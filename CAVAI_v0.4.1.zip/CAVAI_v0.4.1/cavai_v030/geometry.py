"""OCCT-backed geometry serialization and an explicitly non-lossless query index.

Exact geometry is stored as OCCT ASCII BREP; the query index is derived
from it. The index is not advertised as a replacement BREP codec.
"""
import hashlib
import json
import math
import tempfile
from pathlib import Path

import OCP
from OCP.BRep import BRep_Builder, BRep_Tool
from OCP.BRepAdaptor import BRepAdaptor_Curve, BRepAdaptor_Surface, BRepAdaptor_Curve2d
from OCP.BRepBndLib import BRepBndLib
from OCP.BRepGProp import BRepGProp
from OCP.BRepTools import BRepTools, BRepTools_WireExplorer
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.Bnd import Bnd_Box
from OCP.GProp import GProp_GProps
from OCP.IFSelect import IFSelect_RetDone
from OCP.STEPControl import STEPControl_Reader
from OCP.TopAbs import TopAbs_SOLID, TopAbs_COMPOUND, TopAbs_COMPSOLID
from OCP.TopExp import TopExp
from OCP.TopTools import TopTools_IndexedMapOfShape
from OCP.TopoDS import TopoDS, TopoDS_Iterator, TopoDS_Shape

SCHEMA_VERSION = "cavai-cad-0.3.0-core.1"


def canonical_json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False)


def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()


def digest_json(value):
    return digest_bytes(canonical_json(value).encode("utf-8"))


def file_sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def kind(enum):
    return enum.name.split("_", 1)[-1].lower()


def xyz(point):
    return [float(point.X()), float(point.Y()), float(point.Z())]


def axis_system(position):
    return {
        "origin": xyz(position.Location()),
        "axis": xyz(position.Direction()),
        "x_direction": xyz(position.XDirection()),
        "y_direction": xyz(position.YDirection()),
    }


def location_matrix(shape):
    transform = shape.Location().Transformation()
    return [[float(transform.Value(row, col))
             for col in range(1, 5)] for row in range(1, 4)]


def direct_children(shape):
    iterator = TopoDS_Iterator(shape, True, True)
    while iterator.More():
        yield iterator.Value()
        iterator.Next()


def shape_map(shape):
    mapping = TopTools_IndexedMapOfShape()
    TopExp.MapShapes_s(shape, mapping, True, True)
    return mapping


def node_id(index):
    if index < 1:
        raise ValueError("A topology reference was not found")
    return "N%06d" % index


def bbox(shape):
    box = Bnd_Box()
    # Analytic bounds, without expanding them by stored shape tolerances.
    BRepBndLib.AddOptimal_s(shape, box, False, False)
    if box.IsVoid() or box.IsOpen():
        return None
    return list(map(float, box.Get()))


def measure(shape, method):
    prop = GProp_GProps()
    if method == "volume":
        BRepGProp.VolumeProperties_s(shape, prop, True, False, False)
    elif method == "area":
        BRepGProp.SurfaceProperties_s(shape, prop)
    elif method == "length":
        BRepGProp.LinearProperties_s(shape, prop)
    else:
        raise ValueError("Unknown measure")
    mass = float(prop.Mass())
    if not math.isfinite(mass):
        raise ValueError("Non-finite geometric measure")
    center = xyz(prop.CentreOfMass()) if mass != 0 else None
    return {"value": mass, "centroid": center}


def kernel_validity(shape):
    if shape.IsNull():
        return {"status": "invalid", "reason": "null_shape"}
    try:
        valid = BRepCheck_Analyzer(shape).IsValid()
        return {"status": "valid" if valid else "invalid",
                "reason": "OCCT_BRepCheck_Analyzer"}
    except Exception as exc:
        return {"status": "unknown", "reason": type(exc).__name__}


def load_shape(path):
    """Load a STEP/STP or BREP file; CATIA must use the existing adapter.

    STEP transfer target length is explicitly millimetres. A bare BREP
    carries no universally reliable unit declaration and returns unknown.
    """
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    ext = path.suffix.lower()
    if ext in (".step", ".stp"):
        reader = STEPControl_Reader()
        if reader.ReadFile(str(path)) != IFSelect_RetDone:
            raise ValueError("STEP read failed")
        reader.SetSystemLengthUnit(1.0)
        transferred = reader.TransferRoots()
        if transferred <= 0:
            raise ValueError("STEP transfer produced no roots")
        shape = reader.OneShape()
        unit = "mm"
    elif ext == ".brep":
        shape = TopoDS_Shape()
        if not BRepTools.Read_s(shape, str(path), BRep_Builder()):
            raise ValueError("BREP read failed")
        unit = "unknown"
    else:
        raise ValueError("Use existing CATIA Automation adapter for CATPart/CATProduct")
    if shape.IsNull():
        raise ValueError("CAD reader returned a null shape")
    return shape, unit


def serialize_brep(shape):
    """Use the upstream OCCT codec rather than a hand-written serializer."""
    from OCP.TopTools import TopTools_FormatVersion
    if shape.IsNull():
        raise ValueError("Cannot serialize a null shape")
    with tempfile.TemporaryDirectory(prefix="cavai_brep_") as tmp:
        path = Path(tmp) / "shape.brep"
        if not BRepTools.Write_s(shape, str(path), True, True,
                                    TopTools_FormatVersion.TopTools_FormatVersion_VERSION_3):
            raise IOError("OCCT BREP write failed")
        data = path.read_bytes()
    if not data:
        raise ValueError("OCCT wrote an empty BREP")
    return {"codec": "occt_ascii_brep", "sha256": digest_bytes(data),
            "text": data.decode("ascii"), "bytes": len(data)}


def restore_brep(payload):
    if payload.get("codec") != "occt_ascii_brep":
        raise ValueError("Unsupported geometry codec")
    data = payload["text"].encode("ascii")
    if len(data) != payload["bytes"] or digest_bytes(data) != payload["sha256"]:
        raise ValueError("BREP content hash/length mismatch")
    with tempfile.TemporaryDirectory(prefix="cavai_brep_") as tmp:
        path = Path(tmp) / "shape.brep"
        path.write_bytes(data)
        shape = TopoDS_Shape()
        if not BRepTools.Read_s(shape, str(path), BRep_Builder()):
            raise ValueError("OCCT BREP restore failed")
    if shape.IsNull():
        raise ValueError("Restored BREP is null")
    return shape


def spline_curve(curve, is_bspline):
    count = curve.NbPoles()
    out = {"degree": curve.Degree(), "poles": [xyz(curve.Pole(i))
            for i in range(1, count + 1)], "rational": curve.IsRational()}
    if curve.IsRational():
        out["weights"] = [float(curve.Weight(i)) for i in range(1, count + 1)]
    if is_bspline:
        out.update(knots=[float(curve.Knot(i)) for i in range(1, curve.NbKnots() + 1)],
                   multiplicities=[int(curve.Multiplicity(i))
                                   for i in range(1, curve.NbKnots() + 1)],
                   periodic=curve.IsPeriodic())
    return out


def spline_surface(surface, is_bspline):
    nu, nv = surface.NbUPoles(), surface.NbVPoles()
    out = {
        "u_degree": surface.UDegree(), "v_degree": surface.VDegree(),
        "poles_u_v": [[xyz(surface.Pole(i, j)) for j in range(1, nv + 1)]
                      for i in range(1, nu + 1)],
        "u_rational": surface.IsURational(), "v_rational": surface.IsVRational(),
    }
    if out["u_rational"] or out["v_rational"]:
        out["weights_u_v"] = [[float(surface.Weight(i, j))
                                for j in range(1, nv + 1)]
                               for i in range(1, nu + 1)]
    if is_bspline:
        out.update(
            u_knots=[float(surface.UKnot(i)) for i in range(1, surface.NbUKnots() + 1)],
            v_knots=[float(surface.VKnot(i)) for i in range(1, surface.NbVKnots() + 1)],
            u_multiplicities=[int(surface.UMultiplicity(i))
                              for i in range(1, surface.NbUKnots() + 1)],
            v_multiplicities=[int(surface.VMultiplicity(i))
                              for i in range(1, surface.NbVKnots() + 1)],
            u_periodic=surface.IsUPeriodic(), v_periodic=surface.IsVPeriodic(),
        )
    return out


def describe_curve(edge):
    if BRep_Tool.Degenerated_s(edge):
        return {"type": "degenerated", "detail": "exact_brep_only"}
    adaptor = BRepAdaptor_Curve(edge)
    name = kind(adaptor.GetType())
    out = {"type": name, "detail": "indexed_parameters",
           "parameter_range": [float(adaptor.FirstParameter()),
                               float(adaptor.LastParameter())]}
    if all(math.isfinite(v) and abs(v) < 1e100 for v in out["parameter_range"]):
        out["end_points"] = [xyz(adaptor.Value(v)) for v in out["parameter_range"]]
    else:
        out["parameter_range"] = None
    if name == "line":
        line = adaptor.Line()
        out.update(origin=xyz(line.Location()), direction=xyz(line.Direction()))
    elif name == "circle":
        circle = adaptor.Circle()
        out.update(frame=axis_system(circle.Position()), radius=float(circle.Radius()))
    elif name == "ellipse":
        ellipse = adaptor.Ellipse()
        out.update(frame=axis_system(ellipse.Position()),
                   major_radius=float(ellipse.MajorRadius()),
                   minor_radius=float(ellipse.MinorRadius()))
    elif name == "bsplinecurve":
        out.update(spline_curve(adaptor.BSpline(), True))
    elif name == "beziercurve":
        out.update(spline_curve(adaptor.Bezier(), False))
    else:
        out["detail"] = "partial_index_exact_brep_only"
    return out


def describe_surface(face):
    adaptor = BRepAdaptor_Surface(face, True)
    name = kind(adaptor.GetType())
    uv = list(map(float, BRepTools.UVBounds_s(face)))
    out = {"type": name, "detail": "indexed_parameters",
           "uv_bounds": uv if all(math.isfinite(v) and abs(v) < 1e100 for v in uv) else None}
    if name == "plane":
        out["frame"] = axis_system(adaptor.Plane().Position())
    elif name == "cylinder":
        cylinder = adaptor.Cylinder()
        out.update(frame=axis_system(cylinder.Position()), radius=float(cylinder.Radius()))
    elif name == "cone":
        cone = adaptor.Cone()
        out.update(frame=axis_system(cone.Position()), reference_radius=float(cone.RefRadius()),
                   semi_angle_rad=float(cone.SemiAngle()))
    elif name == "sphere":
        sphere = adaptor.Sphere()
        out.update(frame=axis_system(sphere.Position()), radius=float(sphere.Radius()))
    elif name == "torus":
        torus = adaptor.Torus()
        out.update(frame=axis_system(torus.Position()),
                   major_radius=float(torus.MajorRadius()),
                   minor_radius=float(torus.MinorRadius()))
    elif name == "bsplinesurface":
        out.update(spline_surface(adaptor.BSpline(), True))
    elif name == "beziersurface":
        out.update(spline_surface(adaptor.Bezier(), False))
    else:
        out["detail"] = "partial_index_exact_brep_only"
    return out



def describe_pcurve(edge, face):
    """Face-local UV curve for an oriented edge use, including trim range."""
    def uv(point):
        return [float(point.X()), float(point.Y())]
    try:
        a = BRepAdaptor_Curve2d(edge, face)
        typ = kind(a.GetType())
        out = {"type": typ, "detail": "indexed_parameters",
               "parameter_range": [float(a.FirstParameter()), float(a.LastParameter())]}
        if typ == "line":
            c = a.Line()
            out.update(origin_uv=uv(c.Location()), direction_uv=uv(c.Direction()))
        elif typ in ("circle", "ellipse"):
            c = a.Circle() if typ == "circle" else a.Ellipse()
            out.update(origin_uv=uv(c.Location()),
                       x_direction_uv=uv(c.XAxis().Direction()),
                       y_direction_uv=uv(c.YAxis().Direction()))
            if typ == "circle":
                out["radius_uv"] = float(c.Radius())
            else:
                out.update(major_radius_uv=float(c.MajorRadius()),
                           minor_radius_uv=float(c.MinorRadius()))
        elif typ in ("bsplinecurve", "beziercurve"):
            c = a.BSpline() if typ == "bsplinecurve" else a.Bezier()
            out.update(degree=c.Degree(), rational=c.IsRational(),
                       poles_uv=[uv(c.Pole(i)) for i in range(1, c.NbPoles() + 1)])
            if c.IsRational():
                out["weights"] = [float(c.Weight(i)) for i in range(1, c.NbPoles() + 1)]
            if typ == "bsplinecurve":
                out.update(knots=[float(c.Knot(i)) for i in range(1, c.NbKnots() + 1)],
                           multiplicities=[c.Multiplicity(i) for i in range(1, c.NbKnots() + 1)],
                           periodic=c.IsPeriodic())
        else:
            out["detail"] = "partial_index_exact_brep_only"
        canonical_json(out)
        return out
    except Exception as exc:
        return {"detail": "exact_brep_only", "reason": type(exc).__name__}


def face_loops(face, mapping):
    """Keep oriented uses, not just a set of unique edge IDs.

    A seam may use the same edge twice; invalid wires may not be fully
    traversable by WireExplorer. Preserve unordered raw incidence too.
    """
    outer = BRepTools.OuterWire_s(face)
    loops = []
    for child in direct_children(face):
        if kind(child.ShapeType()) != "wire":
            continue
        wire = TopoDS.Wire_s(child)
        raw = [{"edge_id": node_id(mapping.FindIndex(e)),
                "orientation": kind(e.Orientation())}
               for e in direct_children(wire)]
        ordered = []
        complete = False
        try:
            explorer = BRepTools_WireExplorer(wire, face)
            while explorer.More():
                edge = explorer.Current()
                vertex = explorer.CurrentVertex()
                item = {"edge_id": node_id(mapping.FindIndex(edge)),
                        "orientation": kind(edge.Orientation()),
                        "pcurve_uv": describe_pcurve(edge, face),
                        "start_vertex_id": None if vertex.IsNull() else
                            node_id(mapping.FindIndex(vertex))}
                ordered.append(item)
                explorer.Next()
            # Verify incidence counts, including duplicate edge uses.
            from collections import Counter
            complete = (Counter(x["edge_id"] for x in raw) ==
                        Counter(x["edge_id"] for x in ordered))
        except Exception:
            complete = False
        loops.append({
            "wire_id": node_id(mapping.FindIndex(wire)),
            "role": "outer" if not outer.IsNull() and wire.IsSame(outer) else
                ("inner_or_additional" if not outer.IsNull() else "unknown"),
            "ordered_complete": complete,
            "coedges": ordered,
            "raw_edge_uses": raw,
        })
    return loops


def build_index(shape, max_nodes=100000):
    mapping = shape_map(shape)
    if mapping.Extent() > max_nodes:
        raise ValueError("Geometry index node limit exceeded; no partial index is certified")
    nodes = []
    counts = {}
    edge_faces = {}
    for i in range(1, mapping.Extent() + 1):
        s = mapping.FindKey(i)
        typ = kind(s.ShapeType())
        nid = node_id(i)
        counts[typ] = counts.get(typ, 0) + 1
        node = {"id": nid, "type": typ, "orientation": kind(s.Orientation()),
                "location_matrix_3x4": location_matrix(s),
                "children": [{"id": node_id(mapping.FindIndex(child)),
                              "orientation": kind(child.Orientation())}
                             for child in direct_children(s)],
                "properties": {}, "issues": []}
        p = node["properties"]
        # An unavailable optional field is explicitly reported. Do not
        # substitute a guessed value or silently skip the geometry.
        def capture(key, operation):
            try:
                value = operation()
                canonical_json(value)  # reject NaN and infinity
                p[key] = value
            except Exception as exc:
                p[key] = None
                node["issues"].append({"field": key, "reason": type(exc).__name__})
        capture("bbox", lambda: bbox(s))
        if typ == "vertex":
            v = TopoDS.Vertex_s(s)
            capture("point", lambda: xyz(BRep_Tool.Pnt_s(v)))
            capture("tolerance", lambda: float(BRep_Tool.Tolerance_s(v)))
        elif typ == "edge":
            e = TopoDS.Edge_s(s)
            capture("curve", lambda: describe_curve(e))
            capture("length", lambda: measure(e, "length"))
            capture("tolerance", lambda: float(BRep_Tool.Tolerance_s(e)))
        elif typ == "face":
            f = TopoDS.Face_s(s)
            capture("surface", lambda: describe_surface(f))
            capture("area", lambda: measure(f, "area"))
            capture("tolerance", lambda: float(BRep_Tool.Tolerance_s(f)))
            capture("loops", lambda: face_loops(f, mapping))
            for loop in p.get("loops") or []:
                if not loop["ordered_complete"]:
                    node["issues"].append({"field": "loops",
                                           "reason": "incomplete_ordered_traversal"})
                for use in loop["raw_edge_uses"]:
                    edge_faces.setdefault(use["edge_id"], set()).add(nid)
        elif typ == "solid":
            capture("signed_volume", lambda: measure(s, "volume"))
        nodes.append(node)
    return {"root_id": node_id(mapping.FindIndex(shape)),
            "counts": counts, "nodes": nodes,
            "edge_to_faces": {k: sorted(v) for k, v in sorted(edge_faces.items())},
            "index_limitations": [
                "IDs are local to this bundle; not CATIA persistent feature IDs.",
                "Analytic and spline parameters use the located shape coordinate system.",
                "Location matrices are provenance; do not apply them again to located points.",
                "Surface frames are parametric frames, not automatically outward normals.",
                "Trim pcurves are indexed where supported; the BREP preserves the authoritative exact geometry.",
                "The query index alone is not claimed to reconstruct every trimmed surface.",
                "A STEP compound is not a verified native CATIA assembly tree or constraint set.",
            ]}
