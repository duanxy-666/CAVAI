"""CAVAI v0.3.0 independently testable integration core."""
__version__ = "0.3.0-core.1"
