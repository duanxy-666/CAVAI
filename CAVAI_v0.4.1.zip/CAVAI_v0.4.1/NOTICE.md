# CAVAI 0.4.1 — Third-party notices

CAVAI uses the following independently installed runtime dependencies:
- OpenAI Agents SDK: https://github.com/openai/openai-agents-python
- OpenAI Python: https://github.com/openai/openai-python
- pycatia: https://github.com/evereux/pycatia
- pywin32: https://github.com/mhammond/pywin32
- OCP: https://github.com/CadQuery/OCP

The full source trees of these dependencies are not redistributed here.
The existing mechanical-design-review Skill is retained with its own SOURCE.json
and LICENSE.upstream. See references/SKILL_PROVENANCE.md.
Historical provenance is retained separately; it is not a list of currently
implemented modules. Other dependencies are listed in requirements files.
