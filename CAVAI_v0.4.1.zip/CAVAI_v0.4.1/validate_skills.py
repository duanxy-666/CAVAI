from skills.registry import list_skills, load_skill

def main():
    skills = list_skills()
    if not skills:
        raise SystemExit("No valid Skills found.")
    for item in skills:
        loaded = load_skill(item["name"])
        print("[OK] {} — {}".format(item["name"], item["description"]))
        if not loaded.get("content"):
            raise SystemExit("Empty Skill body: {}".format(item["name"]))
    print("Validated {} Skills.".format(len(skills)))

if __name__ == "__main__":
    main()
