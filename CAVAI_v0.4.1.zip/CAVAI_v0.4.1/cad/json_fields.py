def _page_args(offset, limit, cap=100):
    if type(offset) is not int or offset < 0:
        raise ValueError("offset must be a nonnegative integer")
    if type(limit) is not int or not 1 <= limit <= cap:
        raise ValueError("limit must be in [1, %d]" % cap)


def _pointer(obj, pointer):
    """RFC 6901 pointer into JSON data, never into the local filesystem."""
    if pointer == "":
        return obj
    if not isinstance(pointer, str) or not pointer.startswith("/"):
        raise ValueError("Use an RFC 6901 JSON pointer")
    for segment in pointer[1:].split("/"):
        token = segment.replace("~1", "/").replace("~0", "~")
        if isinstance(obj, dict):
            if token not in obj:
                raise ValueError("Unknown field: " + token)
            obj = obj[token]
        elif isinstance(obj, list):
            if not token.isdecimal() or (len(token) > 1 and token.startswith("0")):
                raise ValueError("Invalid list index")
            index = int(token)
            if index >= len(obj):
                raise ValueError("List index out of range")
            obj = obj[index]
        else:
            raise ValueError("Cannot descend into scalar")
    return obj


def _preview(value):
    if isinstance(value, dict):
        return {"kind": "object", "keys": sorted(value)}
    if isinstance(value, list):
        return {"kind": "array", "length": len(value)}
    if isinstance(value, str) and len(value) > 1024:
        return {"kind": "string", "length": len(value)}
    return {"kind": "value", "value": value}


def _paged(value, offset, limit):
    if isinstance(value, dict):
        keys = sorted(value)
        return {"kind": "object", "total": len(keys), "offset": offset,
                "next_offset": offset + limit if offset + limit < len(keys) else None,
                "items": [{"key": k, "preview": _preview(value[k])}
                          for k in keys[offset:offset + limit]]}
    if isinstance(value, list):
        return {"kind": "array", "total": len(value), "offset": offset,
                "next_offset": offset + limit if offset + limit < len(value) else None,
                "items": [{"index": i, "preview": _preview(value[i])}
                          for i in range(offset, min(offset + limit, len(value)))]}
    if isinstance(value, str):
        return {"kind": "string", "total": len(value), "offset": offset,
                "next_offset": offset + limit if offset + limit < len(value) else None,
                "value": value[offset:offset + limit]}
    if offset:
        raise ValueError("Scalar field has no offset")
    return {"kind": "value", "value": value}


