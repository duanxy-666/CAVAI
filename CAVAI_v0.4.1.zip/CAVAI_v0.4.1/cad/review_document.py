"""One exact CAD document; spatially related, dependency-aware review windows.

Complete source fields have a unique owner. Dependency copies in a local
window are exact originals, never substituted by guessed geometry.
Local JSON is authoritative; compact global context is a projection,
explicitly not the full source. No reverse model generation.
"""
from collections import defaultdict, deque
import json
from cad.geometry_transport import encode,size,digest,input_bytes

def rows(value,path,limit):
    item={"path":path,"value":value}
    if size(item)<=limit:
        yield item
    elif isinstance(value,(dict,list)):
        yield {"path":path,"container":"object" if isinstance(value,dict) else "array","length":len(value)}
        for k,v in (value.items() if isinstance(value,dict) else enumerate(value)):
            yield from rows(v,path+[k],limit)
    elif isinstance(value,str):
        yield {"path":path,"container":"string","length":len(value)}
        # A character can occupy up to six bytes after JSON escaping.
        step=max(1,(limit-size({"path":path,"offset":0,"text":""})-64)//6)
        for i in range(0,len(value),step):
            yield {"path":path,"offset":i,"text":value[i:i+step]}
    else:
        raise ValueError("单个JSON标量超过可用输入空间")

def packs(records,limit):
    current=[]; used=2
    for r in records:
        cost=size(r)+1
        if cost+2>limit:raise ValueError("单条精确几何记录超出当前模型容量")
        if current and used+cost>limit:
            yield current;current=[];used=2
        current.append(r);used+=cost
    if current:yield current

def restore(records):
    """Test/audit utility: compare JSON fields, not reconstructed CAD."""
    items={};containers={};strings=defaultdict(list)
    for r in records:
        path=tuple(r["path"])
        if "value" in r or "container" in r:
            if path in items or path in containers:raise ValueError("重复所有权")
            if "value" in r:items[path]=r["value"]
            else:containers[path]=(r["container"],r["length"])
        else:strings[path].append((r["offset"],r["text"]))
    child=defaultdict(list)
    for p in set(items)|set(containers):
        if p:child[p[:-1]].append(p[-1])
    def get(p):
        if p in items:return items[p]
        typ,count=containers[p]
        if typ=="string":
            end=0;parts=[]
            for offset,txt in sorted(strings[p]):
                if offset!=end:raise ValueError("字符串片段缺失")
                end+=len(txt);parts.append(txt)
            if end!=count:raise ValueError("字符串长度不符")
            return "".join(parts)
        ks=child[p]
        if len(ks)!=count:raise ValueError("源字段缺失")
        if typ=="array":return [get(p+(i,)) for i in range(count)]
        return {k:get(p+(k,)) for k in ks}
    return get(())

class CADDocument:
    def __init__(self,data,settings):
        self.data=data
        self.sha=digest(data)
        self.g=data.get("geometry") or {}
        self.t=self.g.get("structured_topology") or {}
        self.nodes=self.t.get("nodes") or []
        self.by_id={n["id"]:n for n in self.nodes}
        if len(self.by_id)!=len(self.nodes):raise ValueError("拓扑实体ID重复")
        self.index={n["id"]:i for i,n in enumerate(self.nodes)}
        self.legacy=self.t.get("legacy_to_node") or {}
        self.face_ids={self.legacy[f["face_id"]]:f for f in self.g.get("faces",[])
                       if f.get("face_id") in self.legacy}
        self.edge_ids={self.legacy[e["edge_id"]]:e for e in self.g.get("edges",[])
                       if e.get("edge_id") in self.legacy}
        self.adjacency=defaultdict(set)
        for edge,faces in (self.t.get("edge_to_faces") or {}).items():
            for f in faces:
                self.adjacency[f].update(x for x in faces if x!=f)
        self.bounds=input_bytes(settings)
        self.overview=self.global_geometry()
        # Global context and exact owned fields share the same window.
        # Do not put an independently generated natural-language summary
        # between the Model and the CAD facts.
        # The full global directory is delivered once at discovery.
        # Later windows use a smaller exact feature-level frame plus the
        # current source records. Increasing capacity must not replicate
        # the full face/edge/vertex directory into every window.
        self.overview_complete=False
        self.frame=self.coarse_geometry()
        if size(self.frame)>self.bounds*.48:
            # Explicitly scoped frame for enormous assemblies. Exact
            # global records are still scheduled below; no hidden omission.
            self.frame={k:self.overview[k] for k in ("scope","unit","bounds","counts")}
            self.frame["limitation"]="全局结构超出单窗口；按完整源字段和局部关联进行评测。全局精确目录可查询。"
        self.memory_reserve=max(1200,min(128000,self.bounds//6))
        self.initial_overview=size(self.overview)+self.memory_reserve+2500<=self.bounds
        self.block_limit=self.bounds-size(self.frame)-self.memory_reserve
        if self.block_limit<1000:raise ValueError("配置的上下文不足以容纳几何及必要工具；请填写实际模型容量")
        self.units=self.build()
        self.unit_map={u["id"]:u for u in self.units}

    def coarse_geometry(self):
        return {"scope":"全局结构框架（局部窗口仍含原始精确数据）",
            "unit":self.overview["unit"],"bounds":self.overview["bounds"],"counts":self.overview["counts"],
            "solids":self.overview["solids"],"features":self.overview["features"],
            "relations":self.overview["relations"],"source_limitations":self.data.get("source_limitations",[]),
            "limitation":"为避免重复传输，本框架不重复全局面、边和顶点目录；可通过工具精确回读。"}

    def global_geometry(self):
        # Column tables are readable numeric CAD data. All original
        # non-projected values are in owned source records, not dropped.
        faces=[];edges=[];vertices=[]
        for n in self.nodes:
            p=n.get("properties") or {};nid=n["id"]
            if n["type"]=="face":
                f=self.face_ids.get(nid,{})
                surface=p.get("surface") or {}
                faces.append([nid,f.get("face_id"),f.get("solid_ids"),f.get("surface_type",surface.get("type")),
                    f.get("center_of_mass"),p.get("bbox"),f.get("area",p.get("area")),f.get("normal"),
                    f.get("axis_origin"),f.get("axis_direction"),f.get("radius"),n.get("orientation"),
                    [[l.get("wire_id"),l.get("role"),[[c.get("edge_id"),c.get("orientation")]
                     for c in l.get("coedges",[])] ] for l in p.get("loops",[])]])
            elif n["type"]=="edge":
                e=self.edge_ids.get(nid,{})
                edges.append([nid,e.get("edge_id"),e.get("curve_type"),e.get("length",p.get("length")),
                    [c.get("id") for c in n.get("children",[])],e.get("center_of_mass"),
                    (p.get("curve") or {}).get("end_points"),(self.t.get("edge_to_faces") or {}).get(nid,[])])
            elif n["type"]=="vertex":
                vertices.append([nid,p.get("point")])
        # Older/base-only extractions still supply actual legacy rows.
        graph=self.g.get("feature_graph") or {}
        return {"scope":"客观空间关系目录；类型/区域不等同于功能。完整精确字段见各窗口。",
            "unit":self.g.get("coordinate_unit","mm"),"bounds":self.g.get("bounding_box_mm"),
            "counts":{k:self.g.get(k) for k in ("solid_count","face_count","edge_count","face_type_counts","hole_candidate_count")},
            "solids":[{k:s.get(k) for k in ("solid_id","volume","bounding_box_mm","center_of_mass","face_count")} for s in self.g.get("solids",[])],
            "features":graph.get("features",[]),"relations":graph.get("relationships",[]),
            "faces":{"columns":["node","face","solids","surface","center","bbox","area","normal","axis_origin","axis_direction","radius","orientation","loops[wire,role,edges]"],
                     "rows":faces} if faces else self.g.get("faces",[]),
            "edges":{"columns":["node","edge","curve","length","vertices","center","endpoints","incident_faces"],"rows":edges} if edges else self.g.get("edges",[]),
            "vertices":{"columns":["node","point"],"rows":vertices},
            "extraction":self.g.get("extraction"),"source_limitations":self.data.get("source_limitations",[]),
            "rules":self.g.get("local_rules",[])}

    def descendants(self,nid):
        found=set();stack=[nid]
        while stack:
            x=stack.pop()
            if x in found or x not in self.by_id:continue
            found.add(x)
            n=self.by_id[x]
            stack.extend(c.get("id") for c in n.get("children",[]) if isinstance(c,dict))
            if n["type"]=="face":
                for loop in n.get("properties",{}).get("loops",[]):
                    stack.extend(c.get("edge_id") for c in loop.get("coedges",[]))
        return found

    def face_order(self):
        # Start from actual structural groups, then continue through
        # shared-edge adjacency, keeping solid/component identity.
        all_faces={n["id"] for n in self.nodes if n["type"]=="face"}
        graph=self.g.get("feature_graph") or {}
        neighbors={f:set(self.adjacency[f]) for f in all_faces}
        for group in graph.get("features",[]):
            ids=[self.legacy.get(f) for f in group.get("evidence_face_ids",[])]
            ids=[f for f in ids if f in all_faces]
            # Connect each group by a star, rather than a quadratic clique.
            if ids:
                for f in ids[1:]:
                    neighbors[ids[0]].add(f);neighbors[f].add(ids[0])
        def key(n):
            f=self.face_ids.get(n,{})
            center=f.get("center_of_mass") or [0,0,0]
            return (tuple(f.get("solid_ids") or []),tuple(center),n)
        todo=set(all_faces);out=[]
        for seed in sorted(all_faces,key=key):
            if seed not in todo:continue
            todo.remove(seed);q=deque([seed])
            while q:
                f=q.popleft();out.append(f)
                for other in sorted(neighbors[f]&todo,key=key):
                    todo.remove(other);q.append(other)
        return out

    def build(self):
        if size(self.data)<=self.bounds*.85:
            return [{"id":"FULL","kind":"full","source_sha256":self.sha,"data":self.data,
                     "face_ids":list(self.face_ids),"owned":[],"support":[]}]
        units=[];owned=set();limit=self.block_limit
        def add(kind,records,faces=None,support=None,fragmented=False,frame_mode="normal",cap=None):
            u={"id":"U%04d"%(len(units)+1),"kind":kind,"source_sha256":self.sha,
               "owned":records,"face_ids":faces or [],"support":support or [],
               "fragmented_dependencies":fragmented,"frame_mode":frame_mode}
            if size(u)>(cap if cap is not None else limit)+500:raise ValueError("几何窗口大小超过规划容量")
            units.append(u)
        def node_record(nid):
            return {"path":["geometry","structured_topology","nodes",self.index[nid]],"value":self.by_id[nid]}
        # All non-node fields retain their original paths and values.
        # This is the first engineering window, not a tool-free reader.
        metadata=[]
        metadata.append({"path":[],"container":"object","length":len(self.data)})
        for k,v in self.data.items():
            if k!="geometry":metadata.extend(rows(v,[k],max(500,limit//2)));continue
            metadata.append({"path":[k],"container":"object","length":len(v)})
            for gk,gv in v.items():
                if gk!="structured_topology" or not isinstance(gv,dict):
                    metadata.extend(rows(gv,[k,gk],max(500,limit//2)));continue
                metadata.append({"path":[k,gk],"container":"object","length":len(gv)})
                for tk,tv in gv.items():
                    if tk=="nodes":
                        metadata.append({"path":[k,gk,tk],"container":"array","length":len(tv)})
                    else:metadata.extend(rows(tv,[k,gk,tk],max(500,limit//2)))
        # Whole solid/shell/compound records supply actual hierarchy.
        for n in self.nodes:
            if n["type"] not in {"face","wire","edge","vertex"}:
                metadata.extend(rows(n,["geometry","structured_topology","nodes",self.index[n["id"]]],max(500,limit//2)))
                owned.add(n["id"])
        if self.initial_overview:
            first_cap=self.bounds-size(self.overview)-self.memory_reserve
            # The first global frame already contains the full numeric
            # face/edge/vertex directory. Place only fitting original records
            # alongside it. All remaining source values keep their ownership.
            first=[];remaining=[];used=2
            for r in metadata:
                c=size(r)+1
                if used+c<=first_cap-700:
                    first.append(r);used+=c
                else:remaining.append(r)
            add("global",first,frame_mode="overview",cap=first_cap)
            metadata=remaining
        for group in packs(metadata,max(800,limit-450)):add("global",group)
        # Greedy connected groups; each normal region includes the whole
        # face/wire/edge/vertex dependency closure. Shared dependencies
        # are explicitly support copies, not duplicate ownership.
        current=[];closure=set();cost=0
        node_sizes={}
        def estimate_node(nid):
            if nid not in node_sizes:node_sizes[nid]=size(node_record(nid))+4
            return node_sizes[nid]
        def flush():
            nonlocal current,closure,cost
            if not current:return
            ordered=sorted(closure,key=self.index.get)
            prim=[node_record(n) for n in ordered if n not in owned]
            support=[self.by_id[n] for n in ordered if n in owned]
            add("region",prim,list(current),support)
            owned.update(closure);current=[];closure=set();cost=0
        for f in self.face_order():
            dep=self.descendants(f)
            fresh=dep-closure
            additional=sum(estimate_node(n) for n in fresh)
            if current and cost+additional+100*len(current)>limit-1400:flush()
            depcost=sum(estimate_node(n) for n in dep)
            if depcost>limit-1400:
                # Extremely large surface/curve. Preserve every owned
                # field, expose exact IDs and explicitly mark dependency
                # fragmentation. The model can use precise field tools.
                if current:flush()
                missing=sorted(dep-owned,key=self.index.get)
                fragment=[]
                for n in missing:
                    fragment.extend(rows(self.by_id[n],["geometry","structured_topology","nodes",self.index[n]],max(500,limit//2)))
                for group in packs(fragment,max(800,limit-900)):
                    add("region_fragment",group,[f],fragmented=True)
                owned.update(missing)
                continue
            cost+=sum(estimate_node(n) for n in dep-closure)
            current.append(f);closure.update(dep)
        flush()
        # Isolated entities, degenerate shapes and otherwise unowned
        # fields are still evaluated. Nothing is silently dropped.
        other=[]
        for n in self.nodes:
            if n["id"] not in owned:
                other.extend(rows(n,["geometry","structured_topology","nodes",self.index[n["id"]]],max(500,limit//2)))
        for group in packs(other,max(800,limit-450)):add("remaining",group)
        return units

    def frame_for(self,unit):
        if unit["kind"]=="full":return {}
        return self.overview if unit.get("frame_mode")=="overview" else self.frame

    def manifest(self):
        return [{"id":u["id"],"kind":u["kind"],"sha256":digest(u),
            "face_count":len(u["face_ids"]),"bytes":size(u),"fragmented":u.get("fragmented_dependencies",False)}
            for u in self.units]

    def reconstruct(self):
        if len(self.units)==1 and self.units[0]["kind"]=="full":return self.units[0]["data"]
        return restore(r for u in self.units for r in u["owned"])
