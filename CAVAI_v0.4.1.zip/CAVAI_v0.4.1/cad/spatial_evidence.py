"""Read-only OCCT spatial measurements on the current model's retained STEP."""
from __future__ import annotations
import math
from pathlib import Path

def _coords(value):
    if not isinstance(value, (tuple, list)) or len(value) != 3:
        raise ValueError("需要三个毫米坐标")
    out = [float(x) for x in value]
    if not all(math.isfinite(x) and abs(x) <= 1e8 for x in out):
        raise ValueError("坐标不合法")
    return out

def read_shape(step_path):
    from OCP.STEPControl import STEPControl_Reader
    from OCP.IFSelect import IFSelect_RetDone
    from OCP.Interface import Interface_Static
    path = Path(step_path or "")
    if not path.is_file():
        raise ValueError("没有可用的本地 STEP 几何源，请重新导入模型")
    try:
        Interface_Static.SetCVal_s("xstep.cascade.unit", "MM")
    except Exception:
        pass
    reader = STEPControl_Reader()
    if reader.ReadFile(str(path)) != IFSelect_RetDone or not reader.TransferRoots():
        raise ValueError("无法读取当前 STEP 几何源")
    shape = reader.OneShape()
    if shape.IsNull():
        raise ValueError("STEP 无有效几何")
    return shape

def _solids(shape):
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopAbs import TopAbs_SOLID
    from OCP.TopoDS import TopoDS
    it = TopExp_Explorer(shape, TopAbs_SOLID)
    out = []
    while it.More():
        out.append(TopoDS.Solid_s(it.Current()))
        it.Next()
    if not out:
        raise ValueError("当前几何没有可分类的实体")
    return out

def classify_point(shape, coordinates, tolerance_mm=1e-5):
    from OCP.BRepClass3d import BRepClass3d_SolidClassifier
    from OCP.TopAbs import TopAbs_IN, TopAbs_ON, TopAbs_OUT
    from OCP.gp import gp_Pnt
    xyz = _coords(coordinates)
    tol = float(tolerance_mm)
    if not math.isfinite(tol) or not 1e-7 <= tol <= 0.01:
        raise ValueError("容差需在 1e-7 到 0.01 mm 之间")
    states = []
    for solid in _solids(shape):
        state = BRepClass3d_SolidClassifier(solid, gp_Pnt(*xyz), tol).State()
        states.append("inside" if state == TopAbs_IN else "boundary" if state == TopAbs_ON else "outside" if state == TopAbs_OUT else "unknown")
    union = "inside" if "inside" in states else "unknown" if "unknown" in states else "boundary" if "boundary" in states else "outside"
    return {"measurement": "point_classification", "point_mm": xyz, "classification": union,
            "tolerance_mm": tol, "solid_count": len(states),
            "note": "仅证实该点相对当前实体集合的位置，不代表整个空间或通道。"}

def box_occupancy(shape, corner_min, corner_max):
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Common, BRepAlgoAPI_Fuse
    from OCP.BRepGProp import BRepGProp
    from OCP.GProp import GProp_GProps
    from OCP.gp import gp_Pnt
    lo, hi = _coords(corner_min), _coords(corner_max)
    spans = [b-a for a,b in zip(lo,hi)]
    if any(x <= 1e-5 for x in spans):
        raise ValueError("区域必须是具有正体积的轴对齐长方体")
    volume = math.prod(spans)
    probe = BRepPrimAPI_MakeBox(gp_Pnt(*lo), gp_Pnt(*hi)).Shape()
    solids = _solids(shape)
    if len(solids)>128:
        raise ValueError("实体数量超过当前空间测量的计算范围")
    merged = solids[0]
    for solid in solids[1:]:
        op = BRepAlgoAPI_Fuse(merged, solid)
        if not op.IsDone():
            raise ValueError("实体合并失败，无法可靠测量占据体积")
        merged = op.Shape()
    common = BRepAlgoAPI_Common(merged, probe)
    if not common.IsDone():
        raise ValueError("OCCT 布尔交集计算失败")
    props = GProp_GProps()
    if not common.Shape().IsNull():
        BRepGProp.VolumeProperties_s(common.Shape(), props)
    occupied = float(props.Mass())
    if not math.isfinite(occupied) or occupied < -1e-6 or occupied > volume + max(1e-6, volume*1e-7):
        raise ValueError("交集体积结果异常")
    occupied = min(volume, max(0.0, occupied))
    return {"measurement": "box_occupancy", "min_mm": lo, "max_mm": hi,
            "region_volume_mm3": volume, "occupied_volume_mm3": occupied,
            "free_volume_mm3": volume-occupied, "occupied_fraction": occupied/volume,
            "note": "轴对齐区域的实体占据体积；空余体积不证明空间连通或运动可行。"}
