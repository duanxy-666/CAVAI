"""Offline orthographic + isometric views of the actual OCP STEP shape.

Uses Open CASCADE BRepMesh tessellation and Pillow's software rasterization;
no cloud viewer, no WebGL, no network, no visual hallucination. Views are
illustrative of shape only; B-Rep data remains the dimensional authority.
"""
from __future__ import annotations

import math
from pathlib import Path

VIEW_DEFS = (
    ('ISOMETRIC', (0.7071068, -0.7071068, 0), (0.4082483, 0.4082483, 0.8164966)),
    ('FRONT', (1, 0, 0), (0, 0, 1)),
    ('TOP', (1, 0, 0), (0, 1, 0)),
    ('RIGHT', (0, 1, 0), (0, 0, 1)),
)


def _dot(a, b):
    return sum(a[i] * b[i] for i in range(3))


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _extract_triangles(step_path: str, max_triangles: int = 100000):
    from OCP.STEPControl import STEPControl_Reader
    from OCP.IFSelect import IFSelect_RetDone
    from OCP.BRepMesh import BRepMesh_IncrementalMesh
    from OCP.BRep import BRep_Tool
    from OCP.TopAbs import TopAbs_FACE
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopoDS import TopoDS
    from OCP.TopLoc import TopLoc_Location

    reader = STEPControl_Reader()
    if reader.ReadFile(str(step_path)) != IFSelect_RetDone or not reader.TransferRoots():
        raise ValueError('STEP geometry unavailable for preview')
    shape = reader.OneShape()
    if shape.IsNull():
        raise ValueError('STEP shape is empty')
    bbox = _bbox_shape(shape)
    span = max(bbox['size']) or 1.0
    linear_deflection = max(0.05, min(1.2, span * 0.004))
    BRepMesh_IncrementalMesh(shape, linear_deflection, False, 0.45, True)

    triangles = []
    exp = TopExp_Explorer(shape, TopAbs_FACE)
    while exp.More():
        face = TopoDS.Face_s(exp.Current())
        location = TopLoc_Location()
        mesh = BRep_Tool.Triangulation_s(face, location)
        if mesh is not None:
            transform = location.Transformation()
            points = {}
            for i in range(1, mesh.NbNodes() + 1):
                node = mesh.Node(i).Transformed(transform)
                points[i] = (float(node.X()), float(node.Y()), float(node.Z()))
            for i in range(1, mesh.NbTriangles() + 1):
                node_ids = mesh.Triangle(i).Get()
                vertices = tuple(points[j] for j in node_ids)
                if len(triangles) >= max_triangles:
                    raise ValueError('Preview tessellation exceeds local triangle limit')
                normal = _cross(tuple(vertices[1][k] - vertices[0][k] for k in range(3)),
                                tuple(vertices[2][k] - vertices[0][k] for k in range(3)))
                norm = math.sqrt(_dot(normal, normal))
                if norm > 1e-10:
                    triangles.append((vertices, tuple(x / norm for x in normal)))
        exp.Next()
    if not triangles:
        raise ValueError('No triangles available for view')
    return triangles, bbox


def _bbox_shape(shape):
    from OCP.Bnd import Bnd_Box
    from OCP.BRepBndLib import BRepBndLib
    bbox = Bnd_Box()
    bbox.SetGap(0.0)
    BRepBndLib.Add_s(shape, bbox)
    xmin, ymin, zmin, xmax, ymax, zmax = bbox.Get()
    return {'min': (xmin, ymin, zmin), 'max': (xmax, ymax, zmax),
            'size': (xmax - xmin, ymax - ymin, zmax - zmin)}


def render_four_views(step_path: str, output_path: str, width: int = 1040,
                      height: int = 800) -> dict:
    """Render a local JPEG storyboard; does not return or upload any CAD file."""
    from PIL import Image, ImageDraw, ImageFont
    tris, bbox = _extract_triangles(step_path)
    width, height = int(width), int(height)
    if width < 400 or height < 300:
        raise ValueError('Preview is too small')
    img = Image.new('RGB', (width, height), (247, 249, 250))
    draw = ImageDraw.Draw(img)
    cx = [(bbox['min'][i] + bbox['max'][i]) / 2.0 for i in range(3)]
    panel_w, panel_h = width // 2, height // 2
    try:
        font = ImageFont.truetype('DejaVuSans.ttf', 17)
    except OSError:
        font = ImageFont.load_default()
    for idx, (label, right, up) in enumerate(VIEW_DEFS):
        left = (idx % 2) * panel_w
        top = (idx // 2) * panel_h
        border = (225, 234, 237)
        draw.rounded_rectangle((left + 10, top + 10, left + panel_w - 10, top + panel_h - 10),
                               radius=14, fill=(255, 255, 255), outline=border, width=2)
        draw.text((left + 26, top + 23), label, font=font, fill=(35, 75, 89))
        forward = _cross(right, up)
        projected = []
        min_x = min_y = float('inf')
        max_x = max_y = -float('inf')
        for vertices, normal in tris:
            ps = []
            depth = 0.0
            for v in vertices:
                dv = tuple(v[i] - cx[i] for i in range(3))
                px, py = _dot(dv, right), _dot(dv, up)
                min_x, max_x = min(min_x, px), max(max_x, px)
                min_y, max_y = min(min_y, py), max(max_y, py)
                depth += _dot(dv, forward) / 3.0
                ps.append((px, py))
            brightness = 0.52 + 0.32 * abs(_dot(normal, forward)) + 0.11 * abs(_dot(normal, (0.3, 0.55, 0.78)))
            brightness = max(0.48, min(brightness, 0.95))
            color = tuple(int(min(245, x * brightness + 30)) for x in (143, 182, 201))
            projected.append((depth, ps, color))
        usable_w, usable_h = panel_w - 90, panel_h - 110
        scale = min(usable_w / max(max_x - min_x, 1e-6),
                    usable_h / max(max_y - min_y, 1e-6))
        scale = max(1e-6, scale)
        panel_cx, panel_cy = left + panel_w / 2, top + panel_h / 2 + 12
        mid_x, mid_y = (max_x + min_x) / 2.0, (max_y + min_y) / 2.0
        # Simple CPU painter's algorithm. This is a visual aid, not a CAD viewport.
        for _, points, color in sorted(projected, key=lambda x: x[0]):
            draw.polygon([(round(panel_cx + (x - mid_x) * scale, 1),
                           round(panel_cy - (y - mid_y) * scale, 1)) for x, y in points],
                         fill=color)
    img.save(output_path, format='JPEG', quality=72, optimize=True)
    return {'status': 'ok', 'preview_path': str(Path(output_path).resolve()),
            'preview_width': width, 'preview_height': height,
            'triangles_rendered': len(tris),
            'projection': ['isometric', 'front', 'top', 'right'],
            'note': '本地B-Rep三角网格预览，仅辅助视觉理解；尺寸必须以OCP数据为准。'}
