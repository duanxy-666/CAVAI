"""Conservative B-Rep structure graph, derived from observed face/edge topology.

Scientific basis: attributed adjacency graphs used in CAD feature recognition
(e.g., AAGNet). This is NOT AAGNet inference, neural network classification,
or proof of mechanical function. It groups geometric patches and records their
relationships so the Agent can investigate a mechanical hypothesis efficiently.

Python 3.9, stdlib only. Never calls an LLM or sends model data externally.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from math import sqrt
from typing import Any, Dict, List, Optional

MAX_RELATED = 18
MAX_RELATIONS = 1800


def _dot(a, b):
    return sum(float(x) * float(y) for x, y in zip(a, b))


def _norm(a):
    return sqrt(_dot(a, a))


def _unit(a):
    if not isinstance(a, (list, tuple)) or len(a) != 3:
        return None
    try:
        size = _norm(a)
        return [float(x) / size for x in a] if size > 1e-12 else None
    except (TypeError, ValueError):
        return None


def _collinear_axis(a: dict, b: dict) -> bool:
    ua = _unit(a.get('axis_direction'))
    ub = _unit(b.get('axis_direction'))
    pa, pb = a.get('axis_origin'), b.get('axis_origin')
    if ua is None or ub is None or not isinstance(pa, list) or not isinstance(pb, list):
        return False
    if abs(_dot(ua, ub)) < 0.99995:
        return False
    delta = [float(pb[i]) - float(pa[i]) for i in range(3)]
    proj = _dot(ua, delta)
    perp = sqrt(sum((delta[i] - proj * ua[i]) ** 2 for i in range(3)))
    return perp <= max(0.08, min(float(a.get('radius') or 0), float(b.get('radius') or 0)) * 0.002)


def _same_patch(a: dict, b: dict) -> bool:
    if a.get('surface_type') != b.get('surface_type'):
        return False
    if not set(a.get('solid_ids') or []).intersection(b.get('solid_ids') or []):
        return False
    if a.get('surface_type') == 'cylinder':
        ra, rb = a.get('radius'), b.get('radius')
        if not isinstance(ra, (int, float)) or not isinstance(rb, (int, float)):
            return False
        return (a.get('cylindrical_side') == b.get('cylindrical_side') and
                abs(ra - rb) <= max(0.001, min(abs(ra), abs(rb)) * 0.0001) and
                _collinear_axis(a, b))
    if a.get('surface_type') == 'plane':
        na, nb = _unit(a.get('normal')), _unit(b.get('normal'))
        oa, ob = a.get('plane_origin'), b.get('plane_origin')
        if na is None or nb is None or not isinstance(oa, list) or not isinstance(ob, list):
            return False
        delta = [float(ob[i]) - float(oa[i]) for i in range(3)]
        return abs(_dot(na, nb)) > 0.99995 and abs(_dot(na, delta)) <= 0.025
    return False


def build_feature_graph(geometry: dict) -> dict:
    """Produce stable local feature IDs and explicit provenance from OCP JSON.

    Note: IDs are stable within one extraction result, not across STEP exports.
    A graph node is an observed geometric region, not a named functional part.
    """
    if geometry.get('status') != 'ok':
        return {'status': 'unavailable', 'reason': 'B-Rep geometry not available'}
    faces = {f['face_id']: f for f in geometry.get('faces', [])
             if isinstance(f, dict) and f.get('face_id')}
    edge_faces = defaultdict(set)
    for fid, face in faces.items():
        for edge_id in face.get('edge_ids', []):
            edge_faces[edge_id].add(fid)
    neighbours = defaultdict(set)
    nonmanifold_edges = 0
    for edge_id, fids in edge_faces.items():
        if len(fids) > 2:
            nonmanifold_edges += 1
        if len(fids) > 10:  # avoid pathological super-linear edges from corrupt data
            continue
        for fid in fids:
            neighbours[fid].update(fids - {fid})

    source_ids = [fid for fid, f in faces.items() if f.get('surface_type') in {'cylinder', 'plane'}]
    parent = {fid: fid for fid in source_ids}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[max(ra, rb)] = min(ra, rb)

    for fid in source_ids:
        for other in neighbours[fid]:
            if other in parent and fid < other and _same_patch(faces[fid], faces[other]):
                union(fid, other)
    components = defaultdict(list)
    for fid in source_ids:
        components[find(fid)].append(fid)

    feature_records = []
    face_to_feature = {}
    groups = sorted(components.values(), key=lambda ids: min(ids))
    cylinder_number = 0
    plane_number = 0
    for ids in groups:
        ids.sort()
        first = faces[ids[0]]
        kind = 'cylindrical_region' if first.get('surface_type') == 'cylinder' else 'planar_region'
        if kind == 'cylindrical_region':
            cylinder_number += 1
            feature_id = 'CY-{:04d}'.format(cylinder_number)
        else:
            plane_number += 1
            feature_id = 'PL-{:04d}'.format(plane_number)
        areas = [float(faces[fid].get('area') or 0) for fid in ids]
        centers = [faces[fid].get('center_of_mass') for fid in ids]
        weights = [max(a, 1e-9) for a in areas]
        mass = sum(weights)
        centroid = [round(sum(weights[j] * float(centers[j][k]) for j in range(len(ids)) if isinstance(centers[j], list)) / mass, 3)
                    for k in range(3)] if all(isinstance(v, list) and len(v) == 3 for v in centers) else None
        shared_edges = sorted({eid for fid in ids for eid in faces[fid].get('edge_ids', [])})
        record = {
            'feature_id': feature_id, 'type': kind, 'confidence': 'observed_geometry',
            'evidence_face_ids': ids, 'face_count': len(ids),
            'solid_ids': sorted({sid for fid in ids for sid in faces[fid].get('solid_ids', [])}),
            'surface_area_mm2': round(sum(areas), 3),
            'center_mm': centroid,
            'boundary_edge_ids': shared_edges,
            'note': '几何区域，不代表已确认的机械零件或功能',
        }
        if kind == 'cylindrical_region':
            record.update(radius_mm=round(float(first.get('radius') or 0), 4),
                          diameter_mm=round(float(first.get('diameter') or 0), 4),
                          side=first.get('cylindrical_side', 'undetermined'),
                          axis_origin_mm=first.get('axis_origin'),
                          axis_direction=first.get('axis_direction'))
        else:
            record['normal'] = first.get('normal')
        feature_records.append(record)
        for fid in ids:
            face_to_feature[fid] = feature_id

    hole_records = []
    for idx, hole in enumerate(geometry.get('hole_candidates', []), 1):
        if not isinstance(hole, dict):
            continue
        ident = 'HO-{:04d}'.format(idx)
        source_face = hole.get('source_face_id')
        record = {
            'feature_id': ident, 'type': 'hole_topology_candidate',
            'confidence': hole.get('confidence', 'low'),
            'candidate_id': hole.get('candidate_id'),
            'topology_class': hole.get('topology_class'),
            'diameter_mm': hole.get('diameter'),
            'estimated_depth_mm': hole.get('estimated_depth'),
            'evidence_face_ids': [source_face] if source_face else [],
            'related_cylindrical_region_id': face_to_feature.get(source_face),
            'boundary_edge_ids': hole.get('boundary_circle_edge_ids', []),
            'axis_origin_mm': hole.get('axis_origin'),
            'axis_direction': hole.get('axis_direction'),
            'note': '拓扑候选，不证明螺纹规格、贯通的所有复杂情形或配合功能',
        }
        hole_records.append(record)
    feature_records.extend(hole_records)

    relations = []
    relation_keys = set()
    def add_relation(a, b, label, evidence=None):
        if not a or not b or a == b or len(relations) >= MAX_RELATIONS:
            return
        aa, bb = sorted((a, b))
        key = (aa, bb, label)
        if key in relation_keys:
            return
        relation_keys.add(key)
        relations.append({'from_feature_id': aa, 'to_feature_id': bb, 'relation': label,
                          'evidence_edge_ids': (evidence or [])[:MAX_RELATED]})

    for edge_id, fids in edge_faces.items():
        feature_ids = sorted({face_to_feature.get(fid) for fid in fids if face_to_feature.get(fid)})
        if len(feature_ids) > 6:
            continue
        for i, a in enumerate(feature_ids):
            for b in feature_ids[i + 1:]:
                add_relation(a, b, 'shared_boundary', [edge_id])
    cylinders = [r for r in feature_records if r['type'] == 'cylindrical_region']
    for i, a in enumerate(cylinders[:200]):
        for b in cylinders[i + 1:200]:
            if set(a['solid_ids']).intersection(b['solid_ids']) and _collinear_axis(
                    {'axis_origin': a['axis_origin_mm'], 'axis_direction': a['axis_direction'], 'radius': a['radius_mm']},
                    {'axis_origin': b['axis_origin_mm'], 'axis_direction': b['axis_direction'], 'radius': b['radius_mm']}):
                add_relation(a['feature_id'], b['feature_id'], 'coaxial_geometry_only')
    for hole in hole_records:
        add_relation(hole['feature_id'], hole.get('related_cylindrical_region_id'), 'candidate_derived_from_surface')

    kinds = Counter(x['type'] for x in feature_records)
    return {
        'status': 'ok', 'method': 'rule_based_brep_adjacency_v1',
        'feature_count': len(feature_records), 'feature_type_counts': dict(kinds),
        'relation_count': len(relations), 'nonmanifold_edge_count': nonmanifold_edges,
        'features': feature_records, 'relationships': relations,
        'face_to_feature': face_to_feature,
        'limitations': [
            '由B-Rep邻接与曲面参数形成的几何关系图；不是AAGNet模型推断或机械功能识别。',
            '同轴只表示轴线几何关系，不证明零件接触、配合、传力或连接。',
            '圆柱外表面只报告为圆柱区域，不自动叫轴、凸台、螺钉；孔仍是拓扑候选。',
            '复杂槽、薄壁、螺纹和装配约束不在本版确定性识别范围内。',
        ]
    }


def brief_feature_graph(geometry: dict, max_features: int = 20, max_relations: int = 16) -> dict:
    graph = geometry.get('feature_graph') or {}
    if graph.get('status') != 'ok':
        return {'status': 'not_available'}
    records = graph.get('features', [])
    # Holes first, then cylinders, then a few prominent planar regions.
    ranked = sorted(records, key=lambda f: (0 if f['type'] == 'hole_topology_candidate' else
                                            1 if f['type'] == 'cylindrical_region' else 2,
                                            -float(f.get('surface_area_mm2') or 0), f['feature_id']))
    preview = []
    for feature in ranked[:max_features]:
        keys = ('feature_id', 'type', 'confidence', 'topology_class', 'side', 'radius_mm',
                'diameter_mm', 'estimated_depth_mm', 'face_count', 'center_mm',
                'axis_direction', 'solid_ids')
        preview.append({k: feature[k] for k in keys if k in feature})
    return {
        'status': 'ok', 'feature_count': graph['feature_count'],
        'feature_type_counts': graph['feature_type_counts'],
        'relation_count': graph['relation_count'],
        'features_preview': preview,
        'relationships_preview': graph.get('relationships', [])[:max_relations],
        'note': '几何区域和关系不等于机械功能；可调用get_structure_feature查看精确证据ID。'
    }


def query_feature_graph(geometry: dict, feature_id: str = '', kind: str = '',
                        start: int = 0, limit: int = 6) -> dict:
    graph = geometry.get('feature_graph') or {}
    if graph.get('status') != 'ok' and geometry.get('status') == 'ok':
        # Older CAVAI evidence may contain B-Rep faces but no materialized
        # feature graph.  Reconstruct locally, free of API calls, so history
        # continuation can still resolve CY-/PL-/HO- IDs after an upgrade.
        graph = build_feature_graph(geometry)
        geometry['feature_graph'] = graph
    if graph.get('status') != 'ok':
        return {'error': '未找到有效几何关系图'}
    if feature_id:
        for feature in graph['features']:
            if feature['feature_id'] == feature_id:
                related = [x for x in graph.get('relationships', [])
                           if feature_id in (x['from_feature_id'], x['to_feature_id'])]
                item = dict(feature)
                item['evidence_face_ids'] = item.get('evidence_face_ids', [])[:32]
                item['boundary_edge_ids'] = item.get('boundary_edge_ids', [])[:32]
                return {'feature': item, 'related': related[:10],
                        'total_relations': len(related), 'source': 'OCP B-Rep feature graph'}
        return {'error': '没有找到该几何特征ID'}
    allowed = {'cylindrical_region', 'planar_region', 'hole_topology_candidate', ''}
    if kind not in allowed:
        return {'error': '不支持的特征类型'}
    matching = [r for r in graph['features'] if not kind or r['type'] == kind]
    start = max(0, min(int(start), len(matching)))
    limit = max(1, min(int(limit), 8))
    return {'kind': kind or 'all', 'total': len(matching), 'start': start,
            'items': [{k: v for k, v in r.items() if k not in ('boundary_edge_ids', 'evidence_face_ids')}
                      for r in matching[start:start + limit]],
            'note': '局部几何特征列表，不代表功能已经核实'}
