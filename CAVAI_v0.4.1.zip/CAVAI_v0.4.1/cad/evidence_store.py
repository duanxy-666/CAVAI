"""Durable, local-only CAD evidence for audit and subsequent Skill lookups."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

from settings_store import ROOT

EVIDENCE_DIR = ROOT / "data" / "evidence"


def save_inspection_evidence(file_id: str, cad_path: str, inspection: Dict[str, Any]) -> Path:
    """Persist full inspection and geometry locally, atomically; NEVER send to LLM."""
    if len(file_id) != 32 or any(c not in "0123456789abcdef" for c in file_id.lower()):
        raise ValueError("file_id不合法")
    src = Path(cad_path)
    h = hashlib.sha256()
    with src.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    snapshot = {
        "schema_version": "cavai-local-evidence-0.1.10",
        "file_id": file_id, "source_filename": src.name,
        "source_sha256": h.hexdigest(),
        "saved_at_utc": datetime.now(timezone.utc).isoformat(),
        "inspection": inspection,
        "scope": "完整CATIA/OCP解析记录保存在本机；按容量发送完整字段或空间关联窗口，不发送原始CAD文件。",
    }
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    target = EVIDENCE_DIR / (file_id.lower() + ".json")
    temp = target.with_suffix(".tmp")
    temp.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    temp.replace(target)
    return target
