"""Direct CAD field extraction. No AI, reverse modelling, or runtime round-trip gate."""
import copy
import hashlib
import json
import math
from pathlib import Path

SCHEMA = "cavai-structured-cad-0.3.1-direct"
GEOMETRY_KEYS = (
    "backend","source_format","coordinate_unit","solid_count","face_count","edge_count",
    "bounding_box_mm","face_type_counts","edge_type_counts","cylindrical_face_counts",
    "hole_candidate_count","hole_candidates","solids","faces","edges","feature_graph",
    "structured_topology","extraction","local_rules","method_notes","geometry_scope_note",
    "catia_body_count","catia_bodies","assembly_root_name",
)

def extract_details(shape, face_map, edge_map, solids):
    rules = []
    try:
        from OCP.BRepCheck import BRepCheck_Analyzer
        valid = BRepCheck_Analyzer(shape).IsValid()
        rules.append({"rule_id":"OCCT_BREP_VALIDITY",
                      "status":"pass" if valid else "fail",
                      "scope":"OCCT几何与拓扑有效性，不是整体设计验收",
                      "source":"OCP.BRepCheck.BRepCheck_Analyzer"})
    except Exception as exc:
        rules.append({"rule_id":"OCCT_BREP_VALIDITY","status":"not_evaluated",
                      "scope":"OCCT几何与拓扑有效性",
                      "reason":type(exc).__name__})
    info = {"schema":SCHEMA,"status":"complete_extraction",
            "scope":"直接读取当前OCCT导入形状；非完整CATIA原生建模历史"}
    topology = None
    try:
        from cavai_v030.geometry import build_index, shape_map, node_id
        topology = build_index(shape)
        mapping = shape_map(shape)
        refs = {}
        for prefix, collection in (("F",face_map),("E",edge_map)):
            for i in range(1,collection.Extent()+1):
                j = mapping.FindIndex(collection.FindKey(i))
                if j > 0:
                    refs[prefix+"%06d"%i] = node_id(j)
        for i, solid in enumerate(solids,1):
            j = mapping.FindIndex(solid)
            if j > 0:
                refs["S%04d"%i] = node_id(j)
        topology["legacy_to_node"] = refs
        topology["index_limitations"] = [
            "N节点与旧F/E/S编号的映射由同一内核形状直接查询得出。",
            "坐标已包含形状定位；不要重复变换。",
            "UV参数不一定是物理长度；内边界环不自动等于贯通孔。",
            "未读取的几何类型与字段在issues/detail标出；不补造数据。",
            "STEP不能保证包含原生CATIA设计树、材料和装配约束。",
        ]
        def mark_unavailable(value):
            missing = 0
            if isinstance(value,dict):
                detail = value.get("detail")
                if isinstance(detail,str) and "brep_only" in detail:
                    value["detail"] = "not_indexed"
                    missing += 1
                for child in value.values():
                    missing += mark_unavailable(child)
            elif isinstance(value,list):
                for child in value:
                    missing += mark_unavailable(child)
            return missing
        info["node_count"] = len(topology["nodes"])
        info["unindexed_fields"] = mark_unavailable(topology)
        info["nodes_with_issues"] = sum(bool(n["issues"]) for n in topology["nodes"])
        if info["nodes_with_issues"] or info["unindexed_fields"]:
            info["status"] = "partial_fields"
    except Exception as exc:
        info.update(status="base_fields_only",
                    error=type(exc).__name__+": "+str(exc)[:240])
    return topology, info, rules

def packet(inspection):
    """The complete structured data packet sent to the first model request.

    Includes all records in the declared geometry schema, not a sample of
    faces/edges. No raw CAD file, BREP text, local filesystem path, or preview
    binary. Unknown fields are explicit; no AI-derived geometry.
    """
    inspection = inspection or {}
    geometry = inspection.get("geometry") or {}
    data = {"schema":SCHEMA,"document_type":inspection.get("document_type"),
            "geometry":{k:geometry[k] for k in GEOMETRY_KEYS if k in geometry},
            "source_limitations":inspection.get("limitations") or []}
    for key in ("part","assembly"):
        if key in inspection:
            data[key] = inspection[key]
    if "extraction" not in data["geometry"]:
        data["geometry"]["extraction"]={"schema":"legacy",
            "status":"base_fields_only","scope":"旧版直接提取字段；扩展拓扑未取得"}
    issues=[]
    def clean(x, path=""):
        if isinstance(x,dict):
            return {str(k):clean(v,path+"/"+str(k)) for k,v in x.items()
                    if str(k) not in {"preview_path","geometry_json_path","source_path",
                                      "path","api_key","full_path","file_path"}}
        if isinstance(x,(list,tuple)):
            return [clean(v,path+"/"+str(i)) for i,v in enumerate(x)]
        if isinstance(x,float) and not math.isfinite(x):
            issues.append({"field":path,"reason":"non_finite_number"})
            return None
        if x is None or isinstance(x,(str,bool,int,float)):
            return x
        issues.append({"field":path,"reason":"unsupported_value_type:"+type(x).__name__})
        return None
    out=clean(data)
    if issues:
        out["unavailable_values"]=issues
    return out

def encode(data):
    return json.dumps(data,ensure_ascii=False,separators=(",",":"),allow_nan=False)

class DirectGeometrySession:
    """Local access to directly extracted fields and deterministic rules."""
    def __init__(self,inspection,spatial_source=None):
        from cad.json_fields import _paged, _pointer, _page_args
        self._paged,self._pointer,self._page_args=_paged,_pointer,_page_args
        self.data=packet(inspection)
        geometry=self.data["geometry"]
        self.index=geometry.get("structured_topology") or {}
        self.nodes={n["id"]:n for n in self.index.get("nodes",[])}
        self.rules=geometry.get("local_rules") or []
        self.spatial_source=spatial_source
        self._shape=None
        self.fingerprint=hashlib.sha256(encode(self.data).encode("utf-8")).hexdigest()

    def _record(self,tool,args,data):
        record={"source":"direct_OCCT_fields","model_sha256":self.fingerprint,
                "tool":tool,"arguments":args,"data":data}
        record["evidence_id"]="G-"+hashlib.sha256(encode(record).encode("utf-8")).hexdigest()[:24]
        return record

    def list_nodes(self,node_type="",offset=0,limit=30):
        self._page_args(offset,limit)
        rows=[n for n in self.nodes.values() if not node_type or n["type"]==node_type]
        items=[{"id":n["id"],"type":n["type"],"bbox":n["properties"].get("bbox"),
                "orientation":n["orientation"],"issue_count":len(n["issues"])}
               for n in rows[offset:offset+limit]]
        return self._record("list_nodes",dict(node_type=node_type,offset=offset,limit=limit),
                            {"items":items,"total":len(rows),"offset":offset,
                             "next_offset":offset+limit if offset+limit<len(rows) else None})

    def read_node(self,node_id,pointer="",offset=0,limit=30):
        self._page_args(offset,limit)
        if node_id not in self.nodes: raise ValueError("未知N节点")
        return self._record("read_node",dict(node_id=node_id,pointer=pointer,offset=offset,limit=limit),
                self._paged(self._pointer(self.nodes[node_id],pointer),offset,limit))

    def read_model_field(self,pointer="",offset=0,limit=30):
        self._page_args(offset,limit)
        return self._record("read_model_field",dict(pointer=pointer,offset=offset,limit=limit),
                self._paged(self._pointer(self.data,pointer),offset,limit))

    def rule_results(self,offset=0,limit=30):
        self._page_args(offset,limit)
        return self._record("rule_results",dict(offset=offset,limit=limit),
            {"items":self.rules[offset:offset+limit],"total":len(self.rules),
             "next_offset":offset+limit if offset+limit<len(self.rules) else None})

    def local_shape(self):
        if self._shape is None:
            from cad.spatial_evidence import read_shape
            self._shape=read_shape(self.spatial_source)
        return self._shape
