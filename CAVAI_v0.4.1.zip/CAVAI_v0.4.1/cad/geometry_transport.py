"""Provider capacity policy and JSON serialization; not an agent planner."""
import hashlib
import json
import math
from urllib.parse import urlsplit

def encode(x):
    return json.dumps(x,ensure_ascii=False,separators=(",",":"),allow_nan=False)

def size(x):
    return len(encode(x).encode("utf-8"))

def digest(x):
    return hashlib.sha256(encode(x).encode("utf-8")).hexdigest()

def _official(settings):
    host=(urlsplit(settings.get("base_url","")).hostname or "").lower()
    model=str(settings.get("model","")).lower()
    return host=="api.deepseek.com" and model in {
        "deepseek-flash","deepseek-v4-flash","deepseek-v4-pro","deepseek-v4-flash-vision-exp"}

def capacity(settings):
    if settings.get("context_window_tokens"):
        return int(settings["context_window_tokens"]),"user_configured"
    if _official(settings):return 1048576,"known_deepseek_capacity"
    return 65536,"unknown_provider_planning_assumption"

def output_capacity(settings):
    window,_=capacity(settings)
    auto=65536 if _official(settings) else min(16384,window//4)
    upper=min(window-4096,393216) if _official(settings) else window-4096
    return max(200,min(int(settings.get("max_output_tokens") or auto),upper))

def token_byte_rate(settings=None):
    # Calibrated conservative planning coefficient, not a tokenizer.
    # The supplied 98-request official DeepSeek ledger had max input
    # tokens / actual HTTP body bytes 0.386. Use 0.60 plus headroom.
    # Do not generalize that observation to unknown providers.
    return 0.60 if _official(settings or {}) else 0.90

def input_bytes(settings):
    available=capacity(settings)[0]-output_capacity(settings)
    if _official(settings):
        return max(1800,int(max(0,available-16000)*0.78/token_byte_rate(settings)))
    return max(1800,int(available*0.68))

def payload_estimate(payload,settings=None):
    # Conservative planning estimate, NOT a tokenizer or provider usage.
    # The encoded image bytes are not text tokens. Charge a separate
    # conservative visual allowance, and record real usage when returned.
    images=0
    def clean(x):
        nonlocal images
        if isinstance(x,dict):
            if x.get("type") in {"image_url","input_image"}:
                images+=1
                return {"type":"image"}
            return {k:clean(v) for k,v in x.items()}
        if isinstance(x,list):return [clean(v) for v in x]
        return x
    return math.ceil(size(clean(payload))*token_byte_rate(settings))+images*8192+1024
