from __future__ import print_function
import sys
from importlib import import_module
from importlib.metadata import version, PackageNotFoundError

print("Python:", sys.version.split()[0], "|", sys.executable)
for name in ("openai-agents", "openai", "httpx", "fastapi", "cadquery-ocp"):
    try:
        print(name + ":", version(name))
    except PackageNotFoundError:
        print(name + ": NOT INSTALLED")
for name in ("agents", "OCP", "pycatia", "win32com.client"):
    try:
        import_module(name)
        print(name + ": import OK")
    except Exception as exc:
        print(name + ": unavailable -", str(exc)[:140])

print("\nAgents SDK usage-schema compatibility (no API request):")
try:
    from agents.usage import Usage
    Usage()
    print("OK: Usage() initialized successfully")
except Exception as exc:
    print("FAILED: {}: {}".format(type(exc).__name__, str(exc)[:300]))
    print('Fix: python -m pip install --force-reinstall --no-deps "openai==2.44.0"')
