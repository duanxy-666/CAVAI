"""Import documentation from a locally reviewed open-source Skill checkout.

No network, no script execution. User must supply its source, revision and license.
"""
import argparse
import json
import re
import shutil
import tempfile
from pathlib import Path
from skills.registry import SKILLS_DIR, _parse_skill

def install(folder, source, revision, license_file):
    folder=Path(folder).resolve()
    license_file=Path(license_file).resolve()
    if not source.startswith('https://github.com/'):
        raise ValueError('请提供上游GitHub URL')
    if not re.fullmatch(r'[0-9a-fA-F]{40}',revision):
        raise ValueError('请提供实际审核的完整git commit SHA')
    if not license_file.is_file() or license_file.stat().st_size>1000000:
        raise ValueError('需要可读的上游许可证文件')
    doc=folder/'SKILL.md'
    if doc.is_symlink() or not doc.is_file() or doc.stat().st_size>1000000:
        raise ValueError('无效SKILL.md')
    meta=_parse_skill(doc)
    dest=SKILLS_DIR/meta['name']
    if dest.exists():
        raise FileExistsError('同名Skill已存在，请先备份；不会覆盖')
    with tempfile.TemporaryDirectory(dir=SKILLS_DIR) as d:
        stage=Path(d)/meta['name']
        stage.mkdir()
        shutil.copyfile(doc,stage/'SKILL.md')
        refs=folder/'references'
        if refs.is_dir() and not refs.is_symlink():
            for f in refs.rglob('*'):
                if f.is_symlink() or not f.is_file() or refs.resolve() not in f.resolve().parents:
                    continue
                if f.suffix.lower() not in {'.md','.txt','.json','.csv'} or f.stat().st_size>1000000:
                    continue
                target=stage/'references'/f.relative_to(refs)
                target.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(f,target)
        shutil.copyfile(license_file,stage/'LICENSE.upstream')
        (stage/'SOURCE.json').write_text(json.dumps({
            'source':source,'commit':revision,'user_reviewed_license_and_content':True,
            'mode':'documentation_only','scripts_enabled':False},ensure_ascii=False,indent=2),encoding='utf-8')
        stage.rename(dest)
    return dest

if __name__=='__main__':
    p=argparse.ArgumentParser(description='Import reviewed local Skill docs only')
    p.add_argument('folder')
    p.add_argument('--source',required=True)
    p.add_argument('--revision',required=True)
    p.add_argument('--license-file',required=True)
    p.add_argument('--reviewed',action='store_true')
    a=p.parse_args()
    if not a.reviewed:
        p.error('请先人工审查许可证、原文、适用范围和潜在提示注入，然后使用 --reviewed')
    print(install(a.folder,a.source,a.revision,a.license_file))
