const $ = (id) => document.getElementById(id);
let sessionId = null;
let currentFileId = null;
let currentFileName = null;
let busy = false;
let reportVersions = []; // immutable local Agent report references, newest last
let displayedReportId = null;
let resumeGoal = '';

function updateReviewButton() {
  const label = $("sendBtn")?.querySelector("span");
  if (!label) return;
  label.textContent = busy ? "处理中" : (resumeGoal ? "继续未完成评测" : reportVersions.length ? "继续评测" : "开始评测");
  if ($("messageInput") && !busy) {
    $("messageInput").placeholder = resumeGoal ? "留空继续原任务；输入新要求则按新目标评测。" : reportVersions.length
      ? "看完报告后，在这里补充设计要求或纠正结论，继续基于原模型评测……"
      : "描述模型设计要求；不填写也可直接开始评测……";
  }
}


function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2800);
}

function addMessage(role, text, label) {
  $("welcomeBlock")?.remove();
  const row = document.createElement("div");
  row.className = "message-row " + role;
  const avatar = document.createElement("div");
  avatar.className = "message-avatar";
  avatar.textContent = role === "user" ? "我" : "C";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  row.appendChild(avatar);
  row.appendChild(bubble);
  $("messages").appendChild(row);
  $("messages").scrollTop = $("messages").scrollHeight;
}


// All text comes from actual model output or local work records. DOM text
// nodes are used instead of injecting model-generated HTML.
function element(tag,cls,text) {
  const el=document.createElement(tag);
  if(cls) el.className=cls;
  if(text!==undefined) el.textContent=String(text);
  return el;
}
function appendMarkdownText(el,text) {
  // Minimal, safe Markdown formatting for headings, paragraphs, bullets and
  // emphasis; code/other syntax remains literal in the complete original.
  String(text||"").split(/\n/).forEach(line=>{
    if(!line.trim())return;
    const m=line.match(/^(#{1,4})\s+(.*)$/);
    const item=element(m?"h"+Math.min(5,m[1].length+2):"p","report-line");
    let content=m?m[2]:line.replace(/^[-*]\s+/,"• ");
    content.split(/(\*\*[^*]+\*\*)/).forEach(part=>{
      if(part.startsWith("**")&&part.endsWith("**")) item.append(element("strong","",part.slice(2,-2)));
      else item.append(document.createTextNode(part));
    });
    el.append(item);
  });
}
function addReviewResult(state,raw,reportId) {
  $("welcomeBlock")?.remove();
  const row=element("div","message-row assistant");
  row.append(element("div","message-avatar","C"));
  const box=element("div","bubble review-result");
  const completed=state.execution==="completed";
  const rows=Array.isArray(state.findings)?state.findings:[];
  const conflicts=rows.filter(x=>x.status==="contradicted");
  const other=rows.filter(x=>x.status!=="contradicted");
  const header=element("div","review-result-header");
  header.append(element("strong","",completed?"工程评测结果":"阶段成果 · 本轮已结束"));
  const stateText=completed?(state.coverage?.review_status==="partial"?"部分验证":"已返回报告"):"未完成全部评测";
  header.append(element("span","review-state-label",stateText));
  box.append(header);
  box.append(element("p","review-result-meta",`${conflicts.length} 项条件矛盾 · ${state.evidence_count||0} 条本地证据`));
  if(!completed && state.stop_reason)box.append(element("p","review-stop",state.stop_reason));
  const truncated=state.coverage?.truncated_readings||[];
  if(truncated.length)box.append(element("p","review-stop",`几何阅读正文截断 ${truncated.length} 包：${truncated.join("、")}。原始字段已送达，但阅读尚不完整。`));
  const statusLabels={contradicted:"条件不成立",supported:"条件支持",insufficient:"未验证",not_applicable:"不适用"};
  function card(f){
    const c=element("section","review-issue");
    c.append(element("span","review-issue-status",statusLabels[f.status]||f.status));
    c.append(element("h4","review-issue-title",f.title||f.condition));
    if(f.location)c.append(element("p","review-location",`位置：${f.location}`));
    if(f.consequence)c.append(element("p","review-consequence",f.consequence));
    if(f.recommendation)c.append(element("p","review-recommendation",`建议：${f.recommendation}`));
    const d=element("details","review-evidence");
    d.append(element("summary","","完整条件与证据"));
    d.append(element("p","",f.condition||""));
    d.append(element("p","",f.basis==="user_requirement"?"依据：用户明确要求":"依据：用途假设下的条件"));
    d.append(element("p","",f.reasoning||""));
    d.append(element("p","",`证据：${(f.evidence_ids||[]).join("、")}`));
    c.append(d);return c;
  }
  conflicts.forEach(f=>box.append(card(f)));
  if(other.length){
    const d=element("details","review-evidence");
    d.append(element("summary","",`其他 ${other.length} 项判断与未验证条件`));
    other.forEach(f=>d.append(card(f)));box.append(d);
  }
  if(raw){
    const d=element("details","review-original");
    d.open=rows.length===0;
    d.append(element("summary","",completed?"查看模型完整报告":"查看停止说明"));
    const body=element("div","review-original-text");appendMarkdownText(body,raw);d.append(body);box.append(d);
  }
  if(reportId){
    const a=element("a","review-download","下载完整报告 Markdown");
    a.href="/api/reports/"+encodeURIComponent(reportId)+"/download/markdown";box.append(a);
  }
  if(state.stage_download_url){
    const stage=element("a","review-download","下载阶段成果及模型实际输出");
    stage.href=state.stage_download_url;box.append(stage);
  }
  box.append(element("p","review-result-meta","记录状态不是整体验收；用途假设及未验证范围见实际报告或证据。"));
  row.append(box);$("messages").append(row);$("messages").scrollTop=$("messages").scrollHeight;
}
async function localRead(url,timeout=4000) {
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),timeout);
  try {
    const response=await fetch(url,{cache:"no-store",signal:controller.signal});
    if(!response.ok)return null;
    return await response.json();
  } finally {clearTimeout(timer);}
}

// This panel shows observable Agent actions, not private/unavailable model thoughts.
function newTraceId() {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, b => b.toString(16).padStart(2, "0")).join("");
}

function renderTaskChecklist(container, state, archived = false) {
  if (!container) return;
  container.replaceChildren();
  if (!state || !Array.isArray(state.nodes)) {
    container.classList.add("hidden");
    return;
  }
  if(state.schema==="cavai-harness-work-2"){
    container.classList.remove("hidden");
    const h=element("div","task-checklist-header");
    h.append(element("strong","",archived?"已保存工程成果":"持续工程评测"));
    h.append(element("span","",`${state.findings?.length||0} 项判断 · ${state.evidence_count||0} 条证据`));
    container.append(h);
    const c=state.coverage||{};
    container.append(element("p","task-caption",`窗口已返回 ${c.received||0}/${c.total||0} · 自然完成 ${c.read||0} · 当前 ${state.current_unit||"准备"}`));
    const important=(state.findings||[]).filter(f=>f.status==="contradicted");
    important.slice(0,3).forEach(f=>{
      const item=element("div","review-issue");
      item.append(element("strong","",f.title));
      item.append(element("p","review-consequence",f.consequence||""));
      container.append(item);
    });
    if(state.output_count){
      const d=element("details","review-evidence");
      d.append(element("summary","",`实际模型输出 ${state.output_count} 条 · 最近结果`));
      for(const row of state.recent_outputs||[]){
        d.append(element("strong","",row.unit_id));
        d.append(element("p","",row.text+(row.truncated?"…［完整原文见阶段成果］":"")));
      }
      container.append(d);
    }
    if(state.stage_save_error)container.append(element("p","review-consequence",state.stage_save_error));
    if(state.stage_download_url){
      const a=element("a","review-download","下载已取得的阶段成果");
      a.href=state.stage_download_url;container.append(a);
    }
    return;
  }
  if(state.schema==="cavai-harness-work-1"){
    container.classList.remove("hidden");
    const h=element("div","task-checklist-header");
    h.append(element("strong","",archived?"已保存工作记忆":"本轮工程工作"));
    h.append(element("span","",`${state.findings?.length||0} 项判断 · ${state.evidence_count||0} 条证据`));
    container.append(h);
    const c=state.coverage||{};
    container.append(element("p","task-caption",`几何输入 ${c.read||0}/${c.total||0} · 已复用读取 ${c.reused_readings||0} · 运行状态 ${state.execution==="running"?"执行中":state.execution==="completed"?"已结束":"已停止"}`));
    return;
  }
  container.classList.remove("hidden");
  const header = document.createElement("div");
  header.className = "task-checklist-header";
  const title = document.createElement("strong");
  title.textContent = archived ? "上次评测任务清单" : "本轮动态评测任务";
  const count = document.createElement("span");
  count.textContent = `${state.reviewed || 0} / ${state.total || 0} 已检查`;
  header.append(title, count);
  container.append(header);
  const caption = document.createElement("p");
  caption.className = "task-caption";
  caption.textContent = "任务由 Agent 按当前模型和要求登记；勾选仅代表已有证据的检查记录，不代表设计合格。";
  container.append(caption);
  if (!state.nodes.length) {
    const empty = document.createElement("p");
    empty.className = "task-caption";
    empty.textContent = state.audit ? "本轮未建立动态检查节点。" : "等待 Agent 登记适用的检查任务…";
    container.append(empty);
  }
  const legend = {pending:["○","待执行"],active:["◌","进行中"],reviewed:["✓","已检查"],
    blocked:["!","未完成 / 受阻"],not_applicable:["–","不适用"],needs_review:["○","待复核"]};
  for (const task of state.nodes) {
    const [mark, label] = legend[task.status] || ["○","未知状态"];
    const row = document.createElement("div");
    row.className = "task-node task-" + (legend[task.status] ? task.status : "pending");
    const icon = document.createElement("span");
    icon.className = "task-node-icon";
    icon.textContent = mark;
    const body = document.createElement("div");
    body.className = "task-node-body";
    const name = document.createElement("strong");
    name.textContent = `${task.id} · ${task.title}`;
    const criterion = document.createElement("small");
    criterion.textContent = task.criterion || "";
    body.append(name, criterion);
    if (task.note) {
      const note = document.createElement("small");
      note.textContent = task.note;
      body.append(note);
    }
    if (Array.isArray(task.evidence_ids) && task.evidence_ids.length) {
      const refs = document.createElement("small");
      refs.className = "task-evidence";
      refs.textContent = "证据：" + task.evidence_ids.join("、");
      body.append(refs);
    }
    const tag = document.createElement("span");
    tag.className = "task-node-status";
    tag.textContent = label;
    row.append(icon, body, tag);
    container.append(row);
  }
  if (state.audit) {
    const audit = document.createElement("p");
    audit.className = "task-audit";
    audit.textContent = state.audit.complete
      ? "自检：本轮已登记的任务均已处理，证据引用与依赖有效。"
      : `自检：${(state.audit.issues || []).length} 项待解决或未覆盖；保留实际状态。`;
    container.append(audit);
  }
}

function createTracePanel(mode,traceId) {
  const details = document.createElement("details");
  details.className = "analysis-trace";
  details.open = true;
  const heading = document.createElement("summary");
  heading.textContent = mode === "intent" ? "用途识别过程 · 正在运行" : "Agent 分析过程 · 正在运行";
  const note = document.createElement("p");
  note.className = "trace-note";
  note.textContent = "实时展示本地几何解析、Skill / 工具调用和 API 请求。模型未公开的内部思维不会伪造显示。";
  const list = document.createElement("ol");
  list.className = "trace-steps";
  const tasks = document.createElement("div");
  tasks.className = "task-checklist hidden";
  const usage=element("p","trace-note");
  const waiting=element("p","trace-note");
  const stop=element("button","review-state-label","停止本轮");
  stop.type="button";
  stop.addEventListener("click",async()=>{
    stop.disabled=true;
    try{
      const response=await fetch("/api/runs/"+traceId+"/stop",{method:"POST"});
      if(!response.ok)throw new Error("当前运行未就绪或已结束");
      stop.textContent="已请求停止";
    }catch(error){stop.disabled=false;toast(error.message);}
  });
  let lastUsage="";
  details.append(heading,note,waiting,stop,tasks,list,usage);
  $("messages").appendChild(details);
  $("messages").scrollTop = $("messages").scrollHeight;
  return {
    renderTasks(state) { renderTaskChecklist(tasks, state); },
    finish(status) {
      heading.textContent="Agent 分析过程 · "+(status==="completed"?"已完成":status==="partial"?"部分完成":status==="unknown"?"连接状态待确认":"已结束");
      stop.disabled=true;waiting.textContent="";
      details.open=false;
    },
    renderUsage(u) {
      if(!u)return;
      usage.textContent=`API ${u.calls||0} 次 · 输入 ${fmtNum(u.prompt_tokens||0)} / 输出 ${fmtNum(u.completion_tokens||0)} Token · 缓存输入 ${fmtNum(u.cached_input_tokens||0)} · 本地证据复用 ${u.local_geometry_cache_hits||0} 次 · 追踪ID ${u.turn_id||""}`;
    },
    render(snapshot) {
      if(snapshot.pending_request){
        const p=snapshot.pending_request;
        waiting.textContent=`正在等待第 ${p.round} 次 API 响应 · ${p.unit_id} · 已等待 ${p.elapsed_seconds} 秒`;
      }else waiting.textContent=snapshot.stop_requested?"正在结束本地运行":"当前无等待中的 API 请求";
      if(snapshot.usage){
        this.renderUsage(snapshot.usage);
        const tag=JSON.stringify([snapshot.usage.calls,snapshot.usage.successful_requests,snapshot.usage.failed_requests,snapshot.usage.prompt_tokens,snapshot.usage.completion_tokens]);
        if(tag!==lastUsage){lastUsage=tag;refreshUsageMini();}
      }
      stop.disabled=Boolean(snapshot.done||snapshot.stop_requested);
      if (snapshot.task_state) renderTaskChecklist(tasks, snapshot.task_state);
      const items = Array.isArray(snapshot.events) ? snapshot.events : [];
      list.replaceChildren();
      items.forEach(item => {
        const row = document.createElement("li");
        row.className = "trace-step trace-" + (item.kind || "step");
        const label = document.createElement("strong");
        label.textContent = item.label || "分析中";
        row.appendChild(label);
        if (item.detail) {
          const detail = document.createElement("small");
          detail.textContent = item.detail;
          row.appendChild(detail);
        }
        list.appendChild(row);
      });
      if (snapshot.done) {
        heading.textContent = snapshot.status === "completed"
          ? "Agent 分析过程 · 已完成" : snapshot.status === "partial"
          ? "Agent 分析过程 · 部分完成" : "Agent 分析过程 · 已停止";
        details.open=false;
      }
      $("messages").scrollTop = $("messages").scrollHeight;
    }
  };
}

function showAutoView(fileId, enabled) {
  const el = $("autoViewLink");
  const image = $("autoViewImage");
  if (!el || !image) return;
  if (!fileId || !enabled) {
    el.classList.add("hidden");
    image.removeAttribute("src");
    return;
  }
  const url = "/api/models/" + encodeURIComponent(fileId) + "/preview";
  el.href = url;
  image.src = url;
  image.onerror = () => el.classList.add("hidden");
  el.classList.remove("hidden");
}

function setBusy(value) {
  busy = value;
  $("sendBtn").disabled = value;
  $("recognizeBtn").disabled = value;
  $("localPreviewBtn").disabled = value;
  updateReviewButton();
}

function setStep(index, state) {
  const steps = [...$("steps").querySelectorAll(".step")];
  if (!steps[index]) return;
  steps[index].classList.remove("active", "done");
  if (state) steps[index].classList.add(state);
  steps[index].querySelector("i").textContent = state === "done" ? "✓" : state === "active" ? "◌" : "○";
}

function resetSteps() {
  [...$("steps").querySelectorAll(".step")].forEach((step) => {
    step.classList.remove("active", "done");
    step.querySelector("i").textContent = "○";
  });
  $("reportPreview").classList.add("hidden");
}

function showUpload(file) {
  $("uploadPreview").classList.remove("hidden");
  $("uploadedName").textContent = file.name;
  $("uploadedMeta").textContent = "正在上传到本地工作空间…";
  $("emptyModel").classList.add("hidden");
  $("modelCard").classList.remove("hidden");
  $("sideFileName").textContent = file.name;
  $("sideFileSize").textContent = formatBytes(file.size);
  $("fileType").textContent = file.name.split(".").pop().toUpperCase();
  $("modelState").textContent = "正在上传";
  $("geometryJsonLink")?.classList.add("hidden");
  $("geometryJsonPreview")?.classList.add("hidden");
}

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / 1024 / 1024).toFixed(1) + " MB";
}


function toggleLimits() {
  const enabled = $("limitsEnabled").checked;
  $("limitsFields").classList.toggle("hidden", !enabled);
  $("limitHint").textContent = enabled
    ? "已开启：超过设定的预估上限，就在发送前停止。"
    : "关闭：不设用户总预算上限；按真实几何关联持续评测，检测无进展重复调用。";
}
$("limitsEnabled").addEventListener("change", toggleLimits);

async function loadSettings() {
  try {
    const response = await fetch("/api/settings");
    const data = await response.json();
    $("apiBaseUrl").value = data.base_url || "https://api.deepseek.com";
    $("apiModel").value = data.model || "deepseek-flash";
    $("limitsEnabled").checked = data.limits_enabled === true;
    $("visionMode").value = data.vision_mode || "auto";
    $("contextWindowTokens").value = data.context_window_tokens || 0;
    $("maxOutputTokens").value = data.max_output_tokens || 0;
    if(data.effective_max_output_tokens) $("outputCapacityHint").textContent =
      `当前实际允许输出 ${fmtNum(data.effective_max_output_tokens)} Token。0 为自动；可按服务商能力调整，非实际消耗。`;
    $("maxRequests").value = data.max_requests ?? 8;
    $("maxTurnTokens").value = data.max_turn_est_tokens ?? 90000;
    toggleLimits();
    $("apiKey").value = "";
    $("apiKey").placeholder = data.api_key_configured
      ? "密钥已保存；留空不更换" : "粘贴 DeepSeek 官方 API Key";
    $("settingsNote").textContent = data.configured
      ? "API 已配置：" + (data.api_key_masked || "密钥已保存")
      : "未配置 API。填入官方 API Key，然后保存即可。";
    $("apiStatus").textContent = data.configured ? "模型 API 已配置" : "尚未配置模型 API";
  } catch (error) {
    $("settingsNote").textContent = "读取设置失败：" + error.message;
  }
}

function openSettings() {
  $("settingsModal").classList.remove("hidden");
  loadSettings();
}
function closeSettings() {
  $("settingsModal").classList.add("hidden");
}
$("presetDeepSeekOfficial").addEventListener("click", () => {
  $("apiBaseUrl").value = "https://api.deepseek.com";
  $("apiModel").value = "deepseek-flash";
  $("settingsNote").style.color = "";
  $("settingsNote").textContent = "已选择 DeepSeek 官方配置。填写官方 API Key 并保存即可（此按钮不会发起收费调用）。";
});
$("settingsBtn").addEventListener("click", openSettings);
$("settingsTopBtn").addEventListener("click", openSettings);
$("closeSettings").addEventListener("click", closeSettings);
$("settingsModal").addEventListener("click", (event) => {
  if (event.target === $("settingsModal")) closeSettings();
});

function settingsPayload() {
  return {
    base_url: $("apiBaseUrl").value.trim(),
    api_key: $("apiKey").value.trim(),
    model: $("apiModel").value.trim(),
    limits_enabled: $("limitsEnabled").checked,
    vision_mode: $("visionMode").value,
    context_window_tokens: Number($("contextWindowTokens").value || 0),
    max_output_tokens: Number($("maxOutputTokens").value || 0),
    max_requests: Number($("maxRequests").value),
    max_turn_est_tokens: Number($("maxTurnTokens").value)
  };
}

$("saveApiBtn").addEventListener("click", async () => {
  const payload = settingsPayload();
  $("settingsNote").textContent = "正在保存……";
  $("saveApiBtn").disabled = true;
  try {
    const response = await fetch("/api/settings", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "保存失败");
    $("apiKey").value = "";
    $("settingsNote").textContent = "✓ API设置已保存在本机。可以开始上传模型并评测。";
    $("settingsNote").style.color = "#21845b";
    $("apiStatus").textContent = "模型API 已配置";
    toast("API设置已保存");
    await loadSettings();
  } catch (error) {
    $("settingsNote").textContent = "保存失败：" + error.message;
    $("settingsNote").style.color = "#b54e45";
  } finally {
    $("saveApiBtn").disabled = false;
  }
});

$("fileInput").addEventListener("change", async (event) => {
  const file = event.target.files[0];
  if (!file) return;
  showUpload(file);
  const form = new FormData();
  form.append("file", file);
  try {
    const response = await fetch("/api/upload", { method: "POST", body: form });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "上传失败");
    // A newly uploaded CAD model must start a new workspace, not overwrite an older report.
    sessionId = null;
    reportVersions = [];
    resumeGoal = '';
    displayedReportId = null;
    $("messages").replaceChildren();
    resetSteps();
    renderVersionButtons();
    updateReviewButton();
    currentFileId = data.file_id;
    showAutoView(null, false);
    currentFileName = data.filename;
    $("uploadedMeta").textContent = `${data.model_type} · 已保存到本机`;
    $("modelState").textContent = "已上传，等待评测";
    toast("模型已上传。可以描述设计目标，也可以直接发送“请先分析模型”。");
  } catch (error) {
    currentFileId = null;
    $("modelState").textContent = "上传失败";
    toast(error.message);
  }
});

$("removeFile").addEventListener("click", () => {
  currentFileId = null;
  currentFileName = null;
  sessionId = null;
  reportVersions = [];
  resumeGoal = '';
  displayedReportId = null;
  renderVersionButtons();
  updateReviewButton();
  showAutoView(null, false);
  $("uploadPreview").classList.add("hidden");
  $("modelCard").classList.add("hidden");
  $("geometryJsonLink")?.classList.add("hidden");
  $("geometryJsonPreview")?.classList.add("hidden");
  $("emptyModel").classList.remove("hidden");
  $("fileInput").value = "";
});

async function sendMessage(textOverride, mode = "review") {
  if (busy) return;
  // Once an actual Agent report exists, the regular Send button performs
  // an incremental review using that report, not a fresh unrelated run.
  if (mode === "review" && sessionId && reportVersions.length) mode = "continue";
  const text = (textOverride || $("messageInput").value || (mode !== "intent" ? resumeGoal : "")).trim();
  if (mode === "continue" && !text) {
    toast("请先输入对上一轮报告的补充或修改要求；避免空白续评产生费用。");
    return;
  }
  if (!text && !currentFileId) {
    toast("请先输入消息或上传CAD模型。");
    return;
  }
  const message = text || "[未提供设计要求] 请自主判断最可能的用途，评测模型的几何、结构和功能，明确已发现的问题、依据、改进方案及未验证范围。";
  addMessage("user", (mode === "intent" ? "【识别模型用途】" : mode === "continue" ? "【继续评测】" : "【开始工程评测】") + message);
  $("messageInput").value = "";
  setBusy(true);
  const traceId = newTraceId();
  const tracePanel = createTracePanel(mode,traceId);
  let polling=false,closed=false,outcome="unknown";
  let resolveTerminal;
  const terminal=new Promise(resolve=>{resolveTerminal=resolve;});
  const postController=new AbortController();
  async function readProgress() {
    if(polling||closed)return;
    polling=true;
    try {
      const snapshot=await localRead("/api/runs/"+traceId+"/events");
      if(closed||!snapshot)return;
      tracePanel.render(snapshot);
      if(snapshot.done){
        const data=await localRead("/api/runs/"+traceId+"/result");
        if(!closed&&data)resolveTerminal({ok:true,data});
      }
    } catch (_) {} finally {polling=false;}
  }
  const traceTimer=setInterval(readProgress,900);
  // A continuation must keep the previous report visible even if the new API
  // run fails. The old version is immutable and available in the version list.
  if (mode !== "continue") resetSteps();
  setStep(0, "done");
  setStep(1, mode === "continue" ? "done" : "active");

  try {
    const post=fetch("/api/chat",{
      method:"POST",headers:{"Content-Type":"application/json"},
      signal:postController.signal,
      body:JSON.stringify({session_id:sessionId,message,file_id:currentFileId,mode,trace_id: traceId})
    }).then(async response=>({ok:response.ok,data:await response.json()}));
    const received=await Promise.race([post,terminal]);
    const data=received.data;
    if(!received.ok)throw new Error(data.detail||"请求失败");
    outcome=data.usage?.status||"completed";
    sessionId = data.session_id;
    if (mode !== "intent") resumeGoal = data.resume_goal || "";
    if (data.task_state) tracePanel.renderTasks(data.task_state);
    reportVersions = Array.isArray(data.report_versions) ? data.report_versions : reportVersions;
    renderVersionButtons();
    updateReviewButton();
    setStep(0, "done");
    const geometryOk = data.inspection?.status === "ok" && data.inspection?.geometry?.status === "ok";
    if (geometryOk) setStep(1, "done");
    else setStep(1, "");
    const calledSkill = (data.tool_trace || []).some(item => item.tool === "load_skill" && item.ok);
    const lookedAtFacts = (data.tool_trace || []).some(item =>
      ["read_geometry","read_global_geometry","read_entity","search_geometry","measure_box_occupancy","classify_model_point","measure_cylinder_occupancy"].includes(item.tool) && item.ok);
    if (calledSkill) setStep(2, "done");
    if (data.task_state ? data.task_state.audit?.complete : (calledSkill && lookedAtFacts)) setStep(3, "done");
    if (data.report_id) setStep(4, "done");
    if(["cavai-harness-work-1","cavai-harness-work-2"].includes(data.review_result?.schema))
      addReviewResult(data.review_result,data.reply,data.report_id);
    else addMessage("assistant",data.reply);
    if (data.loaded_skills && data.loaded_skills.length) {
      toast("已从本地加载评测 Skill：" + data.loaded_skills.join("、"));
    }
    // Tools and geometry evidence are shown in the expandable live execution trace.
    // Do not repeat a long sequence of tool names as a chat bubble.
    if (data.inspection) {
      const geometry = data.inspection.geometry;
      if (data.inspection.status !== "ok") {
        showAutoView(null, false);
        $("modelState").textContent = "CATIA读取失败：" + (data.inspection.error || "请查看检查详情");
        $("geometryJsonLink")?.classList.add("hidden");
  $("geometryJsonPreview")?.classList.add("hidden");
      } else if (geometry && geometry.status === "ok") {
        $("modelState").textContent =
          "B-Rep解析成功 · Body " + (geometry.catia_body_count ?? (data.inspection.document_type === "CATPRODUCT" ? "装配" : "?")) +
          " · Solid " + geometry.solid_count +
          " · Face " + geometry.face_count +
          " · Edge " + geometry.edge_count +
          " · 孔候选 " + geometry.hole_candidate_count +
          " · 结构区域 " + (geometry.structure_feature_count ?? "?") +
          " · 结构关系 " + (geometry.structure_relation_count ?? "?");
        showAutoView(currentFileId, geometry.auto_view_available);
        if ($("geometryJsonLink") && currentFileId) {
          $("geometryJsonLink").href = "/api/models/" + encodeURIComponent(currentFileId) + "/geometry";
          $("geometryJsonLink").classList.remove("hidden");
          showGeometryJson(currentFileId);
        }
      } else if (geometry) {
        showAutoView(null, false);
        $("modelState").textContent = "CATIA已读取，但B-Rep解析失败：" + (geometry.error || "未知错误");
        $("geometryJsonLink")?.classList.add("hidden");
  $("geometryJsonPreview")?.classList.add("hidden");
      } else {
        $("modelState").textContent = "CATIA读取成功（基础信息）";
      }
    }
    if (data.report) {
      displayedReportId = data.report.report_id;
      renderReport(data.report);
      renderVersionButtons();
      toast("已保存 Agent 报告 V" + (data.report_version || reportVersions.length));
    }
    if (data.usage) {
      tracePanel.renderUsage(data.usage);
      refreshUsageMini();
    }
    if (data.provider === "local_geometry_block") toast("CAD 解析未完成，未调用付费 API。");
    if (data.history_save_error) addMessage("assistant", "注意：本次Agent报告已返回，但本地历史保存不完整：" + data.history_save_error + "。请及时下载报告。");
    if (data.evidence_save_error) addMessage("assistant", "注意：本地几何证据保存失败：" + data.evidence_save_error);
    if (data.provider === "api_error") toast("模型API调用失败，已记录账本；请核对服务商账单。");
  } catch (error) {
    addMessage("assistant", "本次请求未完成：" + error.message);
    toast(error.message);
  } finally {
    closed=true;
    clearInterval(traceTimer);
    postController.abort();
    tracePanel.finish(outcome);
    setBusy(false);
  }
}

$("localPreviewBtn").addEventListener("click", async () => {
  if (busy) return;
  if (!currentFileId) { toast("请先上传CATPart、CATProduct或STEP模型"); return; }
  setBusy(true);
  try {
    const response = await fetch("/api/models/" + encodeURIComponent(currentFileId) + "/summary", {cache:"no-store"});
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "本地解析失败");
    const g = data.inspection?.geometry;
    if (g?.status === "ok") {
      $("modelState").textContent = `本地解析完成 · Solid ${g.solid_count} · Face ${g.face_count} · 圆柱/平面等结构区域 ${g.structure_feature_count} · 关系 ${g.structure_relation_count}`;
      showAutoView(currentFileId, g.auto_view_available);
      if ($("geometryJsonLink")) {
        $("geometryJsonLink").href = "/api/models/" + encodeURIComponent(currentFileId) + "/geometry";
        $("geometryJsonLink").classList.remove("hidden");
          showGeometryJson(currentFileId);
      }
      addMessage("assistant", `本地几何解析成功：${g.structure_feature_count} 个几何结构区域、${g.structure_relation_count} 条邻接/同轴关系。${g.auto_view_available ? "右侧已显示自动生成的四视图。" : "自动四视图不可用，仍可以查看几何JSON。"}本次没有调用模型API，也没有消耗Token。`);
      setStep(0,"done");setStep(1,"done");
    } else {
      $("modelState").textContent = "本地解析未完成：" + (g?.error || data.inspection?.error || "未知原因");
      toast("本地模型解析失败，未调用收费API");
    }
  } catch (error) { toast(error.message); }
  finally { setBusy(false); }
});

$("recognizeBtn").addEventListener("click", () => sendMessage(undefined, "intent"));
$("viewInput").addEventListener("change", async event => {
  const file = event.target.files[0];
  if (!file) return;
  if (!currentFileId) { toast("请先上传CAD模型，再上传可选视图"); return; }
  const form = new FormData(); form.append("file", file);
  try {
    const response = await fetch("/api/models/" + encodeURIComponent(currentFileId) + "/view", {method: "POST", body: form});
    const info = await response.json();
    if (!response.ok) throw new Error(info.detail || "视图上传失败");
    toast(info.vision_usable ? "视图已存本机；评测时与JSON一起发送" : "视图已存本机；当前API视觉能力未知，将仅发送文本证据");
  } catch (error) { toast(error.message); }
});

$("sendBtn").addEventListener("click", () => sendMessage());
$("messageInput").addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
});
$("messageInput").addEventListener("input", function () {
  this.style.height = "auto";
  this.style.height = Math.min(this.scrollHeight, 120) + "px";
});
document.querySelectorAll(".suggestion").forEach((button) => {
  button.addEventListener("click", () => sendMessage(button.dataset.prompt));
});

function renderReport(report) {
  if (!report) return;
  displayedReportId = report.report_id || null;
  $("reportPreview").classList.remove("hidden");
  const labels = {fail:"已登记不符合项",conditional_conflict:"存在条件性功能矛盾",inconclusive:"未作整体验收结论",pass:"评测通过",partial:"部分完成"};
  $("verdictText").textContent = labels[report.overall_status] || "已生成评测报告";
  $("verdictNote").textContent = report.report_status === "partial" ? "取证过程未全部完成" : "报告已保存，流程完成不代表整体合格";
  const list = $("findingList");
  list.replaceChildren();
  const pre = document.createElement("pre");
  pre.className = "engineering-json";
  pre.textContent = JSON.stringify({
    overall_status:report.overall_status, report_status:report.report_status,
    finding_count:(report.engineering_findings || report.findings || []).length,
    evidence_count:report.task_state?.evidence_count ?? (report.queried_evidence_ids || []).length,
    geometry_coverage:report.task_state?.coverage || {},
    skill_names:report.actual_skill_names || []
  }, null, 2);
  list.append(pre);
}
async function showGeometryJson(fileId) {
  const panel = $("geometryJsonPreview");
  if (!panel) return;
  panel.textContent = "";
  panel.classList.add("hidden");
  if (!fileId) return;
  try {
    const response = await fetch("/api/models/"+encodeURIComponent(fileId)+"/geometry?summary=true", {cache:"no-store"});
    if (!response.ok) return;
    const geo = await response.json();
    if (currentFileId !== fileId) return;
    const {solid_count,face_count,edge_count,hole_candidate_count,bounding_box_mm,face_type_counts} = geo;
    const graph = geo.feature_graph || {};
    const extraction = geo.extraction || {status:"base_fields_only"};
    const link = $("geometryJsonLink");
    if (link) {
      link.href = "/api/models/" + encodeURIComponent(fileId) + "/geometry/download";
      link.textContent = "下载本地完整结构化 JSON";
    }
    panel.textContent = JSON.stringify({solid_count,face_count,edge_count,hole_candidate_count,bounding_box_mm,
      face_type_counts,structure_feature_count:graph.feature_count,structure_relation_count:graph.relation_count,
      extraction,local_rules:geo.local_rules || []},null,2);
    panel.classList.remove("hidden");
  } catch (error) { /* The existing full-JSON link remains available. */ }
}
function openReportReader(report) {
  const modal = $("reportReaderModal");
  const item = reportVersions.find(x=>x.report_id===report.report_id);
  $("reportReaderTitle").textContent = item ? "评测报告 V"+item.version : "评测报告";
  $("reportReaderBody").textContent = report.markdown_report || report.summary || "";
  $("reportReaderDownload").href = "/api/reports/"+encodeURIComponent(report.report_id)+
      (report.markdown_report ? "/download/markdown" : "/download");
  modal.classList.remove("hidden");
  $("closeReportReader").focus();
}
$("closeReportReader").addEventListener("click",()=> $("reportReaderModal").classList.add("hidden"));
$("reportReaderModal").addEventListener("click",e=> {
  if (e.target === $("reportReaderModal")) $("reportReaderModal").classList.add("hidden");
});
document.addEventListener("keydown",e=> {
  if (e.key==="Escape") $("reportReaderModal").classList.add("hidden");
});

// Historical reports never trigger API requests. Switching reports is a local GET.
function renderVersionButtons() {
  const box = $("reportVersions");
  const list = $("reportVersionButtons");
  if (!box || !list) return;
  list.replaceChildren();
  box.classList.toggle("hidden", reportVersions.length === 0);
  reportVersions.forEach(item => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "version-pill" + (displayedReportId === item.report_id ? " selected" : "");
    button.textContent = "V" + item.version;
    button.title = "查看第 " + item.version + " 版 Agent 评测报告";
    button.addEventListener("click", () => viewReportVersion(item.report_id));
    list.appendChild(button);
  });
  $("reportVersionHint").textContent = reportVersions.length
    ? "已保存 " + reportVersions.length + " 个版本；继续评测基于最新的 V" + reportVersions.length + "，旧报告不会覆盖。"
    : "";
}

async function viewReportVersion(reportId, openReader = true) {
  if (!reportId) return;
  try {
    const resp = await fetch("/api/reports/" + encodeURIComponent(reportId), {cache: "no-store"});
    const report = await resp.json();
    if (!resp.ok) throw new Error(report.detail || "报告不存在");
    renderReport(report);
    renderVersionButtons();
    if (openReader) openReportReader(report);
  } catch (error) { toast("打开报告失败：" + error.message); }
}

function restoreWorkspaceMessages(messages) {
  $("messages").replaceChildren();
  (messages || []).forEach(item => {
    if (item.role === "user" || item.role === "assistant")
      if(item.role==="assistant"&&["cavai-harness-work-1","cavai-harness-work-2"].includes(item.review_result?.schema))
        addReviewResult(item.review_result,item.content,item.report_id);
      else addMessage(item.role, String(item.content || ""));
  });
  if (!messages?.length) $("messages").appendChild(createWelcome());
}

async function restoreWorkspace(id) {
  if (busy) { toast("请先完成当前评测"); return; }
  try {
    const response = await fetch("/api/history/" + encodeURIComponent(id), {cache: "no-store"});
    const state = await response.json();
    if (!response.ok) throw new Error(state.detail || "历史记录不存在");
    sessionId = state.session_id;
    currentFileId = state.model_available ? state.file_id : null;
    currentFileName = state.filename;
    reportVersions = Array.isArray(state.reports) ? state.reports : [];
    resumeGoal = state.engineering_state?.stop_reason ? (state.engineering_state?.review_goal || "") : "";
    displayedReportId = state.current_report_id || null;
    restoreWorkspaceMessages(state.messages);
    if (state.engineering_state?.task_state) {
      const checklist = document.createElement("div");
      checklist.className = "task-checklist archived-tasks";
      renderTaskChecklist(checklist, state.engineering_state.task_state, true);
      $("messages").appendChild(checklist);
    }
    resetSteps();
    if (state.model_available) {
      showUpload({name: state.filename, size: state.model_size || 0});
      $("uploadedMeta").textContent = "已从本地评测历史恢复 · 免重复上传";
      $("modelState").textContent = "使用已有几何证据 · 不重复解析";
      showAutoView(currentFileId, !!state.preview_url);
      if ($("geometryJsonLink")) {
        $("geometryJsonLink").href = "/api/models/" + encodeURIComponent(currentFileId) + "/geometry";
        $("geometryJsonLink").classList.remove("hidden");
          showGeometryJson(currentFileId);
      }
      setStep(0, "done"); setStep(1, "done");
    } else {
      $("uploadPreview").classList.add("hidden");
      $("modelCard").classList.add("hidden");
      $("emptyModel").classList.remove("hidden");
      showAutoView(null, false);
      toast("原模型文件不在当前 data/ 目录；历史报告仍可查看，但暂不能续评。");
    }
    if (reportVersions.length) {
      setStep(2, "done"); if (state.engineering_state?.task_state?.audit?.complete) setStep(3, "done"); setStep(4, "done");
      await viewReportVersion(state.current_report_id, false);
    }
    renderVersionButtons();
    updateReviewButton();
    $("historyModal").classList.add("hidden");
    toast("已恢复本地评测历史。可继续补充信息并生成新版报告。");
  } catch (error) { toast("恢复历史失败：" + error.message); }
}

async function openHistoryModal() {
  if (busy) { toast("请先完成当前评测"); return; }
  $("historyModal").classList.remove("hidden");
  const list = $("historyList");
  list.textContent = "正在读取本地评测记录……";
  try {
    const response = await fetch("/api/history?limit=100", {cache: "no-store"});
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "读取历史失败");
    list.replaceChildren();
    if (!data.items?.length) {
      list.textContent = "尚无评测记录。上传模型并完成首次评测后，这里会自动保存。";
      return;
    }
    data.items.forEach(item => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "history-entry";
      const title = document.createElement("b");
      title.textContent = item.filename || item.title || "CAD 模型";
      const meta = document.createElement("small");
      meta.textContent = "报告 " + item.report_count + " 版 · " +
        fmtBeijing(item.updated_at).slice(0, 16) +
        (item.model_available ? " · 模型可用" : " · 模型文件缺失");
      button.append(title, meta);
      button.addEventListener("click", () => restoreWorkspace(item.session_id));
      list.appendChild(button);
    });
  } catch (error) { list.textContent = "历史读取失败：" + error.message; }
}
$("historyBtn").addEventListener("click", openHistoryModal);
$("refreshHistory").addEventListener("click", openHistoryModal);
$("closeHistory").addEventListener("click", () => $("historyModal").classList.add("hidden"));
$("historyModal").addEventListener("click", event => {
  if (event.target === $("historyModal")) $("historyModal").classList.add("hidden");
});

$("newChatBtn").addEventListener("click", () => {
  if (busy) { toast("请先完成当前评测"); return; }
  sessionId = null;
  currentFileId = null;
  currentFileName = null;
  reportVersions = [];
  resumeGoal = '';
  displayedReportId = null;
  renderVersionButtons();
  updateReviewButton();
  $("messages").innerHTML = "";
  $("messages").appendChild(createWelcome());
  $("uploadPreview").classList.add("hidden");
  $("modelCard").classList.add("hidden");
  $("geometryJsonLink")?.classList.add("hidden");
  $("geometryJsonPreview")?.classList.add("hidden");
  $("emptyModel").classList.remove("hidden");
  $("fileInput").value = "";
  resetSteps();
  toast("已创建新会话");
});

function createWelcome() {
  const wrap = document.createElement("div");
  wrap.className = "welcome-block";
  wrap.innerHTML = `<div class="welcome-mark"><img src="/static/brand_logo.png" alt=""></div>
  <div class="welcome-kicker">WELCOME TO CAVAI</div><h2>你的设计意图，由你定义。</h2>
  <p>上传 CATIA 模型并描述设计要求；也可以不输入要求，让 CAVAI 先分析模型并提出功能假设。</p>
  <div class="welcome-note">
    <span>01</span><div><b>你定义目标</b><small>不预设固定产品类型</small></div>
    <span>02</span><div><b>AI读取模型</b><small>依据实际可获取的CATIA数据</small></div>
    <span>03</span><div><b>证据驱动评测</b><small>区分已验证、未验证和不符合项</small></div>
  </div>`;
  return wrap;
}

$("apiStatus").textContent = "本地服务在线";
fetch("/api/health").then(r => r.json()).then(data => {
  $("apiStatus").textContent = data.llm_configured ? "模型API 已配置" : "尚未配置模型API";
}).catch(() => $("apiStatus").textContent = "服务连接异常");
loadSettings();



function fmtBeijing(value) {
  if (!value) return "-";
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return "-";
  return new Intl.DateTimeFormat("sv-SE", {timeZone:"Asia/Shanghai", year:"numeric",
    month:"2-digit", day:"2-digit", hour:"2-digit", minute:"2-digit", second:"2-digit",
    hourCycle:"h23"}).format(date);
}
function fmtNum(value) { return typeof value === "number" ? value.toLocaleString("zh-CN") : "未知"; }
function fmtCost(value) { return typeof value === "number" ? "￥" + value.toFixed(5) : "未知"; }
async function refreshUsageMini() {
  try {
    const response = await fetch("/api/usage/summary?limit=100");
    const data = await response.json();
    const s = data.all_time;
    $("usageMini").textContent = `成功 ${s.completed_requests} 次 · 失败 ${s.failed_requests} 次 · 发送前拦截 ${s.blocked_before_send} 次 · 输入 ${fmtNum(s.prompt_tokens_reported)} / 输出 ${fmtNum(s.completion_tokens_reported)} Token · 缓存命中 ${fmtNum(s.cached_input_tokens_reported || 0)} · 未命中 ${fmtNum(s.uncached_input_tokens_reported || 0)} · 实际扣费请核对 API 服务商账单`;
  } catch (e) { $("usageMini").textContent = "账本读取异常：" + e.message; }
}
async function showUsageModal() {
  $("usageModal").classList.remove("hidden");
  const overview = $("usageOverview");
  const listing = $("usageLogTable");
  overview.textContent = "正在读取本地日志……";
  try {
    const response = await fetch("/api/usage/summary?limit=140");
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "读取失败");
    const s = data.all_time;
    overview.textContent = `完成 ${s.completed_requests} · 失败 ${s.failed_requests} · 发送前拦截 ${s.blocked_before_send} · 待确认 ${s.pending_or_interrupted} · 输入 ${fmtNum(s.prompt_tokens_reported)} · 输出 ${fmtNum(s.completion_tokens_reported)} · 缓存命中输入 ${fmtNum(s.cached_input_tokens_reported || 0)} · 未命中输入 ${fmtNum(s.uncached_input_tokens_reported || 0)} · 本地几何复用 ${s.local_geometry_cache_hits || 0} 次 · 使用量/实际扣费无法确认的请求 ${s.unknown_cost_requests}`;
    listing.innerHTML = "";
    const table = document.createElement("table");
    table.className = "ledger-table";
    const header = document.createElement("tr");
    ["北京时间 (UTC+8)", "事件", "请求 ID", "Input / Output / Cache", "费用状态", "结果 / 说明"].forEach(text => {
      const cell = document.createElement("th"); cell.textContent = text; header.appendChild(cell);
    });
    table.appendChild(header);
    const tracked = new Set(["api_request_started", "api_request_completed", "api_request_failed", "budget_blocked", "local_tool_executed", "compatibility_switch", "local_review_blocked", "turn_started", "turn_finished", "agent_ready", "model_output_truncated", "geometry_partition_partial"]);
    (data.events || []).filter(ev => tracked.has(ev.event)).forEach(ev => {
      const tr = document.createElement("tr");
      const values = [
        fmtBeijing(ev.time_beijing || ev.time_utc),
        ({api_request_started:"请求已发送", api_request_completed:"请求完成", api_request_failed:"请求失败", budget_blocked:"预算拦截", local_tool_executed:"本地工具", compatibility_switch:"兼容切换",local_review_blocked:"本地停止（未发请求）",turn_started:"评测开始",turn_finished:"评测结束",agent_ready:"SDK已就绪",model_output_truncated:"模型输出截断",geometry_partition_partial:"分包阅读部分完成"})[ev.event] || ev.event,
        `${ev.mode || ""} ${ev.request_id || ev.turn_id || ""}`,
        ev.event === "api_request_completed" ? `${fmtNum(ev.prompt_tokens)} / ${fmtNum(ev.completion_tokens)} / ${fmtNum(ev.cached_input_tokens)}` : (ev.estimated_input_tokens ? `预计输入 ${ev.estimated_input_tokens}` : "—"),
        ev.event === "api_request_completed" ? "以官方账单为准" : "—",
        ev.error || ev.reason || ev.stop_reason || ev.message || (ev.tool ? `${ev.tool} · ${ev.ok ? "成功" : "失败"}` : ev.billing_status || ev.finish_reason || "—")
      ];
      values.forEach(value => { const td = document.createElement("td"); td.textContent = String(value); tr.appendChild(td); });
      table.appendChild(tr);
    });
    listing.appendChild(table);
  } catch (error) { overview.textContent = "读取失败：" + error.message; }
}
$("usageBtn").addEventListener("click", showUsageModal);
$("usageSideBtn").addEventListener("click", showUsageModal);
$("closeUsage").addEventListener("click", () => $("usageModal").classList.add("hidden"));
$("refreshUsage").addEventListener("click", showUsageModal);
$("usageModal").addEventListener("click", event => { if (event.target === $("usageModal")) $("usageModal").classList.add("hidden"); });
refreshUsageMini();
