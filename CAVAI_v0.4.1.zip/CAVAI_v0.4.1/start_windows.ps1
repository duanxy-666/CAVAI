$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$python = "python"
if (Test-Path ".venv\Scripts\python.exe") { $python = ".venv\Scripts\python.exe" }
elseif (Test-Path "venv\Scripts\python.exe") { $python = "venv\Scripts\python.exe" }
Write-Host "CAVAI 0.4.1 - OpenAI Agents SDK (Python 3.9 compatible)"
& $python --version
& $python "run.py"
