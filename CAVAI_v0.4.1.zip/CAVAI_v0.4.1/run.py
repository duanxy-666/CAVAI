from __future__ import print_function

import argparse
import sys
import socket
import threading
import webbrowser

import uvicorn


def port_is_available(host, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        sock.close()


def choose_port(host, preferred):
    for port in range(preferred, preferred + 20):
        if port_is_available(host, port):
            return port
    raise RuntimeError("8000-8019端口均被占用，请关闭旧服务或使用 --port 指定其他端口。")



def check_httpx_openai_compatibility():
    try:
        import openai
        import httpx
        openai_version = getattr(openai, "__version__", "unknown")
        httpx_version = getattr(httpx, "__version__", "unknown")
        try:
            from packaging.version import Version
            incompatible = (
                openai_version == "1.30.1"
                and Version(httpx_version) >= Version("0.28.0")
            )
        except Exception:
            incompatible = (openai_version == "1.30.1" and httpx_version.startswith("0.28"))
        print(" OpenAI SDK     : {}".format(openai_version))
        print(" HTTPX          : {}".format(httpx_version))
        if incompatible:
            print("")
            print("ERROR: openai==1.30.1 is incompatible with httpx>=0.28.0.")
            print("Run this command in the SAME PyCharm Terminal / interpreter:")
            print('python -m pip install --force-reinstall "httpx==0.27.2"')
            print("Then restart CAVAI.")
            raise SystemExit(1)
    except ImportError:
        # The normal requirements installer or Python traceback will explain missing packages.
        pass



def check_agents_usage_schema_compatibility():
    """Zero-cost SDK usage-schema smoke test; blocks incompatible installs at startup."""
    try:
        from agents.usage import Usage
        Usage()  # This previously crashed before any HTTP request with OpenAI 2.45+.
    except Exception as exc:
        print("")
        print("ERROR: OpenAI Agents SDK dependency compatibility check failed.")
        print("No model request has been sent by this check.")
        print("Reason: {}: {}".format(type(exc).__name__, str(exc)[:300]))
        print('In this SAME PyCharm interpreter run:')
        print('python -m pip install --force-reinstall --no-deps "openai==2.44.0"')
        print('python -m pip check')
        print("Then restart CAVAI.")
        raise SystemExit(1)
    print(" Agents SDK usage schema : OK (offline)")



def check_agents_model_settings_compatibility():
    """Offline guard for the SDK extra_body/extra_args collision."""
    try:
        from agents import ModelSettings
        from agent.sdk_agent import _sdk_model_options
        options = _sdk_model_options(
            {'base_url': 'https://api.deepseek.com', 'model': 'deepseek-flash'},
            intent=False
        )
        if 'extra_body' in (options.get('extra_args') or {}):
            raise ValueError("extra_body must not be nested inside extra_args")
        instance = ModelSettings(**options)
        if getattr(instance, 'extra_body', None) != {'thinking': {'type': 'disabled'}}:
            raise ValueError("Installed Agent SDK does not accept ModelSettings.extra_body")
    except Exception as exc:
        print("")
        print("ERROR: OpenAI Agents SDK model-settings compatibility check failed.")
        print("No API request was sent by this check.")
        print("Reason: {}: {}".format(type(exc).__name__, str(exc)[:250]))
        print("Check: python -m pip check")
        print("Then run: python -m unittest tests.test_real_sdk -v")
        raise SystemExit(1)
    print(" Agents SDK model settings : OK (offline)")


def check_cad_geometry_dependencies():
    try:
        import OCP
        print(" Open CASCADE : installed")
    except Exception as exc:
        print(" Open CASCADE : MISSING - {}".format(exc))
        print(" Run: python -m pip install -r requirements-catia.txt")

def main():
    if sys.version_info < (3, 9):
        raise SystemExit("CAVAI 0.4.1 需要 Python 3.9 或更新版本。")
    parser = argparse.ArgumentParser(description="Start CAVAI V0.4.1 local web app.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--open-browser", action="store_true", help="Also open the browser automatically.")
    args = parser.parse_args()

    port = choose_port(args.host, args.port)
    url = "http://{}:{}".format(args.host, port)

    print("")
    print("============================================================")
    print(" CAVAI V0.4.1 - Local CATIA Design Review Agent")
    print("============================================================")
    print(" Project folder : {}".format(__file__))
    print(" Local URL      : {}".format(url))
    print(" Tip            : In PyCharm Terminal, Ctrl+Left Click the URL.")
    print(" Stop server    : Ctrl+C")
    if port != args.port:
        print(" Note           : Port {} was busy; using {} instead.".format(args.port, port))
    print("============================================================")
    print("", flush=True)

    check_httpx_openai_compatibility()
    check_agents_usage_schema_compatibility()
    check_agents_model_settings_compatibility()
    check_cad_geometry_dependencies()

    # Import app only after printing startup guidance so import failures are visible.
    from main import app

    if args.open_browser:
        timer = threading.Timer(1.0, lambda: webbrowser.open(url))
        timer.daemon = True
        timer.start()

    import logging
    class PollFilter(logging.Filter):
        def filter(self, entry):
            args=entry.args
            if isinstance(args,tuple) and len(args)>=5:
                _,method,path,_,status=args[:5]
                if method=="GET" and str(path).startswith("/api/runs/") and str(path).endswith("/events") and str(status).split()[0] in ("200","404"):
                    return False
            return True
    logging.getLogger("uvicorn.access").addFilter(PollFilter())
    uvicorn.run(app, host=args.host, port=port, log_level="info", access_log=True)


if __name__ == "__main__":
    main()
