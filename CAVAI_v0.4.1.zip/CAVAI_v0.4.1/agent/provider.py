"""Public OpenAI SDK integration, with an observed HTTP request ledger.

No private SDK monkey patches, fabricated model responses, automatic paid
retries, or hidden reasoning capture.
"""
import asyncio
import base64
import hashlib
import json
import time
import uuid
from pathlib import Path
from urllib.parse import urlsplit
from cad.geometry_transport import capacity,output_capacity,payload_estimate
from agent.usage_ledger import record,scrub,money_estimate
from agent import live_progress

class HarnessStop(RuntimeError):
    pass

def model_options(settings,intent=False):
    options={"max_tokens":output_capacity(settings)}
    host=(urlsplit(settings.get("base_url","")).hostname or "").lower()
    if host=="api.deepseek.com" and settings.get("model","").lower() in {"deepseek-flash","deepseek-v4-pro"}:
        # Preserve the existing verified compatibility setting.
        options["extra_body"]={"thinking":{"type":"disabled"}}
    return options

class Meter:
    def __init__(self,settings,work):
        self.settings=settings;self.work=work;self.run_id=work.run_id
        self.requests={};self.pending={};self.seen=set();self.calls=0
        self.successes=0;self.failures=0;self.blocked=0;self.unknown=0
        self.prompt=0;self.completion=0;self.cached=0;self.uncached=0
        self.cache_known=0;self.cost=None;self.sent_bytes=0;self.estimated_reserved=0
        self.phase="";self.last_finish=None;self.cutoff=False
        self.local_stop="";self.batch=None;self.batch_revision=None;self.repeats=0
        self.phase_successes=0;self.phase_request_ids=[];self.context_metrics={}

    def start_phase(self,phase):
        self.phase=phase;self.last_finish=None;self.cutoff=False
        self.batch=None;self.batch_revision=None;self.repeats=0
        self.phase_successes=0;self.phase_request_ids=[];self.seen_tool_calls=set();self.context_metrics={}

    def snapshot(self,status="running",reason=""):
        return {"turn_id":self.run_id,"status":status,"stop_reason":reason,
            "calls":self.calls,"successful_requests":self.successes,"failed_requests":self.failures,
            "blocked_before_send":self.blocked,"pending_or_interrupted":len(self.pending),
            "prompt_tokens":self.prompt,"completion_tokens":self.completion,
            "cached_input_tokens":self.cached,"uncached_input_tokens":self.uncached,
            "cache_usage_known_requests":self.cache_known,
            "unknown_cost_requests":self.unknown+len(self.pending),
            "local_geometry_cache_hits":self.work.cache_hits,
            "estimated_cost_cny":self.cost,"request_bytes":self.sent_bytes,
            "geometry_partition_total":len(self.work.plan),
            "geometry_partition_completed":self.work.coverage()["read"]}

    def publish(self):
        live_progress.usage(self.run_id,self.snapshot())

    def stop(self,reason,budget=False):
        self.local_stop=reason
        if budget:
            self.blocked+=1
            record({"event":"budget_blocked","turn_id":self.run_id,"stage":self.phase,"reason":reason})
            self.publish()
        raise HarnessStop(reason)

    async def on_request(self,request):
        if request.method!="POST" or not request.url.path.rstrip("/").endswith("/chat/completions"):
            return
        if live_progress.stop_requested(self.run_id):self.stop("用户停止了本轮评测")
        if self.repeats>=3:self.stop("连续重复工具调用未获得新证据或判断，已停止无进展循环",True)
        raw=await request.aread()
        body=json.loads(raw)
        key=hashlib.sha256(raw).hexdigest()
        if key in self.seen:self.stop("检测到完全相同的重复模型请求，未再次发送",True)
        out=int(body.get("max_tokens") or body.get("max_completion_tokens") or output_capacity(self.settings))
        estimate=payload_estimate(body,self.settings)
        window,origin=capacity(self.settings)
        if origin!="unknown_provider_planning_assumption" and estimate+out>window:
            self.stop("实际请求保守估算超过已配置模型容量；已保留现有工程成果",True)
        if self.settings.get("limits_enabled"):
            if self.calls>=int(self.settings.get("max_requests",8)):
                self.stop("已达到用户设置的总请求数预算",True)
            if self.estimated_reserved+estimate+out>int(self.settings.get("max_turn_est_tokens",90000)):
                self.stop("已达到用户设置的总Token预算（含本次输出预留）",True)
        self.seen.add(key);self.calls+=1;self.sent_bytes+=len(raw)
        self.estimated_reserved+=estimate+out
        rid=uuid.uuid4().hex[:16]
        item={"turn_id":self.run_id,"request_id":rid,"round":self.calls,"stage":self.phase,
              "geometry_partition":self.phase,"estimated_input_tokens":estimate,
              "max_output_tokens":out,"request_bytes":len(raw),
              "context_management":dict(self.context_metrics)}
        self.pending[rid]=item;self.requests[rid]=item
        request.extensions["cavai_request_id"]=rid
        self.phase_request_ids.append(rid)
        record({"event":"api_request_started",**item})
        live_progress.pending(self.run_id,{"request_id":rid,"round":self.calls,
                              "unit_id":self.phase,"started_at":time.time()})
        live_progress.event(self.run_id,"api","向模型发送第{}次请求".format(self.calls),
                            "{} · {} KB；发送结构化几何与工程上下文".format(self.phase,round(len(raw)/1024,1)))
        self.publish()

    def failed(self,rid,reason,http_status=None):
        item=self.pending.pop(rid,None)
        if item is None:return
        self.failures+=1;self.unknown+=1
        record({"event":"api_request_failed",**item,"error_type":"provider_or_transport",
                "error_kind":reason,"http_status":http_status,"billing_status":"unknown"})
        live_progress.pending(self.run_id,None)
        self.publish()

    async def on_response(self,response):
        rid=response.request.extensions.get("cavai_request_id")
        if rid not in self.pending:return
        # Headers arriving are not a completed response. Retain the
        # pending request until body read/JSON parse really succeeds.
        try:
            await response.aread()
        except BaseException as exc:
            self.failed(rid,"响应正文读取中断："+type(exc).__name__,response.status_code)
            raise
        if response.status_code>=400:
            self.failed(rid,"HTTP "+str(response.status_code),response.status_code)
            return
        try:data=response.json()
        except ValueError:
            self.failed(rid,"服务商响应不是有效JSON",response.status_code)
            self.stop("服务商返回非JSON响应，无法读取模型结果")
        if not isinstance(data,dict) or not isinstance(data.get("choices"),list) or not data["choices"]:
            self.failed(rid,"服务商未返回有效模型消息",response.status_code)
            self.stop("API没有返回可读取的模型消息")
        u=data.get("usage") or {}
        def count(x):
            return x if type(x) is int and x>=0 else None
        p=count(u.get("prompt_tokens"));c=count(u.get("completion_tokens"))
        cache=count((u.get("prompt_tokens_details") or {}).get("cached_tokens"))
        if cache is None:cache=count(u.get("prompt_cache_hit_tokens"))
        miss=count(u.get("prompt_cache_miss_tokens"))
        if miss is None and cache is not None and p is not None:miss=max(0,p-cache)
        self.prompt+=p or 0;self.completion+=c or 0;self.cached+=cache or 0;self.uncached+=miss or 0
        if cache is not None:self.cache_known+=1
        cost=money_estimate(self.settings,p,c,cache)
        if cost is None:self.unknown+=1
        else:self.cost=(self.cost or 0)+cost
        item=self.pending.pop(rid);self.successes+=1;self.phase_successes+=1
        choice=data["choices"][0]
        finish=choice.get("finish_reason");message=choice.get("message") or {}
        text=message.get("content")
        if not isinstance(text,str):text=""
        # Public assistant text only. Do not store reasoning_content.
        record({"event":"api_request_completed",**item,"http_status":response.status_code,
            "prompt_tokens":p,"completion_tokens":c,"cached_input_tokens":cache,
            "uncached_input_tokens":miss,"finish_reason":finish,"estimated_cost_cny":cost})
        live_progress.pending(self.run_id,None)
        self.last_finish=finish
        try:self.work.received(self.phase,rid,text,finish)
        except Exception as exc:
            self.stop("模型已返回，但本地成果保存失败："+type(exc).__name__)
        live_progress.event(self.run_id,"api","模型请求已返回",
            "{} · 输入{} / 输出{} Token · {}".format(self.phase,p,c,finish))
        self.publish()
        tools=message.get("tool_calls") or ([] if not message.get("function_call") else [message["function_call"]])
        if tools:
            batch=[]
            for call in tools:
                fn=call.get("function",call)
                arguments=fn.get("arguments")
                try:arguments=json.loads(arguments) if isinstance(arguments,str) else arguments
                except ValueError:pass
                batch.append(json.dumps([fn.get("name"),arguments],sort_keys=True,ensure_ascii=False))
            batch=tuple(sorted(set(batch)))
            if set(batch)<=self.seen_tool_calls and self.work.revision==self.batch_revision:self.repeats+=1
            else:self.repeats=0
            self.seen_tool_calls.update(batch)
            self.batch=batch;self.batch_revision=self.work.revision
        else:self.batch=None;self.repeats=0
        if finish=="length":
            self.cutoff=True
            if tools:
                self.stop("模型输出截断，残缺工具参数未执行；此前实际正文与证据已保留")
        # A valid truncated text response is not an HTTP connection
        # failure. The review engine labels its window as partial.

    def reason(self,exc):
        if self.local_stop:return self.local_stop
        if "maxturns" in type(exc).__name__.lower():
            return "本窗口达到SDK安全轮次边界；已保存实际成果，可继续原工作"
        if isinstance(exc,HarnessStop):return str(exc)
        status=getattr(exc,"status_code",None)
        if status==401:return "API身份验证失败（401）"
        if status==402:return "API余额不足（402）；已完成请求仍可能计费"
        return scrub(type(exc).__name__+": "+str(exc),self.settings.get("api_key",""))[:350]

    def finish(self,status,reason=""):
        for rid in list(self.pending):
            self.failed(rid,reason or "运行结束但没有收到该请求的完整响应")
        snapshot=self.snapshot(status,reason)
        record({"event":"turn_finished",**snapshot})
        live_progress.pending(self.run_id,None)
        live_progress.usage(self.run_id,snapshot)
        return snapshot

async def cancellable(awaitable,run_id):
    task=asyncio.ensure_future(awaitable)
    try:
        while True:
            done,_=await asyncio.wait({task},timeout=.5)
            if task in done:return task.result()
            if live_progress.stop_requested(run_id):
                task.cancel()
                try:await task
                except asyncio.CancelledError:pass
                raise HarnessStop("用户停止了本轮评测；已发出的请求费用仍以服务商账单为准")
    finally:
        if not task.done():
            task.cancel()
            try:await task
            except asyncio.CancelledError:pass

def visual_input(prompt,upload,settings):
    from agent.model_capabilities import detect_model_capabilities
    if not detect_model_capabilities(settings["base_url"],settings["model"],
                                      settings.get("vision_mode","auto"))["vision"]:
        return prompt
    path=Path(upload.get("view_path") or upload.get("auto_view_path") or "")
    if not path.is_file():return prompt
    # Use the existing generated local view. Do not send native CAD.
    import io
    from PIL import Image
    with Image.open(path) as image:
        image=image.convert("RGB")
        image.thumbnail((1600,1600))
        out=io.BytesIO();image.save(out,format="JPEG",quality=86)
    url="data:image/jpeg;base64,"+base64.b64encode(out.getvalue()).decode("ascii")
    return [{"role":"user","content":[{"type":"input_text","text":prompt},
        {"type":"input_image","image_url":url,"detail":"auto"}]}]
