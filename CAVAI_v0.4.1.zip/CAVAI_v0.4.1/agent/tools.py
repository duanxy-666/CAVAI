"""Model-facing deterministic tools and genuine professional Skill access."""
import math
import json
from cad.geometry_transport import size,encode
from cad.json_fields import _pointer
from cad.spatial_evidence import read_shape,classify_point,box_occupancy
from agent.work import file_hash,fingerprint
from agent.usage_ledger import record
from agent import live_progress
from skills import registry

def page(value,offset=0,limit=20,max_bytes=24000):
    if type(offset) is not int or type(limit) is not int or offset<0 or not 1<=limit<=1000:
        raise ValueError("offset>=0，limit为1到1000")
    if offset==0 and size(value)<=max_bytes:
        return {"complete":True,"value":value}
    if isinstance(value,str):
        text=value[offset:offset+limit]
        while size(text)>max_bytes and text:text=text[:max(1,len(text)//2)]
        return {"kind":"string","total":len(value),"offset":offset,"value":text,
                "next_offset":offset+len(text) if offset+len(text)<len(value) else None}
    if isinstance(value,dict):
        seq=sorted(value);get=lambda k:value[k];kind="object"
    elif isinstance(value,list):
        seq=range(len(value));get=lambda k:value[k];kind="array"
    else:return {"complete":True,"value":value}
    if offset>len(seq):raise ValueError("分页位置超过集合长度")
    items=[];end=offset
    for k in seq[offset:offset+limit]:
        v=get(k)
        r={"key":k,"value":v}
        if size(r)>max_bytes-300:
            # This is an explicit unexpanded record, not its replacement.
            r={"key":k,"unexpanded":True,"value_bytes":size(v),
               "note":"使用当前pointer加此key继续读取精确值。"}
        if items and size(items+[r])>max_bytes-200:break
        items.append(r);end+=1
    return {"kind":kind,"total":len(seq),"offset":offset,"items":items,
            "next_offset":end if end<len(seq) else None,"complete":False}

def cylinder_occupancy(shape,origin,direction,radius,height):
    """Measured overlap with an arbitrary finite cylinder; not connectivity."""
    from OCP.gp import gp_Pnt,gp_Dir,gp_Ax2
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeCylinder
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Common,BRepAlgoAPI_Fuse
    from OCP.BRepGProp import BRepGProp
    from OCP.GProp import GProp_GProps
    from cad.spatial_evidence import _coords,_solids
    origin=_coords(origin);direction=_coords(direction)
    if math.sqrt(sum(x*x for x in direction))<=1e-12:
        raise ValueError("圆柱轴向不能为零")
    radius=float(radius);height=float(height)
    if not all(math.isfinite(x) and 1e-5<x<=1e8 for x in (radius,height)):
        raise ValueError("半径与长度必须为有限正数")
    probe=BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(*origin),gp_Dir(*direction)),radius,height).Shape()
    solids=_solids(shape)
    if len(solids)>128:raise ValueError("当前空间布尔运算不支持超过128个实体的合并")
    merged=solids[0]
    for solid in solids[1:]:
        op=BRepAlgoAPI_Fuse(merged,solid)
        if not op.IsDone():raise ValueError("实体合并失败")
        merged=op.Shape()
    op=BRepAlgoAPI_Common(merged,probe)
    if not op.IsDone():raise ValueError("圆柱相交计算失败")
    prop=GProp_GProps()
    if not op.Shape().IsNull():BRepGProp.VolumeProperties_s(op.Shape(),prop)
    volume=math.pi*radius*radius*height;occupied=float(prop.Mass())
    if not math.isfinite(occupied) or occupied<-1e-6 or occupied>volume+max(1e-6,volume*1e-7):
        raise ValueError("交集体积数值异常")
    occupied=max(0,min(volume,occupied))
    return {"measurement":"cylinder_occupancy","origin_mm":origin,"direction":direction,
            "radius_mm":radius,"height_mm":height,"probe_volume_mm3":volume,
            "occupied_volume_mm3":occupied,"free_volume_mm3":volume-occupied,
            "occupied_fraction":occupied/volume,
            "scope":"此有限圆柱区域的几何占据；不直接证明装配运动或空余空间连通性"}

class ToolBox:
    def __init__(self,work,meter):
        self.work=work;self.meter=meter;self.doc=work.document
        self.trace=[];self._shape=None
        self.max_bytes=max(800,min(48000,self.doc.bounds//12))
        self.legacy={}
        for name,key in (("faces","face_id"),("edges","edge_id"),("solids","solid_id")):
            self.legacy.update({v[key]:v for v in self.doc.g.get(name,[]) if key in v})
        self.features={v["feature_id"]:v for v in (self.doc.g.get("feature_graph") or {}).get("features",[])}
    def new_window(self):
        # Work-level observation index and persistent cache survive windows.
        pass
    def shape(self):
        if self._shape is None:
            if not self.work.spatial_sha or file_hash(self.work.spatial_path)!=self.work.spatial_sha:
                raise ValueError("当前本地空间测量源缺失或已改变；请重新导入模型")
            self._shape=read_shape(self.work.spatial_path)
        return self._shape
    def get_entity(self,entity_id):
        nid=self.doc.legacy.get(entity_id,entity_id)
        if entity_id in self.features:return self.features[entity_id]
        if nid not in self.doc.by_id and entity_id not in self.legacy:raise ValueError("未找到实体")
        return {"legacy":self.legacy.get(entity_id),"node":self.doc.by_id.get(nid),
                "incident_faces":(self.doc.t.get("edge_to_faces") or {}).get(nid,[])}
    def log(self,name,ok,cache=False,eid=None):
        row={"tool":name,"ok":ok,"evidence_id":eid,"from_disk_cache":cache}
        self.trace.append(row)
        record({"event":"local_tool_executed","turn_id":self.work.run_id,
                "tool":name,"stage":self.work.current_unit,"from_disk_cache":cache,
                "evidence_id":eid,"result":"成功" if ok else "未取得结果"})
        live_progress.event(self.work.run_id,"tool","完成 "+name if ok else name+" 未取得结果",
                            ("复用已测量证据 · " if cache else "")+(eid or ""))
        self.meter.publish()
    def measured(self,name,args,calculate):
        try:
            # The result-page size is part of a read operation's identity.
            # Geometry measurements retain their exact numerical semantics.
            if name in ("read_geometry","read_global_geometry","read_entity","search_geometry"):
                args={**args,"page_bytes":self.max_bytes}
            evidence,hit=self.work.query(name,args,calculate)
            eid=evidence["id"]
            self.log(name,True,hit,eid)
            return encode({"evidence_id":eid,"source":evidence["source"],"data":evidence["data"],
                           "reused_measurement":hit})
        except (ValueError,KeyError,IndexError,TypeError,OSError,RuntimeError) as exc:
            self.log(name,False)
            return encode({"error":type(exc).__name__,"message":str(exc)[:220],"scope":"没有形成证据"})
    def guarded(self,name,fn):
        try:
            value=fn();self.log(name,True)
            return encode(value)
        except (ValueError,KeyError,IndexError,TypeError,OSError,RuntimeError) as exc:
            self.log(name,False)
            return encode({"error":type(exc).__name__,"message":str(exc)[:220]})
    def build(self,function_tool):
        # Tools are public SDK function_tool instances. No home-made
        # function-calling loop or model-generated Python execution.
        box=self

        @function_tool
        def read_geometry(pointer: str="", offset: int=0, limit: int=20)->str:
            """Read exact fields of the full local CAD JSON via JSON Pointer. Large values have explicit pages or child pointers; no guessed values."""
            args={"pointer":pointer,"offset":offset,"limit":limit}
            return box.measured("read_geometry",args,lambda:page(_pointer(box.doc.data,pointer),offset,limit,box.max_bytes))

        @function_tool
        def read_global_geometry(pointer: str="",offset: int=0,limit: int=20)->str:
            """Read the actual global numerical geometry directory, including coordinates, face/edge/vertex relations and structure groups."""
            args={"pointer":pointer,"offset":offset,"limit":limit}
            return box.measured("read_global_geometry",args,lambda:page(_pointer(box.doc.overview,pointer),offset,limit,box.max_bytes))

        @function_tool
        def read_entity(entity_id: str,pointer: str="",offset: int=0,limit: int=20)->str:
            """Inspect exact CAD entity F/E/S/N ID or observed structure feature ID. Use /node/properties/surface or another JSON pointer for a large record."""
            args={"entity_id":entity_id,"pointer":pointer,"offset":offset,"limit":limit}
            return box.measured("read_entity",args,lambda:page(_pointer(box.get_entity(entity_id),pointer),offset,limit,box.max_bytes))

        @function_tool
        def search_geometry(kind: str, geometry_type: str="", solid_id: str="", radius_mm: float=-1.0,
                            offset: int=0,limit: int=20)->str:
            """Find observed faces, edges, solids, hole_candidates, features or nodes. Optional exact type, solid ID and radius filter; radius -1 disables the filter. Results are actual extracted records."""
            args={"kind":kind,"geometry_type":geometry_type,"solid_id":solid_id,
                  "radius_mm":radius_mm,"offset":offset,"limit":limit}
            def calculate():
                if kind=="features":source=list(box.features.values())
                elif kind=="nodes":source=box.doc.nodes
                elif kind in {"faces","edges","solids","hole_candidates"}:source=box.doc.g.get(kind,[])
                else:raise ValueError("未知几何类别")
                values=[]
                for r in source:
                    if geometry_type and geometry_type not in (r.get("surface_type"),r.get("curve_type"),r.get("type")):continue
                    if solid_id and solid_id not in list(r.get("solid_ids") or [])+[r.get("solid_id")]:continue
                    if radius_mm>=0 and (type(r.get("radius")) not in (int,float) or abs(r["radius"]-radius_mm)>1e-6):continue
                    values.append(r)
                return page(values,offset,limit,box.max_bytes)
            return box.measured("search_geometry",args,calculate)

        @function_tool
        def classify_model_point(x_mm: float,y_mm: float,z_mm: float)->str:
            """Classify a point against the actual local solid geometry. One point alone does not prove that a hole or a connected passage exists."""
            xyz=[x_mm,y_mm,z_mm]
            return box.measured("classify_model_point",{"point_mm":xyz},lambda:classify_point(box.shape(),xyz))

        @function_tool
        def measure_box_occupancy(min_mm: list[float],max_mm: list[float])->str:
            """Measure the exact occupied/free volume of an axis-aligned rectangular probe against the actual solids. No inferred connectivity."""
            args={"min_mm":min_mm,"max_mm":max_mm}
            return box.measured("measure_box_occupancy",args,lambda:box_occupancy(box.shape(),min_mm,max_mm))

        @function_tool
        def measure_cylinder_occupancy(origin_mm: list[float],direction: list[float],radius_mm: float,height_mm: float)->str:
            """Measure occupied/free volume of a finite cylindrical probe at arbitrary position and axis, using OCCT boolean geometry. Does not establish motion feasibility by itself."""
            args={"origin_mm":origin_mm,"direction":direction,"radius_mm":radius_mm,"height_mm":height_mm}
            return box.measured("measure_cylinder_occupancy",args,lambda:cylinder_occupancy(box.shape(),origin_mm,direction,radius_mm,height_mm))

        @function_tool
        def measure_geometry_batch(points_mm: list[list[float]],
                                   boxes_mm: list[list[list[float]]],
                                   cylinders_mm: list[list[float]],
                                   investigation: str="")->str:
            """Run independent measurements together. points: [x,y,z]; boxes: [[xmin,ymin,zmin],[xmax,ymax,zmax]]; cylinders: [ox,oy,oz,dx,dy,dz,radius,height]. Use [] for unused groups. investigation states the engineering question, not a measured fact. Results are exact OCCT observations, not a conclusion. Up to 32 probes per batch; avoid repeating already measured identical probes."""
            def calculate():
                operations=[]
                for v in points_mm:
                    if len(v)!=3:raise ValueError("point must have three coordinates")
                    operations.append(("classify_model_point",{"point_mm":v},
                        lambda v=v:classify_point(box.shape(),v)))
                for v in boxes_mm:
                    if len(v)!=2 or any(len(p)!=3 for p in v):raise ValueError("box must have two 3D corners")
                    operations.append(("measure_box_occupancy",{"min_mm":v[0],"max_mm":v[1]},
                        lambda v=v:box_occupancy(box.shape(),v[0],v[1])))
                for v in cylinders_mm:
                    if len(v)!=8:raise ValueError("cylinder must have eight parameters")
                    operations.append(("measure_cylinder_occupancy",{"origin_mm":v[:3],"direction":v[3:6],
                        "radius_mm":v[6],"height_mm":v[7]},lambda v=v:cylinder_occupancy(box.shape(),v[:3],v[3:6],v[6],v[7])))
                if not operations or len(operations)>32:raise ValueError("每批需要1至32个独立测量")
                results=[];refs=[]
                for i,(name,args,fn) in enumerate(operations):
                    value=json.loads(box.measured(name,args,fn))
                    eid=value.get("evidence_id")
                    if eid and eid in refs:
                        results.append({"index":i,"tool":name,"evidence_id":eid,"duplicate_of":refs.index(eid)})
                    else:
                        results.append({"index":i,"tool":name,**value})
                    refs.append(eid)
                return {"investigation":investigation,"results":results,
                        "scope":"独立测量的实际结果；调查目的不是已证实结论"}
            return box.guarded("measure_geometry_batch",calculate)

        @function_tool
        def find_work_records(query: str, entity_ids: list[str],
                              min_mm: list[float], max_mm: list[float],
                              offset: int=0, limit: int=12)->str:
            """Recall prior engineering judgments, measurements and tool records by text, exact entity IDs, or spatial region. Use empty strings/lists for absent filters. Spatial overlap suggests relevance, not equivalence. Small exact results included; full records retrievable by category and ID."""
            from agent.working_context import recall_records
            def lookup():
                if offset<0 or not 1<=limit<=100:raise ValueError("无效分页")
                matches=recall_records(box.work,query,entity_ids,min_mm,max_mm)
                selected=[];used=300;end=offset
                for row in matches[offset:offset+limit]:
                    if size(row)>box.max_bytes-600:
                        row={k:row[k] for k in ("id","category","recall_score") if k in row}
                        row["exact_record_available"]=True
                    if used+size(row)+1>box.max_bytes:break
                    selected.append(row);used+=size(row)+1;end+=1
                return {"total":len(matches),"offset":offset,"records":selected,
                        "next_offset":end if end<len(matches) else None}
            return box.guarded("find_work_records",lookup)

        @function_tool
        def load_skill(name: str)->str:
            """Load an existing professional Skill from the advertised local catalog. Reuse its exact content in later engineering windows."""
            def load():
                row=registry.load_skill(name)
                box.work.note_skill(name,row["content"])
                return {"name":name,"content":row["content"],"references":row.get("reference_paths",[])}
            return box.guarded("load_skill",load)

        @function_tool
        def read_skill_reference(name: str,relative_path: str,offset: int=0,limit: int=1000)->str:
            """Read a reference file belonging to an actually loaded Skill. No external file access."""
            def load():
                if name not in box.work.skills:raise ValueError("请先加载此Skill")
                row=registry.read_skill_reference(name,relative_path)
                return {"skill_name":name,"relative_path":relative_path,
                        "content":page(row["content"],offset,limit,box.max_bytes)}
            return box.guarded("read_skill_reference",load)

        @function_tool
        def record_finding(title: str,condition: str,basis: str,status: str,location: str,
                           reasoning: str,consequence: str,recommendation: str,
                           evidence_ids: list[str],finding_id: str="",severity: str="unspecified",
                           correction_reason: str="")->str:
            """Persist a real engineering judgment immediately. basis=user_requirement or function_hypothesis; status=supported, contradicted, insufficient, or not_applicable. Cite actual E-IDs (including the input window). Reuse finding_id to correct it, with a correction_reason. No checklist completion required."""
            row={"id":finding_id,"title":title,"condition":condition,"basis":basis,"status":status,
                 "location":location,"reasoning":reasoning,"consequence":consequence,
                 "recommendation":recommendation,"evidence_ids":evidence_ids,
                 "severity":severity,"correction_reason":correction_reason}
            return box.guarded("record_finding",lambda:box.work.register(row))

        @function_tool
        def list_work_records(category: str,offset: int=0,limit: int=30)->str:
            """List saved findings, unit_results, evidence, skills, outputs, interactions, plan or source_windows. These include earlier conclusions and exact source references, not new measurements."""
            def list_records():
                table=box.work.list_records(category)
                rows=[{"id":k,"label":v.get("title") or v.get("tool") or v.get("unit_id") or v.get("name") or v.get("status")}
                      for k,v in table.items()]
                return page(rows,offset,limit,box.max_bytes)
            return box.guarded("list_work_records",list_records)

        @function_tool
        def read_work_record(category: str,record_id: str,pointer: str="",offset: int=0,limit: int=1000)->str:
            """Read a saved work record with exact pagination. category=source_windows reads the original window by U-ID, including /owned or /data; interactions reads archived tool inputs/outputs; findings/evidence/outputs/unit_results/skills read actual prior records. A prior opinion is not a measurement."""
            return box.guarded("read_work_record",lambda:page(
                _pointer(box.work.list_records(category)[record_id],pointer),offset,limit,box.max_bytes))

        return [read_geometry,read_global_geometry,read_entity,search_geometry,
                classify_model_point,measure_box_occupancy,measure_cylinder_occupancy,
                measure_geometry_batch,find_work_records,
                load_skill,read_skill_reference,record_finding,list_work_records,read_work_record]
