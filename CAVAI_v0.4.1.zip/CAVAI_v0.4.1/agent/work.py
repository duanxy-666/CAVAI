"""Durable engineering work, rather than a transcript or task checklist."""
from pathlib import Path
from contextlib import contextmanager
from threading import RLock
import copy
import hashlib
import json
import sqlite3
import time
import os
from cad.geometry_transport import encode,size,digest
from settings_store import ROOT
from agent import live_progress

DB_PATH=ROOT/"data"/"harness"/"review.sqlite3"
STAGE_DIR=ROOT/"data"/"harness"/"stages"
REVISION="cavai-work-0.4.1"
GEOMETRY_CACHE_REVISION="cavai-work-0.4.0"

def canonical(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":"),allow_nan=False)

def fingerprint(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()

def query_key(name,args):
    def normalized(x):
        if type(x) is float and x.is_integer():
            return int(x)
        if isinstance(x,list):return [normalized(v) for v in x]
        if isinstance(x,dict):return {k:normalized(v) for k,v in x.items()}
        return x
    spatial={"classify_model_point","measure_box_occupancy","measure_cylinder_occupancy"}
    return fingerprint([name,normalized(args) if name in spatial else args])

def file_hash(path):
    p=Path(path or "")
    if not p.is_file():return None
    h=hashlib.sha256()
    with p.open("rb") as stream:
        for b in iter(lambda:stream.read(1024*1024),b""):h.update(b)
    return h.hexdigest()

class Store:
    def __init__(self,path=None):
        self.path=Path(path or DB_PATH)
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.lock=RLock()
        with self.connection() as c:
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("""CREATE TABLE IF NOT EXISTS records(
                category TEXT NOT NULL, owner TEXT NOT NULL, key TEXT NOT NULL,
                value TEXT NOT NULL, updated REAL NOT NULL,
                PRIMARY KEY(category,owner,key))""")
    @contextmanager
    def connection(self):
        with self.lock:
            c=sqlite3.connect(str(self.path),timeout=15)
            try:
                yield c
                c.commit()
            except BaseException:
                c.rollback()
                raise
            finally:c.close()
    def get(self,category,owner,key):
        with self.connection() as c:
            row=c.execute("SELECT value FROM records WHERE category=? AND owner=? AND key=?",
                          (category,owner,key)).fetchone()
        return json.loads(row[0]) if row else None
    def all(self,category,owner):
        with self.connection() as c:
            rows=c.execute("SELECT key,value FROM records WHERE category=? AND owner=? ORDER BY updated,key",
                           (category,owner)).fetchall()
        return {k:json.loads(v) for k,v in rows}
    def put(self,category,owner,key,value):
        with self.connection() as c:
            c.execute("""INSERT INTO records VALUES(?,?,?,?,?) ON CONFLICT(category,owner,key)
                DO UPDATE SET value=excluded.value,updated=excluded.updated""",
                (category,owner,key,encode(value),time.time()))
    def put_many(self,rows):
        with self.connection() as c:
            c.executemany("""INSERT INTO records VALUES(?,?,?,?,?) ON CONFLICT(category,owner,key)
                DO UPDATE SET value=excluded.value,updated=excluded.updated""",
                [(cat,owner,key,encode(v),time.time()) for cat,owner,key,v in rows])

def geometry_key(document,upload):
    path=Path(str(upload.get("path") or ""))
    source=file_hash(path)
    step=path if path.suffix.lower() in (".stp",".step") else path.parent/(path.stem+"_review_source.step")
    spatial=file_hash(step)
    # Do not reuse a geometry cache across an unidentified source.
    key=fingerprint([GEOMETRY_CACHE_REVISION,document.sha,source,spatial]) if source else None
    return key,str(step),spatial

class ReviewWork:
    def __init__(self,store,document,upload,settings,goal,scope,run_id,mode="review",prior=None,stage_dir=None):
        self.store=store;self.document=document;self.upload=upload;self.goal=goal;self.run_id=run_id
        self.mode=mode;self.lock=RLock();self.stage_dir=Path(stage_dir or STAGE_DIR)
        self.geometry_key,self.spatial_path,self.spatial_sha=geometry_key(document,upload)
        # Work identity is tied to the actual source, exact plan, goal,
        # provider/model and actual professional Skill corpus.
        from skills.registry import list_skills,load_skill
        corpus=[(s["name"],fingerprint(load_skill(s["name"])["content"])) for s in list_skills()]
        self.plan=document.manifest()
        view=upload.get("view_path") or upload.get("auto_view_path")
        self.scope_key=fingerprint([REVISION,scope,self.geometry_key or run_id,mode,goal,
            settings.get("base_url"),settings.get("model"),settings.get("vision_mode"),
            file_hash(view),corpus,self.plan])
        active=store.get("active",self.scope_key,"job") or {}
        self.identity=active.get("identity") or fingerprint([self.scope_key,run_id])
        old=store.get("job",self.identity,"meta")
        if old and old.get("execution")=="completed":
            self.identity=fingerprint([self.scope_key,run_id]);old=None
        store.put("active",self.scope_key,"job",{"identity":self.identity})
        self.evidence=store.all("evidence",self.identity)
        self.findings=store.all("finding",self.identity)
        self.outputs=store.all("output",self.identity)
        self.units=store.all("unit",self.identity)
        self.skills=store.all("skill",self.identity)
        self.interactions=store.all("interaction",self.identity)
        self.observation_index={query_key(v["tool"],v["arguments"]):v
            for v in self.evidence.values() if v.get("source")=="local_geometry"}
        self.revision=int((old or {}).get("revision",0))
        self.resumed=bool(old)
        self.cache_hits=0
        self.current_unit=""
        self.phase="preparing";self.execution="running";self.reason=""
        self.final_text=""
        self.stage_error=""
        self.prior=prior or {}
        self.persist_meta()
        self.publish()
        if self.outputs or self.findings:self.write_stage()

    def persist_meta(self):
        self.store.put_many([
            ("job",self.identity,"meta",{"schema":REVISION,"run_id":self.run_id,"goal":self.goal,
                "geometry_key":self.geometry_key,"source_sha256":self.document.sha,"plan":self.plan,
                "phase":self.phase,"execution":self.execution,"stop_reason":self.reason,
                "revision":self.revision,"filename":self.upload.get("filename",""),
                "mode":self.mode,"final_text":self.final_text}),
            ("run",self.run_id,"job",{"identity":self.identity})
        ])
    def changed(self):
        self.revision+=1
        self.persist_meta()
        self.publish()

    def observe(self,kind,args,value,source="local_geometry",cache=False):
        # Evidence identity includes actual values, not merely arguments.
        # Different measured results can never overwrite an older fact.
        key="E-"+fingerprint([self.document.sha,kind,args,value])[:20]
        if key not in self.evidence:
            row={"id":key,"source":source,"tool":kind,"arguments":args,"data":value}
            self.store.put("evidence",self.identity,key,row)
            self.evidence[key]=row
            self.changed()
        if source=="local_geometry":
            self.observation_index[query_key(kind,args)]=self.evidence[key]
        if cache:self.cache_hits+=1
        return self.evidence[key]

    def input_record(self,unit):
        return self.observe("CAD输入窗口",{"unit_id":unit["id"]},
            {"source_sha256":self.document.sha,"window_sha256":digest(unit),
             "kind":unit["kind"],"frame_sha256":digest(self.document.frame_for(unit)),
             "face_ids":unit.get("face_ids",[]),
             "source_path_count":1 if unit["kind"]=="full" else len(unit.get("owned",[])),
             "source_record_accessor":{"category":"source_windows","record_id":unit["id"],
                                       "pointer":"/data" if unit["kind"]=="full" else "/owned"},
             "global_frame":"完整原始JSON" if unit["kind"]=="full" else unit.get("frame_mode","normal")},
             source="cad_input_record")

    def query(self,name,args,calculate):
        with self.lock:
            key=query_key(name,args)
            existing=self.observation_index.get(key)
            if existing is not None:
                self.cache_hits+=1
                return existing,True
            row=self.store.get("cache",self.geometry_key,key) if self.geometry_key else None
            legacy_key=fingerprint([name,args])
            if row is None and self.geometry_key and legacy_key!=key:
                row=self.store.get("cache",self.geometry_key,legacy_key)
            hit=row is not None
            if hit:value=row["data"]
            else:
                value=calculate()
                # Failed queries are not cached as geometry facts.
                if self.geometry_key:self.store.put("cache",self.geometry_key,key,{"data":value})
            return self.observe(name,args,value,cache=hit),hit

    def note_skill(self,name,content):
        row={"name":name,"sha256":fingerprint(content),"content":content}
        if self.skills.get(name)!=row:
            self.skills[name]=row
            self.store.put("skill",self.identity,name,row)
            self.changed()

    def register(self,row):
        with self.lock:
            required=("title","condition","reasoning","consequence","recommendation")
            if any(not isinstance(row.get(k),str) or not row[k].strip() for k in required):
                raise ValueError("判断必须有标题、条件、依据、后果及改进建议")
            if row.get("basis") not in ("user_requirement","function_hypothesis"):
                raise ValueError("区分明确要求与推测用途")
            if row.get("status") not in ("supported","contradicted","insufficient","not_applicable"):
                raise ValueError("未知判断状态")
            ids=list(dict.fromkeys(row.get("evidence_ids") or []))
            if any(x not in self.evidence for x in ids):raise ValueError("引用了尚未取得的证据")
            if row["status"] in ("supported","contradicted") and not ids:
                raise ValueError("明确条件判断需要实际几何证据或输入窗口引用")
            ident=str(row.get("id") or "F-"+fingerprint([row["condition"],row.get("location",""),row["basis"]])[:12])
            if not ident or len(ident)>80:raise ValueError("无效判断编号")
            clean={k:row[k].strip() for k in required}
            clean.update(id=ident,basis=row["basis"],status=row["status"],evidence_ids=ids,
                         location=str(row.get("location") or ""),severity=str(row.get("severity") or "unspecified"),
                         unit_id=self.current_unit)
            old=self.findings.get(ident)
            if old and {k:v for k,v in old.items() if k!="unit_id"}=={k:v for k,v in clean.items() if k!="unit_id"}:
                return {"id":ident,"saved":True,"changed":False}
            if old and old["status"]!=clean["status"]:
                correction=str(row.get("correction_reason") or "").strip()
                if not correction:raise ValueError("改变既有判断状态时说明新增证据或修正原因")
                clean["correction_reason"]=correction
                self.store.put("revision",self.identity,ident+":"+str(self.revision),old)
            self.store.put("finding",self.identity,ident,clean)
            self.findings[ident]=clean;self.changed();self.write_stage()
            return {"id":ident,"saved":True,"changed":True}

    def start_unit(self,unit_id):
        self.current_unit=unit_id
        self.phase="engineering_review" if unit_id!="SYNTHESIS" else "synthesis"
        self.persist_meta();self.publish()

    def received(self,unit_id,request_id,text,finish_reason):
        # Actual visible assistant message only; no hidden reasoning.
        with self.lock:
            row={"unit_id":unit_id,"request_id":request_id,"text":text or "",
                 "finish_reason":finish_reason,"run_id":self.run_id}
            self.outputs[request_id]=row
            try:
                self.store.put("output",self.identity,request_id,row)
            finally:
                if text:self.write_stage()
                self.publish()

    def finish_unit(self,unit_id,text,complete):
        with self.lock:
            row={"id":unit_id,"text":text,"status":"completed" if complete else "partial"}
            self.store.put("unit",self.identity,unit_id,row)
            self.units[unit_id]=row
            self.changed();self.write_stage()

    def done(self,unit_id):
        return self.units.get(unit_id,{}).get("status")=="completed"

    def coverage(self):
        ids={x["id"] for x in self.plan}
        received={x["unit_id"] for x in self.outputs.values()}
        reviewed={x for x in ids if self.done(x)}
        return {"total":len(ids),"read":len(reviewed),"received":len(ids&received),
                "complete_units":sorted(reviewed),"pending_units":sorted(ids-reviewed),
                "partial_units":sorted(x for x in ids if self.units.get(x,{}).get("status")=="partial"),
                "source_data_complete":ids<=received,"semantic_coverage_verified":False,
                 "global_directory_first_window":bool(self.document.units[0]["kind"]=="full" or self.document.initial_overview or self.document.overview_complete),
                "review_status":"completed" if self.execution=="completed" else "partial",
                "resumed":self.resumed}

    def has_output(self):
        return bool(self.findings or any(x.get("text") for x in self.outputs.values()) or any(x.get("text") for x in self.units.values()))

    def snapshot(self):
        # Only small public previews are polled. Complete outputs remain
        # on disk and are available through the stage download endpoint.
        previews=[]
        for row in self.outputs.values():
            if row.get("text"):
                previews.append({"unit_id":row["unit_id"],"request_id":row["request_id"],
                                 "text":row["text"][:1200],"truncated":len(row["text"])>1200})
        return {"schema":"cavai-harness-work-2","identity":self.identity,"execution":self.execution,
            "phase":self.phase,"stop_reason":self.reason,"findings":list(self.findings.values()),
            "evidence_count":len(self.evidence),"nodes":[],"coverage":self.coverage(),
            "current_unit":self.current_unit,"output_count":len(previews),
            "recent_outputs":previews[-3:],"revision":self.revision,
            "stage_download_url":"/api/runs/"+self.run_id+"/stage" if (self.stage_dir/(self.run_id+".md")).is_file() else None,
            "stage_save_error":self.stage_error,
            "audit":{"complete":self.execution=="completed","issues":[]}}

    def publish(self):
        live_progress.tasks(self.run_id,self.snapshot())

    def archive_interactions(self,rows):
        with self.lock:
            new=[]
            for row in rows:
                ident=row["id"]
                if ident not in self.interactions:
                    new.append(("interaction",self.identity,ident,row))
            if new:
                self.store.put_many(new)
                for _,_,ident,row in new:self.interactions[ident]=row

    def memory(self,budget,unit_id,recent=None,exclude_evidence=(),exclude_skills=()):
        from agent.working_context import build_memory
        return build_memory(self,budget,unit_id,recent,exclude_evidence,exclude_skills)

    def list_records(self,category):
        table={"findings":self.findings,"unit_results":self.units,"evidence":self.evidence,
               "skills":self.skills,"outputs":self.outputs,"plan":{v["id"]:v for v in self.plan},
               "interactions":self.interactions,"source_windows":self.document.unit_map}
        if category not in table:raise ValueError("未知工作记录类别")
        return table[category]

    def stage_markdown(self):
        cov=self.coverage()
        lines=["# CAVAI 工程工作成果（实际记录）","",
            "模型："+str(self.upload.get("filename") or ""),"",
            "目标："+self.goal,"",
            "工作状态：{}；输入响应 {}/{}，窗口自然结束 {}/{}。".format(self.execution,cov["received"],cov["total"],cov["read"],cov["total"]),
            "本文件由已保存的模型输出及判断组成，不是额外生成的报告，不代表设计通过。",""]
        if self.reason:lines.extend(["停止原因："+self.reason,""])
        if self.findings:
            lines+=["## 已登记的工程判断",""]
            for f in sorted(self.findings.values(),key=lambda x:(x["status"]!="contradicted",x["id"])):
                lines += ["### "+f["title"],"",f"状态：{f['status']}；依据：{f['basis']}；位置：{f['location']}",
                          f"条件：{f['condition']}",f"判断：{f['reasoning']}",
                          f"后果：{f['consequence']}",f"建议：{f['recommendation']}",
                          "证据："+", ".join(f["evidence_ids"]),""]

        lines+=["## 已完成窗口的模型结论",""]
        for u in self.units.values():
            lines.extend(["### "+u["id"]+" · "+u["status"],"",u["text"],""])
        lines+=["## API实际可见输出原文（包含尚未完成的窗口）",""]
        for r in self.outputs.values():
            if r["text"]:lines.extend(["### "+r["unit_id"]+" · "+r["request_id"]+" · "+str(r["finish_reason"]),"",r["text"],""])
        if self.final_text:lines+=["## 最终模型正文","",self.final_text,""]
        return "\n".join(lines)+"\n"

    def write_stage(self):
        if not self.has_output():return
        try:
            self.stage_dir.mkdir(parents=True,exist_ok=True)
            path=self.stage_dir/(self.run_id+".md")
            temp=path.with_suffix(".md.tmp")
            temp.write_text(self.stage_markdown(),encoding="utf-8")
            os.replace(temp,path)
            self.stage_error=""
        except OSError as exc:
            self.stage_error="阶段文件写入失败："+type(exc).__name__+"；保留SQLite及内存中的实际输出。"
        self.publish()

    def finish(self,status,reason="",final_text=""):
        self.execution=status;self.reason=reason;self.final_text=final_text
        self.phase="finished";self.persist_meta();self.publish();self.write_stage()

    def export(self):
        return {"schema":REVISION,"geometry_key":self.geometry_key,"harness_work_id":self.identity,
            "model_fingerprint":self.document.sha,"review_goal":self.goal,"stop_reason":self.reason,
            "task_state":self.snapshot(),"stage_download_url":self.snapshot()["stage_download_url"]}
