"""Local-only, read-only Agent execution progress.

This is a record of observable tool/API actions, not the model's hidden thoughts.
No API secrets, CAD geometry dumps or model private reasoning are stored here.
Python 3.9 compatible. UI polls this in-memory state; there is no paid API call.
"""
from __future__ import annotations

import re
import copy
import threading
import time
from typing import Any, Dict, Optional

_LOCK = threading.RLock()
_RUNS: Dict[str, dict] = {}
_ID_RE = re.compile(r"^[a-fA-F0-9]{16,64}$")
_MAX_RUNS = 128
_MAX_EVENTS = 75
_TTL_SECONDS = 1800


def valid_id(run_id: str) -> bool:
    return isinstance(run_id, str) and bool(_ID_RE.fullmatch(run_id))


def _clean(value: Any, max_len: int = 180) -> str:
    # Callers must pass explanations or safe summaries, never raw HTTP payloads.
    return ' '.join(str(value or '').split())[:max_len]


def begin(run_id: str, label: str = '开始分析') -> None:
    if not valid_id(run_id):
        raise ValueError('无效的本地进度追踪ID')
    now = time.time()
    with _LOCK:
        expired = [key for key, value in _RUNS.items()
                   if value.get('done') and now - value['created_at'] > _TTL_SECONDS]
        for key in expired:
            _RUNS.pop(key, None)
        if len(_RUNS) >= _MAX_RUNS:
            finished=[key for key,value in _RUNS.items() if value.get('done')]
            if finished:_RUNS.pop(min(finished,key=lambda x:_RUNS[x]['created_at']),None)
        _RUNS[run_id] = {'run_id': run_id, 'created_at': now, 'done': False,
                         'status': 'running', 'events': [], 'task_state': None, 'usage':None, 'pending_request':None, 'stop_requested':False, 'label': _clean(label)}
        _append_unlocked(run_id, 'start', label)


def _append_unlocked(run_id: str, kind: str, label: str, detail: str = '') -> None:
    run = _RUNS.get(run_id)
    if not run:
        return
    events = run['events']
    run['event_count']=run.get('event_count',0)+1
    events.append({'index': run['event_count'], 'kind': _clean(kind, 36),
                   'label': _clean(label, 110), 'detail': _clean(detail, 190),
                   'timestamp': round(time.time(), 3)})
    # Capped to ensure the local UI cannot grow without bound.
    if len(events) > _MAX_EVENTS:
        del events[1:len(events) - _MAX_EVENTS + 1]


def event(run_id: str, kind: str, label: str, detail: str = '') -> None:
    if not valid_id(run_id):
        return
    with _LOCK:
        _append_unlocked(run_id, kind, label, detail)


def tasks(run_id: str, snapshot: dict) -> None:
    """Publish a real Python task snapshot, without an additional API request."""
    if not valid_id(run_id):
        return
    with _LOCK:
        run = _RUNS.get(run_id)
        if run is not None:
            run['task_state'] = copy.deepcopy(snapshot)


def finish(run_id: str, status: str, label: str = '') -> None:
    if not valid_id(run_id):
        return
    with _LOCK:
        run = _RUNS.get(run_id)
        if run is None:
            return
        if run['done']:
            return
        run['done'] = True
        run['status'] = status if status in {'completed','partial','incomplete','failed'} else 'failed'
        _append_unlocked(run_id, 'finish', label or ('分析完成' if status == 'completed' else '分析已结束'))


def snapshot(run_id: str) -> Optional[dict]:
    if not valid_id(run_id):
        return None
    with _LOCK:
        run = _RUNS.get(run_id)
        if not run:
            return None
        return {'run_id': run_id, 'done': run['done'], 'status': run['status'],
                'events': [dict(item) for item in run['events']],
                                'task_state': copy.deepcopy(run.get('task_state')),
                'usage':copy.deepcopy(run.get('usage')),
                'pending_request':({**run['pending_request'],
                    'elapsed_seconds':max(0,int(time.time()-run['pending_request']['started_at']))}
                    if run.get('pending_request') else None),
                'stop_requested':bool(run.get('stop_requested')),
                'note': '仅展示真实请求、工具调用及工程证据轨迹，不代表模型未公开的内部思维链。'}

def set_result(run_id: str, payload: dict) -> None:
    with _LOCK:
        run=_RUNS.get(run_id)
        if run is not None:run["result"]=copy.deepcopy(payload)

def result(run_id: str):
    if not valid_id(run_id):return None
    with _LOCK:
        run=_RUNS.get(run_id)
        return copy.deepcopy(run.get("result")) if run and run.get("done") else None

def usage(run_id,value):
    with _LOCK:
        if run_id in _RUNS:_RUNS[run_id]["usage"]=copy.deepcopy(value)

def pending(run_id,value):
    with _LOCK:
        if run_id in _RUNS:_RUNS[run_id]["pending_request"]=copy.deepcopy(value)

def request_stop(run_id):
    with _LOCK:
        run=_RUNS.get(run_id)
        if not run or run["done"]:return False
        run["stop_requested"]=True
        _append_unlocked(run_id,"stop","用户已请求停止","不再发起新请求；本地正在执行的几何计算可能需要结束")
        return True

def stop_requested(run_id):
    with _LOCK:return bool(_RUNS.get(run_id,{}).get("stop_requested"))
