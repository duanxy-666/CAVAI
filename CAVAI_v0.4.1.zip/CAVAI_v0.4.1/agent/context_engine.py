"""Compatibility adapter for the existing local workspace format."""
def merge_state(previous,current,user_text,turn_id):
    if not current:return previous or {}
    state=dict(current)
    state["user_statements"]=(list((previous or {}).get("user_statements") or [])+
                              [{"text":str(user_text),"turn_id":str(turn_id)}])[-100:]
    return state
