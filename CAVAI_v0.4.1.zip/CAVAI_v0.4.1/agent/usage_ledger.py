"""Append-only, local API usage ledger. Never writes keys, raw prompts or CAD geometry.

Important: provider usage and prices are authoritative only at the provider. A request
that timed out may have been charged even when no usage was returned.
"""
from __future__ import annotations

import json
import math
import re
import threading
import time
import uuid
from collections import deque
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.parse import urlsplit

from settings_store import ROOT

LEDGER_PATH = ROOT / "data" / "usage" / "events.jsonl"
_LOCK = threading.Lock()


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def scrub(value: Any, api_key: str = "") -> str:
    text = str(value)
    if api_key:
        text = text.replace(api_key, "[REDACTED_API_KEY]")
    text = re.sub(r"(?i)Bearer\s+[^\s,;'\"]+", "Bearer [REDACTED]", text)
    text = re.sub(r"\bsk-[a-zA-Z0-9_-]{8,}\b", "[REDACTED_KEY]", text)
    text = re.sub(r"(?i)(api[_-]?key|token|authorization)(=|\s*:\s*)[^&\s,;'\"]+", r"\1\2[REDACTED]", text)
    return text[:550]


def record(event: Dict[str, Any]) -> None:
    entry = {"time_utc": now_utc(), **event}
    try:
        stamp = datetime.fromisoformat(entry["time_utc"])
        if stamp.tzinfo is not None:
            entry["time_beijing"] = stamp.astimezone(timezone(timedelta(hours=8))).isoformat(timespec="milliseconds")
    except (TypeError, ValueError):
        pass
    LEDGER_PATH.parent.mkdir(parents=True, exist_ok=True)
    # Flush AND fsync so a later network/API failure doesn't erase previous calls.
    with _LOCK:
        with LEDGER_PATH.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(entry, ensure_ascii=False, default=str, separators=(",", ":")) + "\n")
            stream.flush()
            import os
            os.fsync(stream.fileno())
    if entry.get("event") in {"api_request_started", "api_request_completed", "api_request_failed",
                              "budget_blocked", "local_tool_executed", "local_review_blocked", "turn_finished"}:
        status = entry.get("error_kind") or entry.get("reason") or entry.get("stop_reason") or entry.get("message") or entry.get("result") or ""
        print("[CAVAI 0.4.1账本] {} {} turn={} request={} input={} output={} cost_CNY={} {}".format(
            entry.get("time_beijing", entry["time_utc"]), entry["event"], entry.get("turn_id", ""), entry.get("request_id", ""),
            entry.get("prompt_tokens", entry.get("estimated_input_tokens", "?")),
            entry.get("completion_tokens", "?"), entry.get("estimated_cost_cny", "?"),
            str(status)[:95]), flush=True)


def _as_dict(obj: Any) -> Dict[str, Any]:
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    if hasattr(obj, "model_dump"):
        try:
            return obj.model_dump(exclude_none=True)
        except TypeError:
            return obj.model_dump()
    return getattr(obj, "__dict__", {}) or {}


def extract_usage(response: Any) -> Dict[str, Any]:
    raw = _as_dict(getattr(response, "usage", None))
    details = raw.get("prompt_tokens_details") or {}
    if not isinstance(details, dict):
        details = _as_dict(details)
    completion_details = raw.get("completion_tokens_details") or {}
    if not isinstance(completion_details, dict):
        completion_details = _as_dict(completion_details)
    prompt = raw.get("prompt_tokens")
    completion = raw.get("completion_tokens")
    cached = details.get("cached_tokens")
    if cached is None:
        cached = raw.get("prompt_cache_hit_tokens")
    return {
        "prompt_tokens": int(prompt) if prompt is not None else None,
        "completion_tokens": int(completion) if completion is not None else None,
        "total_tokens": int(raw["total_tokens"]) if raw.get("total_tokens") is not None else None,
        "cached_input_tokens": int(cached) if cached is not None else None,
        "reasoning_tokens": int(completion_details["reasoning_tokens"]) if completion_details.get("reasoning_tokens") is not None else None,
        "cache_creation_tokens": int(raw["prompt_cache_miss_tokens"]) if raw.get("prompt_cache_miss_tokens") is not None else None,
    }


def money_estimate(settings: Dict[str, Any], prompt: Optional[int], output: Optional[int], cached: Optional[int] = None) -> Optional[float]:
    """CNY / million tokens, configured by user; never invent a vendor price."""
    if prompt is None or output is None:
        return None
    ip = settings.get("price_input_cny_million")
    op = settings.get("price_output_cny_million")
    if ip is None or op is None:
        return None
    cached = min(int(cached or 0), prompt)
    cp = settings.get("price_cached_cny_million")
    if cp is None:
        cp = ip  # conservative estimate if the special cache discount is unspecified
    return round(((prompt - cached) * ip + cached * cp + output * op) / 1_000_000, 8)


def est_tokens(payload: Dict[str, Any]) -> int:
    """Conservative byte heuristic (NOT tokenizer or actual billable token count)."""
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), default=str).encode("utf-8")
    return math.ceil(len(raw) / 1.5)


class BudgetError(RuntimeError):
    pass


class APIError(RuntimeError):
    def __init__(self, message: str, unsupported_tools: bool = False):
        super().__init__(message)
        self.unsupported_tools = unsupported_tools


class Tracker:
    def __init__(self, settings: Dict[str, Any], turn_id: str, stage: str = "review"):
        self.settings = settings
        self.turn_id = turn_id
        self.stage = stage
        self.calls = 0
        self.estimated_prompt_total = 0
        self.budget_spent = 0.0
        self.known_cost = 0.0
        self.cost_unknown_calls = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self.request_ids = []
        record({"event": "turn_started", "turn_id": turn_id, "stage": stage, "model": settings.get("model"),
                "tool_mode": settings.get("tool_mode"), "max_requests": settings.get("max_requests"),
                "max_turn_est_tokens": settings.get("max_turn_est_tokens"),
                "limits_enabled": bool(settings.get("limits_enabled", False)), "max_cost_cny": None, "prices_configured": bool(settings.get("price_input_cny_million") is not None and settings.get("price_output_cny_million") is not None)})

    def completion(self, client: Any, messages: Any, tools: Optional[Any], mode: str, round_index: int, max_tokens: Optional[int] = None, tool_choice: Optional[Any] = None) -> Any:
        from cad.geometry_transport import output_capacity
        out_limit = int(max_tokens or output_capacity(self.settings))
        kwargs: Dict[str, Any] = {"model": self.settings["model"], "messages": messages, "max_tokens": out_limit}
        if tools is not None:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = tool_choice if tool_choice is not None else "auto"
        # Only apply DeepSeek-specific parameters to the verified official hostname.
        official_deepseek = (urlsplit(self.settings.get("base_url", "")).hostname or "").lower() == "api.deepseek.com"
        if official_deepseek and self.settings["model"] in {"deepseek-flash", "deepseek-v4-pro"}:
            kwargs["extra_body"] = {"thinking": {"type": "enabled" if self.settings.get("deepseek_thinking", False) else "disabled"}}
        request_bytes = len(json.dumps(kwargs, ensure_ascii=False, default=str).encode("utf-8"))
        estimated = est_tokens(kwargs)
        # Users only configure TWO optional limits: total estimated tokens and call count.
        # 'No limit' means neither of these preflight limits is active.
        enabled = bool(self.settings.get("limits_enabled", False))
        max_req = int(self.settings.get("max_requests", 4))
        max_turn_est = int(self.settings.get("max_turn_est_tokens", 30000))
        reserve = estimated + out_limit
        candidate_cost = money_estimate(self.settings, estimated, out_limit)
        reason = None
        if enabled and self.calls >= max_req:
            reason = "本次评测最多允许 %s 次API请求" % max_req
        elif enabled and self.estimated_prompt_total + reserve > max_turn_est:
            reason = ("预计本次输入与最多输出合计 %s Token，超过你设置的 %s 上限；"
                      "已在请求发送前停止（估算非实际分词值）。" %
                      (self.estimated_prompt_total + reserve, max_turn_est))
        if reason:
            record({"event": "budget_blocked", "turn_id": self.turn_id, "stage": self.stage,
                    "round": round_index, "mode": mode, "estimated_input_tokens": estimated, "reason": reason})
            raise BudgetError("已在发送前拦截，未提交这一次API请求：" + reason)

        request_id = uuid.uuid4().hex[:16]
        self.request_ids.append(request_id)
        self.calls += 1
        self.estimated_prompt_total += reserve  # reserve the upper-bound output before sending
        if candidate_cost is not None:
            self.budget_spent += candidate_cost
        started = time.monotonic()
        record({"event": "api_request_started", "request_id": request_id, "turn_id": self.turn_id,
                "stage": self.stage, "mode": mode, "round": round_index,
                "model": self.settings["model"], "base_url": scrub(self.settings.get("base_url", ""), self.settings.get("api_key", "")),
                "endpoint": "chat/completions", "tools_sent": tools is not None,
                "official_deepseek": official_deepseek,
                "deepseek_thinking": bool(self.settings.get("deepseek_thinking", False)) if official_deepseek else None,
                "tool_names": [x["function"]["name"] for x in tools] if tools else [],
                "message_count": len(messages), "request_bytes": request_bytes,
                "estimated_input_tokens": estimated, "max_output_tokens": out_limit,
                "estimated_max_cost_cny": candidate_cost,
                "note": "估算非实际账单；API超时也可能被服务商计费。禁用SDK自动重试。"})
        try:
            response = client.chat.completions.create(**kwargs)
        except Exception as exc:
            elapsed = round((time.monotonic() - started) * 1000)
            status = getattr(exc, "status_code", None)
            raw_text = scrub(exc, self.settings.get("api_key", ""))
            lowered = raw_text.lower()
            unsupported = bool(status in (400, 422) and any(word in lowered for word in
                              ("tools", "tool_choice", "function", "tool call", "不支持", "unsupported tool", "unknown parameter")))
            if status == 402 or "insufficient_quota" in lowered:
                kind = "insufficient_quota"
                message = ("DeepSeek官方API返回402：账户余额不足（不是Tool Calling不兼容）。" if official_deepseek else
                           "服务商返回402：账户余额或额度不足。") + "此前已完成的请求仍可能已计费。"
            elif status == 401:
                kind, message = "authentication_error", "API返回401：密钥错误或没有调用权限。"
            elif status == 429:
                kind, message = "rate_limited", "API返回429：请求频率或额度限制；不会自动重试。"
            elif unsupported:
                kind, message = "unsupported_tools", "当前接口不接受原生tools参数。CAVAI标准评测已无需设置工具模式。"
            elif status == 404:
                kind, message = "model_or_route_missing", "API返回404：请核对模型名称与Base URL。"
            else:
                kind, message = "request_error", f"API调用异常（HTTP {status or '未知'}）：{raw_text}"
            record({"event": "api_request_failed", "request_id": request_id, "turn_id": self.turn_id,
                    "stage": self.stage, "mode": mode, "round": round_index, "http_status": status,
                    "duration_ms": elapsed, "error_kind": kind, "error": raw_text,
                    "usage_available": False, "billing_status": "未知；请到服务商账单核对"})
            self.cost_unknown_calls += 1
            raise APIError(message, unsupported_tools=unsupported) from exc

        usage = extract_usage(response)
        cost = money_estimate(self.settings, usage["prompt_tokens"], usage["completion_tokens"], usage["cached_input_tokens"])
        elapsed = round((time.monotonic() - started) * 1000)
        self.prompt_tokens += usage["prompt_tokens"] or 0
        self.completion_tokens += usage["completion_tokens"] or 0
        if cost is None:
            self.cost_unknown_calls += 1
        else:
            self.known_cost += cost
        choice = (getattr(response, "choices", None) or [None])[0]
        record({"event": "api_request_completed", "request_id": request_id, "turn_id": self.turn_id,
                "stage": self.stage, "mode": mode, "round": round_index,
                "provider_request_id": scrub(getattr(response, "id", "")),
                "duration_ms": elapsed, "finish_reason": getattr(choice, "finish_reason", None),
                **usage, "estimated_cost_cny": cost,
                "billing_status": "服务商使用量+本地填入的单价估算" if cost is not None else "未获得完整usage或未填入价格"})
        return response

    def finish(self, status: str, message: str = "", trace: Optional[list] = None) -> Dict[str, Any]:
        result = {
            "turn_id": self.turn_id, "status": status, "calls": self.calls,
            "prompt_tokens": self.prompt_tokens, "completion_tokens": self.completion_tokens,
            "estimated_cost_cny": round(self.known_cost, 6) if self.cost_unknown_calls == 0 else None,
            "known_portion_cost_cny": round(self.known_cost, 6), "unknown_cost_requests": self.cost_unknown_calls,
            "request_ids": self.request_ids,
        }
        record({"event": "turn_finished", **result, "message": scrub(message, self.settings.get("api_key", "")),
                "successful_tools": [x.get("tool") for x in trace or [] if x.get("ok")]})
        return result


def get_ledger_summary(limit: int = 60) -> Dict[str, Any]:
    latest = deque(maxlen=max(1, min(int(limit), 250)))
    completed, failed, blocked, pending = 0, 0, 0, set()
    prompt, completion, cost, unknown = 0, 0, 0.0, 0
    cached, uncached, cache_known, geometry_cache_hits = 0, 0, 0, 0
    if LEDGER_PATH.exists():
        with LEDGER_PATH.open("r", encoding="utf-8") as f:
            for line in f:
                try:
                    x = json.loads(line)
                except ValueError:
                    continue
                latest.append(x)
                if x.get("event") == "api_request_started":
                    pending.add(x.get("request_id"))
                elif x.get("event") == "api_request_completed":
                    pending.discard(x.get("request_id"))
                    completed += 1
                    prompt += x.get("prompt_tokens") or 0
                    completion += x.get("completion_tokens") or 0
                    if x.get("cached_input_tokens") is not None:
                        cached += x["cached_input_tokens"]
                    if x.get("uncached_input_tokens") is not None:
                        uncached += x["uncached_input_tokens"]
                        cache_known += 1
                    value = x.get("estimated_cost_cny")
                    if value is None:
                        unknown += 1
                    else:
                        cost += value
                elif x.get("event") == "api_request_failed":
                    pending.discard(x.get("request_id"))
                    failed += 1
                    unknown += 1
                elif x.get("event") == "budget_blocked":
                    blocked += 1
                elif x.get("event") == "local_tool_executed" and x.get("from_disk_cache"):
                    geometry_cache_hits += 1
    return {
        "path": str(LEDGER_PATH), "all_time": {
            "completed_requests": completed, "failed_requests": failed,
            "blocked_before_send": blocked, "pending_or_interrupted": len(pending),
            "prompt_tokens_reported": prompt, "completion_tokens_reported": completion,
            "cached_input_tokens_reported": cached, "uncached_input_tokens_reported": uncached,
            "cache_usage_known_requests": cache_known,
            "cache_hit_rate": round(cached / prompt, 4) if prompt else None,
            "local_geometry_cache_hits": geometry_cache_hits,
            "known_portion_cost_cny": round(cost, 6), "unknown_cost_requests": unknown,
        }, "events": list(reversed(latest)),
        "disclaimer": "只记录本版本运行后的请求；API返回Token用量不等于实际账单。未知费用不能当成0，超时请求也可能被计费。",
    }
