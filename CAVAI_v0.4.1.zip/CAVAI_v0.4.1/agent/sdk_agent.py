"""Thin public application entry point using the official Agents SDK."""
import asyncio
import uuid
from pathlib import Path
from cad.structured_geometry import packet
from cad.review_document import CADDocument
from agent.work import Store,ReviewWork
from agent.provider import Meter,HarnessStop,model_options,visual_input
from agent.tools import ToolBox
from agent.engine import INSTRUCTIONS,investigate
from agent.usage_ledger import record,scrub
from agent import live_progress
from settings_store import get_llm_settings
from reports.agent_report import save_agent_markdown

def _sdk_model_options(settings,intent=False):
    return model_options(settings,intent)

async def execute_sdk(work,meter,tools,settings,upload,history,prior,intent,transport=None):
    # This is the only production model/tool execution implementation.
    # No fallback hand-written SDK, private patch or guessed responses.
    import httpx
    from openai import AsyncOpenAI
    from agents import Agent,Runner,RunConfig,ModelSettings,function_tool,set_tracing_disabled
    from agents.models.openai_chatcompletions import OpenAIChatCompletionsModel
    from agents.run_config import ModelInputData
    from agent.working_context import WorkingContext
    set_tracing_disabled(True)
    timeout=httpx.Timeout(900.0,connect=20.0,write=60.0,pool=30.0)
    async with httpx.AsyncClient(timeout=timeout,follow_redirects=False,transport=transport,
        event_hooks={"request":[meter.on_request],"response":[meter.on_response]}) as client:
        async with AsyncOpenAI(api_key=settings["api_key"],base_url=settings["base_url"],
            http_client=client,max_retries=0,timeout=timeout) as provider:
            model=OpenAIChatCompletionsModel(model=settings["model"],openai_client=provider)
            agent=Agent(name="CAVAI Engineering Review",instructions=INSTRUCTIONS,
                model=model,tools=tools.build(function_tool),
                model_settings=ModelSettings(**model_options(settings,intent)))
            async def invoke(inp,turns):
                result=await Runner.run(agent,input=inp,max_turns=turns,
                                      run_config=RunConfig(tracing_disabled=True,
                                          call_model_input_filter=WorkingContext(work,meter,ModelInputData)))
                return result.final_output
            def image(text):
                try:return visual_input(text,upload,settings)
                except (OSError,ValueError) as exc:
                    live_progress.event(work.run_id,"vision","本地视图读取失败，继续几何评测",type(exc).__name__)
                    return text
            return await investigate(work,meter,tools,invoke,image,history,prior,intent)

def local_block(run_id,reason):
    record({"event":"local_review_blocked","turn_id":run_id,"reason":reason})
    usage={"turn_id":run_id,"status":"failed","stop_reason":reason,"calls":0,
           "prompt_tokens":0,"completion_tokens":0,"successful_requests":0}
    live_progress.usage(run_id,usage)
    return {"reply":reason,"provider":"local_geometry_block","tool_trace":[],"loaded_skills":[],
            "report":None,"report_id":None,"report_download_url":None,
            "turn_id":run_id,"usage":usage}

def _run(message,history,upload,inspection,trace_id,report_context,intent=False):
    run_id=trace_id if live_progress.valid_id(trace_id) else uuid.uuid4().hex
    if live_progress.snapshot(run_id) is None:live_progress.begin(run_id,"开始工程工作")
    if not upload or not inspection or inspection.get("status")!="ok" or (inspection.get("geometry") or {}).get("status")!="ok":
        return local_block(run_id,"本地真实CAD几何未成功读取，未调用付费API。")
    settings=get_llm_settings()
    if not all(settings.get(k) for k in ("base_url","api_key","model")):
        return local_block(run_id,"请先填写模型API地址、Key和模型ID。")
    work=None;meter=None;tools=None;report=None
    try:
        doc=CADDocument(packet(inspection),settings)
        prior=report_context or {}
        scope=prior.get("workspace_id") or upload.get("file_id") or run_id
        work=ReviewWork(Store(),doc,upload,settings,message,scope,run_id,
                        "intent" if intent else "review",prior)
        meter=Meter(settings,work);tools=ToolBox(work,meter)
        record({"event":"turn_started","turn_id":run_id,"model":settings["model"],
                "stage":"intent" if intent else "review","geometry_windows":len(doc.units)})
        meter.publish()
        text,complete=asyncio.run(execute_sdk(work,meter,tools,settings,upload,history,prior,intent))
        if not text or (meter.successes<1 and not any(r.get("text") for r in work.outputs.values())):
            raise HarnessStop("没有实际模型返回，不生成报告")
        status="completed" if complete else "partial"
        reason="" if complete else "部分窗口输出未完整结束；已有真实综合结果，仍有未完整核查范围"
        # Save actual result and final status before publishing terminal
        # UI. A local report-write failure is a recoverable stage outcome.
        work.finish("completed" if complete else "paused",reason,text)
        usage=meter.snapshot(status,reason)
        if not intent:
            report=save_agent_markdown(markdown=text,filename=upload.get("filename",""),
                file_id=upload.get("file_id",""),model_id=settings["model"],
                loaded_skills=list(work.skills),tool_trace=tools.trace,
                geometry_fact_ids=list(work.evidence),usage=usage,
                status=status,task_state=work.snapshot(),
                geometry_partition_state=work.coverage())
        reply=report["report"]["markdown_report"] if report else text
    except Exception as exc:
        reason=meter.reason(exc) if meter else scrub(type(exc).__name__+": "+str(exc),settings.get("api_key",""))[:350]
        if isinstance(exc,ImportError):reason="缺少官方SDK或其依赖："+scrub(str(exc),settings.get("api_key",""))[:180]
        status="incomplete" if work and work.has_output() else "failed"
        if work:
            try:work.finish("paused",reason)
            except Exception as saving:
                reason+="；本地状态保存异常："+type(saving).__name__
        reply="本轮运行已结束："+reason
        if work and work.has_output():
            reply+="\n已保存实际模型输出与工程判断，可查看阶段成果并继续原评测。"
            # Display real returned text even when nothing was formally
            # registered. Full text is available in the stage artifact.
            texts=[r["text"] for r in work.outputs.values() if r.get("text")]
            if texts:
                reply+="\n\n## 已获得的模型实际正文（节选）\n\n"+texts[0][:3200]
                if len(texts)>1:reply+="\n\n"+texts[-1][:3200]
    usage=meter.finish(status,reason) if meter else {"turn_id":run_id,"status":status,
        "stop_reason":reason,"calls":0,"prompt_tokens":0,"completion_tokens":0}
    state=work.snapshot() if work else None
    if work and work.has_output():work.write_stage()
    return {"reply":reply,"provider":"openai_agents_sdk" if meter else "local_geometry_block",
            "tool_trace":tools.trace if tools else [],"loaded_skills":list(work.skills) if work else [],
            "report":report["report"] if report else None,"report_id":report["report_id"] if report else None,
            "report_download_url":report["download_url"] if report else None,
            "turn_id":run_id,"usage":usage,"task_state":state,
            "review_result":None if intent else state,
            "engineering_state":work.export() if work and not intent else {}}

def run_review(message,history=None,upload=None,inspection=None,trace_id=None,report_context=None):
    return _run(message,history or [],upload,inspection,trace_id,report_context)

def run_intent(message,upload=None,inspection=None,trace_id=None):
    return _run(message,[],upload,inspection,trace_id,None,True)
