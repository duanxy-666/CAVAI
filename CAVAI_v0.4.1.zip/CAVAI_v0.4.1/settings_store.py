from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

ROOT = Path(__file__).resolve().parent
SETTINGS_FILE = ROOT / "data" / "settings.json"

DEFAULTS = {
    "deepseek_thinking": False,  # Official DeepSeek: default off to limit reasoning-token spend
    "tool_mode": "native",  # internal backwards compatibility; hidden from users
    "limits_enabled": False,  # opt-in: otherwise no per-review budget caps
    "staged_review_enabled": False,  # retained only for reading old settings
    "vision_mode": "auto",
    "context_window_tokens": 0,  # 0=auto; unknown providers use a conservative planning assumption
    "max_requests": 8,
    "max_request_est_tokens": 32000,
    "max_turn_est_tokens": 90000,
    "max_output_tokens": 0,  # automatic; user can explicitly set provider-supported capacity
    "max_cost_cny": None,  # no user-facing currency guesses
    "price_input_cny_million": None,
    "price_output_cny_million": None,
    "price_cached_cny_million": None,
}


def normalize_base_url(value: str) -> str:
    """Accept vendor base paths AND pasted /chat/completions endpoints."""
    from urllib.parse import urlsplit, urlunsplit
    url = value.strip().rstrip("/")
    if not url:
        return ""
    parsed = urlsplit(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("API Base URL必须是有效的http(s)地址")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("Base URL不能携带用户名、密码、query或fragment；请单独填写API Key。")
    path = parsed.path.rstrip("/")
    for ending in ("/chat/completions", "/completions"):
        if path.endswith(ending):
            path = path[:-len(ending)]
            break
    return urlunsplit((parsed.scheme, parsed.netloc, path, "", ""))


def get_llm_settings() -> Dict[str, Any]:
    data: Dict[str, Any] = {}
    if SETTINGS_FILE.exists():
        try:
            data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    result = dict(DEFAULTS)
    for name in DEFAULTS:
        if name in data and data[name] is not None:
            result[name] = data[name]
    for name in ("price_input_cny_million", "price_output_cny_million", "price_cached_cny_million"):
        if name in data:  # None is meaningful: not configured
            result[name] = data[name]
    result.update({
        "base_url": str(data.get("base_url") or os.getenv("LLM_BASE_URL", "")).strip(),
        "api_key": str(data.get("api_key") or os.getenv("LLM_API_KEY", "")).strip(),
        "model": str(data.get("model") or os.getenv("LLM_MODEL", "")).strip(),
    })
    # 5000 was the old hidden default, not a user-selected output allowance.
    # Preserve explicit settings saved under the new schema, including 5000.
    if data.get("max_output_tokens")==5000 and data.get("output_capacity_schema")!=1:
        result["max_output_tokens"]=0
    # 0.1.9 let users pick JSON mode; 0.1.10 uses native DeepSeek tools by default.
    # Don't silently spend an extra call on a fallback when the UI no longer exposes modes.
    # UI deliberately hides expert modes/pricing. Do not inherit stale expensive
    # thinking-mode or JSON fallback settings from a 0.1.9 user's local config.
    result["tool_mode"] = "native"
    result["staged_review_enabled"] = False
    result["deepseek_thinking"] = False
    result["max_cost_cny"] = None
    for field in ("price_input_cny_million", "price_output_cny_million", "price_cached_cny_million"):
        result[field] = None
    return result


def validate_limits(values: Dict[str, Any]) -> None:
    window=values.get("context_window_tokens",0)
    if type(window) is not int or (window!=0 and not 8192<=window<=10000000):
        raise ValueError("模型上下文容量填写0（自动）或8192至10000000 Token")
    if values.get("vision_mode","auto") not in {"auto","text","vision"}:
        raise ValueError("图像输入模式必须是auto/text/vision")
    if not isinstance(values.get("limits_enabled", False), bool):
        raise ValueError("是否限制用量必须是布尔值")
    if not isinstance(values.get("staged_review_enabled", True), bool):
        raise ValueError("工程分阶段检查必须是布尔值")
    if not isinstance(values.get("deepseek_thinking", False), bool):
        raise ValueError("DeepSeek思考模式必须是布尔值")
    if values["tool_mode"] not in {"auto", "native", "json"}:
        raise ValueError("API兼容模式只能是 auto、native 或 json")
    bounds = {
        "max_requests": (1, 100000),
        "max_request_est_tokens": (1000, 50000),
        "max_turn_est_tokens": (1000, 1000000000),
    }
    output=values.get("max_output_tokens",0)
    if type(output) is not int or (output!=0 and not 200<=output<=10000000):
        raise ValueError("单次输出容量填写0（自动）或200至10000000 Token")
    for key, (low, high) in bounds.items():
        value = values[key]
        if not isinstance(value, int) or isinstance(value, bool) or not low <= value <= high:
            raise ValueError("{}需设置在{}~{}之间".format(key, low, high))
    for key in ("max_cost_cny", "price_input_cny_million", "price_output_cny_million", "price_cached_cny_million"):
        val = values.get(key)
        if val is not None and (not isinstance(val, (int, float)) or isinstance(val, bool) or not 0 <= val <= 100000):
            raise ValueError("{}必须为非负数字或留空".format(key))


def save_llm_settings(base_url: str, api_key: str, model: str, **options: Any) -> None:
    SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
    combined = get_llm_settings()
    combined.update(options)
    combined.update({"base_url": normalize_base_url(base_url), "api_key": api_key.strip(), "model": model.strip()})
    validate_limits(combined)
    combined["output_capacity_schema"]=1
    temp = SETTINGS_FILE.with_suffix(".tmp")
    temp.write_text(json.dumps(combined, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(SETTINGS_FILE)


def public_settings() -> Dict[str, Any]:
    data = get_llm_settings()
    key = data["api_key"]
    return {
        "base_url": data["base_url"],
        "model": data["model"],
        "api_key_configured": bool(key),
        "api_key_masked": (key[:4] + "…" + key[-4:]) if len(key) > 10 else ("已保存" if key else ""),
        "configured": bool(data["base_url"] and key and data["model"]),
        **{k: data[k] for k in DEFAULTS},
    }
