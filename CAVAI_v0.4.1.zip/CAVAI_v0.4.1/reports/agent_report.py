"""Persist the actual LLM-created final report; never ask the LLM to call a save-file tool.

A report file exists only after a real model response. No synthetic answers are written.
"""
from __future__ import annotations
import json
import os
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

from reports.store import REPORT_DIR


def recorded_conflicts_markdown(rows):
    conflicts = [row for row in rows if row.get('status')=='contradicted']
    if not conflicts:
        return ''
    lines=['## 已登记的工程矛盾',
           '以下为本轮模型实际登记的判断索引；程序只核验记录和证据引用，不独立证明工程语义。']
    for row in conflicts:
        basis = '用户明确要求' if row['basis']=='user_requirement' else '功能假设下的必要条件'
        lines.append('- **'+row['condition']+'**（'+basis+'）：'+row['consequence']
                     +'；证据：'+', '.join(row['evidence_ids'])+'。')
        if row.get('location'):
            lines.append('  - 位置：'+row['location'])
        if row.get('recommendation'):
            lines.append('  - 改进：'+row['recommendation'])
    return '\n\n'.join(lines)


def save_agent_markdown(*, markdown: str, filename: str, file_id: str,
                        model_id: str, loaded_skills: list,
                        tool_trace: list, geometry_fact_ids: list,
                        usage: dict, status: str = 'completed', task_state: dict = None, geometry_partition_state: dict = None) -> Dict[str, Any]:
    content = (markdown or '').strip()
    if not content:
        raise ValueError('模型未返回报告正文；不能凭空生成报告。')
    if status not in {'completed', 'partial'}:
        raise ValueError('不支持的报告状态')
    ident = uuid.uuid4().hex
    rows = (task_state or {}).get('findings') or []
    conflicts = recorded_conflicts_markdown(rows)
    model_text = content
    if conflicts and (task_state or {}).get('schema') not in {'cavai-harness-work-1','cavai-harness-work-2'}:
        content = conflicts+'\n\n---\n\n'+model_text
    coverage=(task_state or {}).get("coverage",{})
    if status=="partial":
        content="> 部分工程评测：仍有未自然结束的几何窗口。下文为模型实际综合正文，不代表整体验收。\\n\\n".replace("\\n","\n")+content
    truncated=coverage.get('truncated_readings',[])
    if truncated:
        content=('> 本报告为部分验证结果：以下几何数据包的模型阅读正文达到输出上限：'
                 +'、'.join(truncated)+'。原始数据已送达，但不能证明完整语义核查。\n\n'+content)
    requirements = [{'requirement':f['condition'],
                     'status':{'supported':'pass','contradicted':'fail','insufficient':'not_checked','not_applicable':'not_applicable'}[f['status']],
                     'evidence':', '.join(f['evidence_ids']), 'reasoning':f['reasoning']}
                    for f in rows if f['basis']=='user_requirement']
    findings = [{'title':f['condition'],'severity':'info','detail':f['reasoning']+'；'+f['consequence'],
                 'status':f['status'],'basis':f['basis'],'evidence_ids':f['evidence_ids'],
                 'measurement_check':f.get('measurement_check')}
                for f in rows if f['status'] in ('contradicted','insufficient')]
    overall = 'fail' if any(f['basis']=='user_requirement' and f['status']=='contradicted' for f in rows) else (
              'conditional_conflict' if any(f['status']=='contradicted' for f in rows) else 'inconclusive')
    payload = {
        'report_id': ident,
        'title': 'CAVAI Agent CAD 工程评测报告',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'report_source': 'agent_llm_output',
        'report_status': status,
        'overall_status': overall,  # No global pass inferred from checklist completion.
        'summary': content[:2000],
        'markdown_report': content,
        'model_markdown_original': model_text,
        'requirements': requirements,
        'findings': findings,
        'engineering_findings': rows,
        'model_filename': filename,
        'model_file_id': file_id,
        'model_id': model_id,
        'actual_skill_names': sorted(set(loaded_skills)),
        'actual_tool_trace': tool_trace[:40],
        'queried_evidence_ids': sorted(set(geometry_fact_ids)),
        'usage': usage,
        'task_state':task_state or {},
        'geometry_partition_state':geometry_partition_state or {},
    }
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    target_json = REPORT_DIR / f'{ident}.json'
    target_md = REPORT_DIR / f'{ident}.md'
    scratch_json = target_json.with_suffix('.json.tmp')
    scratch_md = target_md.with_suffix('.md.tmp')
    try:
        scratch_md.write_text(content + '\n', encoding='utf-8')
        scratch_json.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(scratch_md, target_md)
        os.replace(scratch_json, target_json)
    finally:
        scratch_md.unlink(missing_ok=True)
        scratch_json.unlink(missing_ok=True)
    return {'report_id': ident, 'report': payload,
            'download_url': f'/api/reports/{ident}/download/markdown',
            'report_status': status}
