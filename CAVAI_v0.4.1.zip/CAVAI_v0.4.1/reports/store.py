from __future__ import annotations

import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

ROOT = Path(__file__).resolve().parent.parent
REPORT_DIR = ROOT / "data" / "reports"
REPORT_DIR.mkdir(parents=True, exist_ok=True)


def save_review_report(report: Dict[str, Any]) -> Dict[str, Any]:
    report_id = uuid.uuid4().hex
    payload = dict(report)
    payload.setdefault("title", "CAD设计评测报告")
    payload.setdefault("overall_status", "inconclusive")
    payload.setdefault("summary", "")
    payload.setdefault("requirements", [])
    payload.setdefault("findings", [])
    payload.setdefault("evidence", [])
    payload.setdefault("limitations", [])
    payload["report_id"] = report_id
    payload["created_at"] = datetime.utcnow().isoformat() + "Z"
    path = REPORT_DIR / (report_id + ".json")
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return {"report_id": report_id, "report": payload, "download_url": "/api/reports/{}/download".format(report_id)}


def read_review_report(report_id: str) -> Dict[str, Any]:
    path = REPORT_DIR / (report_id + ".json")
    if not path.exists():
        raise FileNotFoundError(report_id)
    return json.loads(path.read_text(encoding="utf-8"))
