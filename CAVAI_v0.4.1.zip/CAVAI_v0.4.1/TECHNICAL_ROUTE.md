# CAVAI v0.4.1 技术路线：不可变原始数据与逐轮工作集

## 1. 架构

```text
CATIA / STEP
  → 既有真实 CAD 提取
  → 完整原始 JSON + 真实拓扑索引 + 可选视图 + 确定性 Rule
  → CADDocument：尽量少的精确关联窗口（完整原始字段归属）
  → 官方 Agents SDK Runner
       ├─ 首次调用：原始窗口 + 全局结构 + 相关工作记忆
       ├─ Model：用途假设、选择 Skill、工程判断、主动取证
       ├─ Tools：原始字段查询、精确测量、批量测量、记忆召回
       ├─ ReviewWork：证据、判断、已选 Skill、可见输出、工具交互
       └─ 每次后续调用前：
            call_model_input_filter
            → 归档已取得的真实工具结果
            → 构造当前数值几何与相关工作记忆
            → 保留最新完整调用与返回批次
            → 仅当确有字节收益且消息格式可处理时采用工作集
  → 同一工程目标持续推进
  → 必要的综合复核 / 原报告、阶段成果与历史接口
```

模型负责功能理解、专业推理及工程结论；Harness 管理原始信息、工具、
可检索记忆、输入工作集和真实交付。数据不会因为移出当前模型输入而删除。
不以压缩后的自然语言代替原始 CAD 精确值，不使用 CAD 逆向重建门槛。

## 2. 实际模块

| 模块 | 实现 |
|---|---|
| cad/review_document.py | 完整原始字段归属、关联依赖窗口，首次全局数值目录与后续小型框架 |
| cad/geometry_transport.py | 统一输出容量、原始字节和保守 Token 估算；依据实际 DeepSeek 账本校准该接口的规划 |
| agent/working_context.py | 动态工作集、文本/实体/空间相关性召回、精确工具对归档、SDK 输入过滤 |
| agent/work.py | 工作身份、SQLite 持久状态、证据、判断、交互和确定性测量索引 |
| agent/tools.py | 原始数据和历史回读、基于已有 OCCT 算法的批量测量、相关工作记录召回 |
| agent/engine.py | 工程目标连续推进、按相关性装入记忆、最终综合 |
| agent/sdk_agent.py | 官方 SDK 0.8.4 RunConfig.call_model_input_filter 接入 |
| agent/provider.py | 实际请求/响应观测、输入管理统计、原有停止及重复请求保护 |

## 3. 原始数据管理的边界

全局目录和区域窗口不是模型生成的几何摘要。所有已提取原始字段
在本地保持原值，并在各窗口首请求提供。常规区域保留面、环、边、
顶点的真实关联依赖，不能因为追求少字节而破坏它们。
首次加载新的专业 Skill 后保留原始窗口用于实际应用。
对于后续请求，当前局部数值记录、已取得证据与工具返回组成工作集。
确需此前详细曲线、曲面、拓扑字段时，使用原始数据或历史记录工具回读。
大块历史工具结果按调用 ID 归档，最新的完整工具请求/响应批次原样保留。
不保存或伪造隐藏推理；对于无法识别的 SDK 协议项保守不裁剪。
有视觉能力时保留当前输入中真实图像，不把图像引用当成模型已经看过。

文本/ID/空间范围是确定性召回线索，不是语义等价判断。
原始测量的相同数值可复用，近似测量不合并。新问题仍可主动取证。
初次窗口数的调整源于真实旧账本输入 Token/HTTP 字节比值约 0.334–0.386，
采用较保守的 0.60 系数和额外容量余量；它不是准确 tokenizer，
对未验证的模型、编码或超大装配体不能保证不超过提供商实际容量。

## 4. 技术依据及实际应用

- [OpenAI Agents SDK 0.8.4 RunConfig 源码](https://raw.githubusercontent.com/openai/openai-agents-python/v0.8.4/src/agents/run_config.py)：
  使用该固定版本公开的 CallModelData、ModelInputData 与 call_model_input_filter，
  不更换 SDK、不自建工具调用循环。
- [OpenAI Agents SDK Running agents](https://openai.github.io/openai-agents-python/running_agents/)：
  每次模型调用前组织输入；保留消息及工具协议有效性。
- [Anthropic Effective context engineering for AI agents](https://www.anthropic.com/research/effective-context-engineering-for-ai-agents)：
  借鉴按需加载、外部工作记录与当前上下文分离。没有引入 Claude 专有 API。
- [DeepSeek Multi-round Conversation](https://api-docs.deepseek.com/guides/multi_round_chat/)：
  当前 Chat Completions 多轮输入由客户端管理，因此本地数据库不是服务端模型记忆。
- [AgentScope](https://github.com/agentscope-ai/agentscope)：
  参考大型工具输出外存和动态上下文的思想；没有整包引入或替换既有 SDK。

现有专业 Skill 的内容及来源记录逐字节保留。新增加的工具只组合已有
真实几何读取、点分类及体积占据算法，不引入自编专业 Skill。

## 5. 验证

实际源码和数据测试见 TEST_RESULTS.txt。真实 CAD JSON 首次窗口原始字段一致；
受控 SDK 输入项回放测量实际序列化字节差，不将其冒充远程 Token 用量。
当前未安装官方 SDK，生产 hook 的真实 SDK 运行仍需在既有实机依赖环境中验证。
模型输出是否更准确、实际成本是否下降以及超大装配体的适用性均待真实对照。
