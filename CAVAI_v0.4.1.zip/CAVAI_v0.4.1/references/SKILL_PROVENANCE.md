# 0.4.0 当前 Skill 来源

仅随包包含 `skills/mechanical-design-review`，以及加载它的原 registry。
该目录下的 SKILL.md、LICENSE.upstream、SOURCE.json 与上一版逐字节一致。
具体原始来源、授权、适配记录以目录内 SOURCE.json 和 LICENSE.upstream 为准。
本次未重新下载上游 Skill，也未声称验证其完整上游对应关系。
历史版本的来源文档另存为 SKILL_PROVENANCE_HISTORICAL.md，
其中列出的历史 Skill 或方案不代表当前包仍包含其代码。
