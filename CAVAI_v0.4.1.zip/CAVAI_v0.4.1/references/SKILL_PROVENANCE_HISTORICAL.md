# Skill 源码出处、授权与适配说明（CAVAI_v0.1.12）

## 统一规范

- **Agent Skills**：https://github.com/agentskills/agentskills/blob/main/docs/specification.mdx
  - 采用 `SKILL.md` + `references/` 的包装约定，按需加载。并非复制该规范仓库的运行时。

## 领域参考

- **earthtojake/text-to-cad / DFM Skill**（仓库MIT）：https://github.com/earthtojake/text-to-cad/blob/main/skills/dfm/SKILL.md
  - 借鉴“依据工艺选择不同检查方法/规则”的思路，作为 `manufacturing-dfm-review` 的检查问题来源。
  - **未移植** `cad model dfm`、模具分析器、FreeCAD或该项目服务端；这些命令不在CAVAI中提供。
- **dooosp/freecad-automation**：https://github.com/dooosp/freecad-automation
  - 借鉴“设计意图→可检查项→本地证据→报告”的阶段式工作流。
  - **未复制**其`dfm_checker.py`实现或FreeCAD可执行程序，因目标环境是CATIA V5 / Python3.9。
- **OpenAI Agents SDK 0.8.4**：https://pypi.org/project/openai-agents/0.8.4/
  - 实际通过其 `Agent`、`Runner`、`function_tool` 进行Agent多轮调度。此依赖安装自PyPI，不随源码包分发。
- **pycatia**：https://github.com/evereux/pycatia
  - 调用CATIA V5 COM，非Python版CATIA建模引擎。

## 本包实际包含的代码

- `agent/sdk_agent.py`：使用Agents SDK并暴露本地只读的CAD检索工具与Skill按需读取工具。
- `cad/*`：原CAVAI基于OCP/pycatia的已有本地几何读取模块。
- `skills/fastener-review`、`skills/fixture-review`、`skills/manufacturing-dfm-review`：CAVAI**原创适配**的说明与检查问题（非移植的外部DFM程序）。
- `skills/registry.py`：只加载随本软件包预装的Skill，禁止任意磁盘路径读取。

## 实现边界

运行时不访问GitHub，也不自行安装外部Skill。`SKILL.md` 不是可执行的几何求解器，几何证据由现有Python工具提供；力学求解、工艺过程模拟与全面装配干涉检查目前不在已验证的实现范围。没有引入独立Benchmark评分模块。
