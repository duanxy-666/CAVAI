"""Optional genuine SDK smoke test with a controlled HTTP provider.

No fake agents/openai modules are loaded. Run this after installing the
pinned official requirements. It does not send an external request.
"""
import asyncio
import importlib.util
import json
import tempfile
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch
import httpx
from cad.review_document import CADDocument
from agent.work import Store,ReviewWork
from agent.provider import Meter
from agent.tools import ToolBox
from agent.sdk_agent import execute_sdk
from agent import live_progress,usage_ledger
from tests.test_harness import CFG,fixture,response,SKILL

HAS_SDK=all(importlib.util.find_spec(x) is not None for x in ("agents","openai"))
@unittest.skipUnless(HAS_SDK,"official agents/openai packages are not installed")
class GenuineSDKTest(unittest.TestCase):
    def test_real_agent_runner_native_tool_calls(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td);cad=path/"fixture.step";cad.write_bytes(b"identity fixture")
            rid=uuid.uuid4().hex;live_progress.begin(rid,"SDK fixture")
            upload={"path":str(cad),"filename":"fixture.step","file_id":"fixture"}
            w=ReviewWork(Store(path/"memory.sqlite3"),CADDocument(fixture(),CFG),upload,
                CFG,"controlled SDK smoke","scope",rid,stage_dir=path/"stages")
            meter=Meter(CFG,w);box=ToolBox(w,meter)
            calls=[]
            def tool(name,args,i):
                return {"id":f"call_{i}","type":"function","function":{"name":name,"arguments":json.dumps(args)}}
            def provider(req):
                body=json.loads(req.content);calls.append(body)
                self.assertEqual(body["max_tokens"],65536)
                self.assertEqual(body.get("thinking"),{"type":"disabled"})
                self.assertTrue(body.get("tools"))
                n=len(calls)
                if n==1:
                    return response(None,"tool_calls",[
                        tool("load_skill",{"name":SKILL},1),
                        tool("read_geometry",{"pointer":"/geometry/solid_count","offset":0,"limit":20},2)])
                if n==2:
                    eid=next(e["id"] for e in w.evidence.values() if e["tool"]=="read_geometry")
                    return response(None,"tool_calls",[tool("record_finding",{
                        "title":"Controlled test","condition":"fixture count","basis":"user_requirement",
                        "status":"supported","location":"fixture","reasoning":"actual fixture count",
                        "consequence":"controlled result","recommendation":"none",
                        "evidence_ids":[eid],"finding_id":"SDK-F1","severity":"info","correction_reason":""},3)])
                return response("Controlled genuine SDK final response")
            with patch.object(usage_ledger,"LEDGER_PATH",path/"events.jsonl"):
                text,complete=asyncio.run(execute_sdk(w,meter,box,CFG,upload,[],{},False,
                    transport=httpx.MockTransport(provider)))
            self.assertTrue(complete)
            self.assertEqual(text,"Controlled genuine SDK final response")
            self.assertEqual(len(calls),3)
            self.assertIn(SKILL,w.skills);self.assertIn("SDK-F1",w.findings)

if __name__=="__main__":unittest.main()
