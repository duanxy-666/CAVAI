import json
import tempfile
import unittest
import uuid
from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
import httpx
from fastapi.testclient import TestClient
import main, workspace_store
import cad.evidence_store
import agent.work, agent.sdk_agent, agent.usage_ledger
import reports.agent_report, reports.store
from agent.engine import investigate
from settings_store import get_llm_settings
from tests.test_harness import response, CFG

class ApplicationHTTPTest(unittest.TestCase):
    def test_step_upload_review_and_download(self):
        with tempfile.TemporaryDirectory() as td, ExitStack() as stack:
            p=Path(td)
            for mod, attr, path in [
                (main,"UPLOAD_DIR",p/"uploads"),(main,"REPORT_DIR",p/"reports"),
                (workspace_store,"UPLOAD_DIR",p/"uploads"),
                (workspace_store,"WORKSPACE_DIR",p/"workspaces"),
                (workspace_store,"EVIDENCE_DIR",p/"evidence"),
                (workspace_store,"REPORT_DIR",p/"reports"),
                (cad.evidence_store,"EVIDENCE_DIR",p/"evidence"),
                (reports.agent_report,"REPORT_DIR",p/"reports"),
                (reports.store,"REPORT_DIR",p/"reports"),
                (agent.work,"DB_PATH",p/"work.sqlite3"),
                (agent.work,"STAGE_DIR",p/"stages"),
                (agent.usage_ledger,"LEDGER_PATH",p/"events.jsonl")]:
                stack.enter_context(patch.object(mod,attr,path))
            stack.enter_context(patch.object(main,"UPLOADS",{}))
            cfg={**get_llm_settings(),**CFG}
            for mod in (main,agent.sdk_agent):
                stack.enter_context(patch.object(mod,"get_llm_settings",return_value=cfg))
            requests=[]
            async def controlled(work,meter,tools,settings,upload,history,prior,intent):
                def handler(req):
                    requests.append(json.loads(req.content))
                    return response("Controlled HTTP integration report; not an engineering conclusion.")
                async with httpx.AsyncClient(transport=httpx.MockTransport(handler),
                    event_hooks={"request":[meter.on_request],"response":[meter.on_response]}) as client:
                    async def invoke(inp,turns):
                        r=await client.post(CFG["base_url"]+"/chat/completions",json={
                            "messages":[{"role":"user","content":inp}],"max_tokens":65536})
                        return r.json()["choices"][0]["message"]["content"]
                    return await investigate(work,meter,tools,invoke,lambda x:x,history,prior,intent)
            stack.enter_context(patch.object(agent.sdk_agent,"execute_sdk",controlled))
            client=TestClient(main.app)
            step=Path(__file__).resolve().parents[1]/"examples"/"through_hole.step"
            result=client.post("/api/upload",files={"file":(step.name,step.read_bytes(),"application/octet-stream")})
            self.assertEqual(result.status_code,200,result.text)
            file_id=result.json()["file_id"]
            geometry=client.get(f"/api/models/{file_id}/geometry/download")
            self.assertEqual(geometry.status_code,200,geometry.text[:400])
            doc=geometry.json()
            self.assertTrue(doc["geometry"]["face_count"]>0)
            rid=uuid.uuid4().hex
            result=client.post("/api/chat",json={"file_id":file_id,"trace_id":rid,
                "mode":"review","message":"Controlled integration test"})
            self.assertEqual(result.status_code,200,result.text)
            out=result.json()
            self.assertEqual(out["usage"]["status"],"completed",out)
            self.assertEqual(len(requests),1)
            self.assertTrue(out["report_id"],out)
            self.assertIn("Controlled HTTP integration report",out["reply"])
            self.assertEqual(client.get(f"/api/runs/{rid}/result").status_code,200)
            stage=client.get(f"/api/runs/{rid}/stage")
            self.assertEqual(stage.status_code,200)
            self.assertIn("Controlled HTTP integration report",stage.text)
            self.assertEqual(client.get(out["report_download_url"]).status_code,200)
            self.assertTrue(workspace_store.get_workspace(out["session_id"])["reports"])
            self.assertEqual(client.get(f"/api/runs/{rid}/events").json()["status"],"completed")
            self.assertEqual(client.post("/api/chat",json={"file_id":file_id,
                "session_id":out["session_id"],"trace_id":rid,
                "mode":"review","message":"Controlled integration test"}).status_code,409)
            self.assertEqual(len(requests),1)
