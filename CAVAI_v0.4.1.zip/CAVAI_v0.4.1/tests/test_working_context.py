"""SDK input-filter contract tests. No invented live model output."""
import copy
import json
import tempfile
import unittest
import uuid
from pathlib import Path
from dataclasses import dataclass
from types import SimpleNamespace
from unittest.mock import patch
from cad.geometry_transport import encode,size
from cad.review_document import CADDocument
from agent.work import Store,ReviewWork
from agent.engine import make_prompt
from agent.working_context import (WorkingContext,HEADER,CONTINUATION,latest_batch,
    pairs,recall_records,active_geometry)
from agent.tools import ToolBox
from agent import live_progress,usage_ledger
from agent.provider import Meter
from tests.test_harness import fixture,CFG,SKILL

@dataclass
class InputData:
    input:list
    instructions:str

def message(prompt):
    return {"role":"user","content":prompt}

def call(name,args,ident):
    return {"type":"function_call","name":name,"arguments":encode(args),"call_id":ident}

def result(ident,data):
    return {"type":"function_call_output","call_id":ident,"output":data if isinstance(data,str) else encode(data)}

class WorkingContextTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.path=Path(self.tmp.name)
        self.cad=self.path/"test.step";self.cad.write_bytes(b"fixture")
        data=fixture()
        # Uninterpreted exact future geometry data is large enough that
        # re-sending it would dominate each continuation request.
        data["extra_future_fields"]={"dense":[i/11 for i in range(28000)],
                                     "literal":"exact_source_marker"}
        self.doc=CADDocument(data,CFG)
        self.assertEqual(self.doc.reconstruct(),data)
        self.rid=uuid.uuid4().hex;live_progress.begin(self.rid,"context fixture")
        self.w=ReviewWork(Store(self.path/"memory.sqlite3"),self.doc,
            {"path":str(self.cad),"filename":"fixture.step","file_id":"fixture"},
            CFG,"fixture review","fixture",self.rid,stage_dir=self.path/"stages")
        self.meter=Meter(CFG,self.w);self.box=ToolBox(self.w,self.meter)
        self.unit=self.doc.units[0];self.w.start_unit(self.unit["id"])
        self.filter=WorkingContext(self.w,self.meter,InputData)
        self.root=message(make_prompt(self.w,self.unit))
        self.tools={f.__name__:f for f in self.box.build(lambda f:f)}
        self.patch=patch.object(usage_ledger,"LEDGER_PATH",self.path/"events.jsonl")
        self.patch.start();self.addCleanup(self.patch.stop)

    def filter_items(self,items):
        return self.filter(SimpleNamespace(model_data=InputData(items,"unchanged instructions")))

    def test_first_input_and_first_skill_application_are_exact(self):
        first=self.filter_items([self.root])
        self.assertEqual(first.input,[self.root])
        self.assertEqual(first.instructions,"unchanged instructions")
        self.assertEqual(self.meter.context_metrics["mode"],"initial_exact_source")
        skill=self.tools["load_skill"](SKILL)
        items=[self.root,call("load_skill",{"name":SKILL},"s1"),result("s1",skill)]
        out=self.filter_items(items)
        base=json.loads(out.input[0]["content"].split("\n",1)[1])
        self.assertEqual(base["current_exact_geometry"],self.unit)
        self.assertEqual(out.input[-2:],items[-2:])
        self.assertEqual(len(self.w.interactions),1)

    def test_followup_keeps_latest_parallel_pairs_and_retrievable_old_values(self):
        old_args={"pointer":"/geometry/solid_count","offset":0,"limit":20}
        old_value=self.tools["read_geometry"](**old_args)
        args1={"pointer":"/geometry/face_count","offset":0,"limit":20}
        args2={"pointer":"/geometry/edge_count","offset":0,"limit":20}
        value1=self.tools["read_geometry"](**args1)
        value2=self.tools["read_geometry"](**args2)
        items=[self.root,call("read_geometry",old_args,"a"),result("a",old_value),
            {"type":"message","role":"assistant","content":[{"type":"output_text","text":"fixture observation"}]},
            call("read_geometry",args1,"b"),call("read_geometry",args2,"c"),
            result("b",value1),result("c",value2)]
        before=copy.deepcopy(items)
        out=self.filter_items(items)
        self.assertEqual(items,before)
        self.assertEqual(out.input[1:],items[3:])
        self.assertEqual(self.meter.context_metrics["mode"],"active_working_set")
        self.assertNotIn("current_exact_geometry",json.loads(out.input[0]["content"].split("\n",1)[1]))
        self.assertLess(size(out.input),size(items)*.5)
        self.assertEqual(len(self.w.interactions),3)
        archived=next(v for v in self.w.interactions.values() if v["call_id"]=="a")
        self.assertEqual(archived["output"],old_value)
        exact=json.loads(self.tools["read_work_record"]("interactions",archived["id"],"/output"))
        self.assertEqual(exact["value"],old_value)
        original=json.loads(self.tools["read_work_record"]("source_windows",self.unit["id"],"/source_sha256"))
        self.assertEqual(original["value"],self.doc.sha)
        # Latest results already occupy the SDK tool protocol group; they
        # must not also occur as duplicated full values in work_memory.
        working=json.loads(out.input[0]["content"].split("\n",1)[1])
        latest={json.loads(value1)["evidence_id"],json.loads(value2)["evidence_id"]}
        self.assertEqual(set(working["work_memory"]["in_flight_evidence_ids"]),latest)
        self.assertFalse(latest&{v["id"] for v in working["work_memory"]["evidence"]})

    def test_malformed_or_unrecognized_protocol_is_not_cut(self):
        items=[self.root,result("orphan","fixture")]
        self.assertEqual(self.filter_items(items).input,items)
        self.assertEqual(self.meter.context_metrics["mode"],"unrecognized_history_preserved")
        items=[self.root,{"type":"custom_tool_call","call_id":"other"},result("other","fixture")]
        self.assertEqual(self.filter_items(items).input,items)

    def test_picture_and_latest_reasoning_protocol_preserved_without_archiving_reasoning(self):
        user={"role":"user","content":[{"type":"input_text","text":self.root["content"]},
            {"type":"input_image","image_url":"data:image/png;base64,fixture","detail":"auto"}]}
        args={"pointer":"/geometry/solid_count","offset":0,"limit":20}
        value=self.tools["read_geometry"](**args)
        reasoning={"type":"reasoning","id":"rs_latest","summary":[]}
        items=[user,reasoning,call("read_geometry",args,"a"),result("a",value)]
        out=self.filter_items(items)
        self.assertEqual(out.input[0]["content"][1],user["content"][1])
        self.assertEqual(out.input[-3:],items[-3:])
        self.assertEqual(len(self.w.interactions),1)
        self.assertNotIn("reasoning",encode(list(self.w.interactions.values())))

    def test_exact_cached_measurement_returns_data_even_after_window_change(self):
        count=[]
        args={"point_mm":[1.0,2.0,-0.0]}
        def calculate():
            count.append(1);return {"classification":"inside"}
        a=json.loads(self.box.measured("classify_model_point",args,calculate))
        self.box.new_window()
        b=json.loads(self.box.measured("classify_model_point",{"point_mm":[1,2,0]},calculate))
        self.assertEqual(len(count),1)
        self.assertEqual(a["evidence_id"],b["evidence_id"])
        self.assertEqual(b["data"],{"classification":"inside"})
        self.assertTrue(b["reused_measurement"])
        c=json.loads(self.box.measured("classify_model_point",{"point_mm":[1,2,0.00001]},calculate))
        self.assertEqual(len(count),2)
        self.assertNotEqual(a["evidence_id"],c["evidence_id"])
        recalled=recall_records(self.w,"",[],[.9,1.9,-.1],[1.1,2.1,.1])
        ids={r["id"] for r in recalled if r["category"]=="evidence"}
        self.assertEqual(ids,{a["evidence_id"],c["evidence_id"]})

    def test_batch_reuses_identical_probes_without_merging_nearby_points(self):
        with patch("agent.tools.classify_point",return_value={"classification":"inside"}) as calc, \
             patch.object(self.box,"shape",return_value=object()):
            response=json.loads(self.tools["measure_geometry_batch"](
                [[1,2,3],[1.0,2.0,3.0],[1,2,3.001]],[],[],"fixture"))
        self.assertEqual(calc.call_count,2)
        self.assertEqual(len(response["results"]),3)
        self.assertEqual(response["results"][1]["duplicate_of"],0)
        self.assertEqual(response["results"][0]["evidence_id"],response["results"][1]["evidence_id"])
        self.assertNotEqual(response["results"][2]["evidence_id"],response["results"][0]["evidence_id"])

    def test_archived_tool_history_survives_restart(self):
        args={"pointer":"/geometry/solid_count","offset":0,"limit":20}
        value=self.tools["read_geometry"](**args)
        self.filter_items([self.root,call("read_geometry",args,"original"),result("original",value)])
        restored=ReviewWork(Store(self.path/"memory.sqlite3"),self.doc,self.w.upload,CFG,
            self.w.goal,"fixture",uuid.uuid4().hex,stage_dir=self.path/"stages")
        self.assertEqual(restored.identity,self.w.identity)
        self.assertEqual(restored.interactions,self.w.interactions)

if __name__=="__main__":unittest.main()
