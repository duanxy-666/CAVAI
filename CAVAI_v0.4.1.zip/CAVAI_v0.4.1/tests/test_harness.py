import asyncio
import json
import math
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import httpx
from cad.geometry_transport import capacity,output_capacity,size,encode,payload_estimate
from cad.review_document import CADDocument,restore
from agent.work import Store,ReviewWork
from agent.provider import Meter,HarnessStop,cancellable
from agent.tools import ToolBox,page,cylinder_occupancy
from agent.engine import investigate,make_prompt
from agent import live_progress,usage_ledger

CFG={"base_url":"https://api.deepseek.com","model":"deepseek-flash",
     "api_key":"offline-fixture","vision_mode":"text","limits_enabled":False}
SKILL="mechanical-design-review"

def fixture():
    # Deliberately small synthetic document used to test the Harness,
    # not an actual mechanical acceptance result.
    return {"schema":"fixture","geometry":{"coordinate_unit":"mm",
        "solid_count":1,"face_count":1,"edge_count":1,
        "bounding_box_mm":{"min":[0,0,0],"max":[10,10,10]},
        "faces":[{"face_id":"F000001","surface_type":"plane","area":100,"center_of_mass":[5,5,0],
                  "normal":[0,0,1],"edge_ids":["E000001"],"solid_ids":["S0001"]}],
        "edges":[{"edge_id":"E000001","curve_type":"line","length":10}],
        "solids":[{"solid_id":"S0001","volume":1000}],
        "structured_topology":{"nodes":[
            {"id":"N1","type":"face","properties":{"bbox":[0,0,0,10,10,0]},
             "children":[{"id":"N2"}]},
            {"id":"N2","type":"wire","properties":{},"children":[{"id":"N3"}]},
            {"id":"N3","type":"edge","properties":{"length":10},"children":[{"id":"N4"}]},
            {"id":"N4","type":"vertex","properties":{"point":[0,0,0]},"children":[]}],
            "legacy_to_node":{"F000001":"N1","E000001":"N3"},"edge_to_faces":{"N3":["N1"]}}},
        "part":{"name":"fixture"},"source_limitations":[]}

def response(text="Controlled visible response",finish="stop",tools=None,prompt=200,output=50):
    msg={"role":"assistant","content":text}
    if tools is not None:msg["tool_calls"]=tools
    return httpx.Response(200,json={"id":"chatcmpl-controlled","object":"chat.completion","created":1,
        "model":"offline-fixture","choices":[{"index":0,"message":msg,"finish_reason":finish}],
        "usage":{"prompt_tokens":prompt,"completion_tokens":output,"total_tokens":prompt+output,
                 "prompt_cache_hit_tokens":0}})

class HarnessTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.store=Store(self.root/"memory.sqlite3")
        self.source=self.root/"fixture.step";self.source.write_bytes(b"fixture identity, not a CAD file")
        self.upload={"path":str(self.source),"filename":"fixture.step","file_id":"fixture"}
        self.patch=patch.object(usage_ledger,"LEDGER_PATH",self.root/"events.jsonl")
        self.patch.start();self.addCleanup(self.patch.stop)
        self.doc=CADDocument(fixture(),CFG)
    def new(self,goal="test goal",settings=None,scope="workspace"):
        import uuid
        rid=uuid.uuid4().hex;live_progress.begin(rid,"test")
        return ReviewWork(self.store,self.doc,self.upload,settings or CFG,goal,scope,rid,
                          stage_dir=self.root/"stages")
    def events(self):
        path=self.root/"events.jsonl"
        return [json.loads(s) for s in path.read_text("utf-8").splitlines()] if path.is_file() else []
    def post(self,work,meter,handler,body=None):
        async def go():
            async with httpx.AsyncClient(transport=httpx.MockTransport(handler),
                event_hooks={"request":[meter.on_request],"response":[meter.on_response]}) as client:
                return await client.post(CFG["base_url"]+"/chat/completions",
                     json=body or {"messages":[{"role":"user","content":"fixture"}],"max_tokens":1000})
        return asyncio.run(go())
    def test_full_document_original_fields(self):
        self.assertEqual(self.doc.units[0]["kind"],"full")
        self.assertEqual(self.doc.reconstruct(),fixture())
    def test_large_fields_and_region_dependencies(self):
        data=fixture()
        nodes=data["geometry"]["structured_topology"]["nodes"]
        data["geometry"]["structured_topology"]["nodes"]=[]
        data["geometry"]["structured_topology"]["legacy_to_node"]={}
        data["geometry"]["structured_topology"]["edge_to_faces"]={}
        data["geometry"]["faces"]=[];data["geometry"]["edges"]=[]
        for i in range(80):
            names={n["id"]:f"{n['id']}-{i}" for n in nodes}
            for n in nodes:
                row=json.loads(json.dumps(n));row["id"]=names[n["id"]]
                row["children"]=[{"id":names[c["id"]]} for c in row["children"]]
                if n["type"]=="face":row["properties"]["exact_parameters"]=[i/7+j/13 for j in range(120)]
                data["geometry"]["structured_topology"]["nodes"].append(row)
            data["geometry"]["structured_topology"]["edge_to_faces"][f"N3-{i}"]=[f"N1-{i}"]
            data["geometry"]["structured_topology"]["legacy_to_node"][f"F{i}"]=f"N1-{i}"
            data["geometry"]["faces"].append({"face_id":f"F{i}","surface_type":"plane",
                "center_of_mass":[i,0,0],"solid_ids":["S0001"],"edge_ids":[f"E{i}"]})
        data["geometry"]["face_count"]=80
        data["extra_future_fields"]={"unicode":"精确字段"+chr(92)+"a"*30000,"empty":[],"bool":True}
        doc=CADDocument(data,{**CFG,"context_window_tokens":32768,"max_output_tokens":4096})
        self.assertGreater(len(doc.units),1)
        self.assertEqual(doc.reconstruct(),data)
        covered=set()
        for u in doc.units:
            self.assertLessEqual(size(u)+size(doc.frame_for(u)),doc.bounds)
            covered.update(u["face_ids"])
            if u["kind"]=="region":
                have={r["value"]["id"] for r in u["owned"] if isinstance(r.get("value"),dict) and "id" in r["value"]}
                have.update(n["id"] for n in u["support"])
                self.assertTrue(all(doc.descendants(f)<=have for f in u["face_ids"]))
        self.assertEqual(covered,{f"N1-{i}" for i in range(80)})
    def test_capacity_is_not_hidden_5000_limit(self):
        self.assertEqual(capacity(CFG)[0],1048576)
        self.assertEqual(output_capacity(CFG),65536)
        self.assertEqual(output_capacity(dict(CFG,max_output_tokens=131072)),131072)
    def test_exact_cache_and_new_goal_isolation(self):
        w=self.new()
        first,hit=w.query("measurement",{"a":1},lambda:{"value":123.456})
        self.assertFalse(hit)
        row={"title":"Fixture","condition":"Known condition","basis":"user_requirement",
             "status":"contradicted","location":"fixture","reasoning":"controlled",
             "consequence":"controlled","recommendation":"controlled",
             "evidence_ids":[first["id"]],"id":"F-test"}
        self.assertTrue(w.register(row)["changed"])
        self.assertFalse(w.register(row)["changed"])
        w.finish("paused","controlled interruption")
        resumed=self.new()
        self.assertTrue(resumed.resumed)
        self.assertEqual(resumed.findings,w.findings)
        other=self.new(goal="other goal")
        self.assertFalse(other.findings)
        second,hit=other.query("measurement",{"a":1},lambda:self.fail("must reuse exact observation"))
        self.assertTrue(hit);self.assertEqual(first,second)
        self.source.write_bytes(b"changed source")
        changed=self.new()
        self.assertNotEqual(changed.geometry_key,w.geometry_key)
        self.assertFalse(changed.findings)
    def test_completed_job_remains_immutable_next_job_can_resume(self):
        w=self.new();w.finish("completed",final_text="old")
        second=self.new();self.assertNotEqual(w.identity,second.identity)
        second.finish("paused","new interruption")
        third=self.new();self.assertEqual(third.identity,second.identity)
    def test_record_evidence_provenance_and_revision(self):
        w=self.new()
        row={"title":"Fixture","condition":"condition","basis":"function_hypothesis",
             "status":"contradicted","location":"fixture","reasoning":"controlled",
             "consequence":"controlled","recommendation":"controlled","evidence_ids":["E-fake"],"id":"F1"}
        with self.assertRaises(ValueError):w.register(row)
        eid=w.input_record(w.document.units[0])["id"];row["evidence_ids"]=[eid]
        w.register(row)
        with self.assertRaises(ValueError):w.register({**row,"status":"supported"})
        w.register({**row,"status":"supported","correction_reason":"controlled revision"})
        self.assertEqual(w.findings["F1"]["status"],"supported")
    def test_exact_pagination_does_not_disguise_preview(self):
        obj={"long":[i/7 for i in range(3000)],"short":42}
        got=page(obj,0,10,1000)
        self.assertTrue(got["items"][0]["unexpanded"])
        self.assertEqual(got["items"][1]["value"],42)
        p=page(obj["long"],0,20,1000)
        self.assertEqual([r["value"] for r in p["items"]],obj["long"][:20])
    def test_body_timeout_is_terminal_unknown_cost(self):
        w=self.new();meter=Meter(CFG,w);meter.start_phase("FULL")
        class Timeout(httpx.AsyncByteStream):
            async def __aiter__(self):
                raise httpx.ReadTimeout("controlled body failure")
                yield b""
        with self.assertRaises(httpx.ReadTimeout):
            self.post(w,meter,lambda r:httpx.Response(200,stream=Timeout()))
        u=meter.finish("failed","controlled")
        self.assertEqual(u["calls"],1);self.assertEqual(u["failed_requests"],1)
        self.assertEqual(u["unknown_cost_requests"],1);self.assertEqual(u["pending_or_interrupted"],0)
        self.assertEqual(sum(e["event"]=="api_request_failed" for e in self.events()),1)
    def test_text_cutoff_is_visible_and_not_connection_error(self):
        w=self.new();meter=Meter(CFG,w);meter.start_phase("FULL")
        r=self.post(w,meter,lambda req:response("actual partial fixture",finish="length",output=65536))
        self.assertEqual(r.status_code,200);self.assertTrue(meter.cutoff)
        self.assertEqual(meter.successes,1);self.assertEqual(meter.failures,0)
        self.assertIn("actual partial fixture",w.stage_markdown())
        self.assertEqual(w.snapshot()["output_count"],1)
    def test_truncated_tool_arguments_not_executed(self):
        w=self.new();meter=Meter(CFG,w);meter.start_phase("FULL")
        tools=[{"id":"call_x","type":"function","function":{"name":"load_skill","arguments":"{\"name\":"}}]
        with self.assertRaises(HarnessStop):
            self.post(w,meter,lambda req:response("actual partial fixture",finish="length",tools=tools))
        self.assertEqual(meter.successes,1)
        self.assertIn("残缺工具参数",meter.local_stop)
        self.assertFalse(w.skills)
    def test_duplicate_request_prevented(self):
        w=self.new();meter=Meter(CFG,w);meter.start_phase("FULL")
        self.post(w,meter,lambda req:response())
        with self.assertRaises(HarnessStop):self.post(w,meter,lambda req:self.fail("duplicate sent"))
        self.assertEqual(meter.calls,1);self.assertEqual(meter.blocked,1)
    def test_alternating_no_progress_calls_stopped(self):
        w=self.new();meter=Meter(CFG,w);meter.start_phase("FULL")
        for i in range(5):
            calls=[{"id":f"call_{i}","type":"function","function":{
                "name":"load_skill" if i%2 else "read_geometry",
                "arguments":"{}"}}]
            self.post(w,meter,lambda req:response(None,"tool_calls",calls),
                      {"messages":[{"role":"user","content":str(i)}],"max_tokens":1000})
        self.assertEqual(meter.repeats,3)
        with self.assertRaises(HarnessStop):
            self.post(w,meter,lambda r:self.fail("repeated tool loop sent"),
                      {"messages":[{"role":"user","content":"next"}],"max_tokens":1000})
    def test_explicit_budget_and_stop(self):
        w=self.new();meter=Meter(dict(CFG,limits_enabled=True,max_requests=1,max_turn_est_tokens=100000),w)
        meter.start_phase("FULL");self.post(w,meter,lambda r:response())
        with self.assertRaises(HarnessStop):
            self.post(w,meter,lambda r:self.fail("budget exceeded"),{"messages":[{"role":"user","content":"another"}],"max_tokens":1000})
        self.assertTrue(live_progress.request_stop(w.run_id))
        self.assertTrue(live_progress.stop_requested(w.run_id))
        async def go():
            with self.assertRaises(HarnessStop):
                await cancellable(asyncio.sleep(10),w.run_id)
        asyncio.run(go())
    def test_actual_full_window_output_no_second_synthesis(self):
        w=self.new();meter=Meter(CFG,w);box=ToolBox(w,meter)
        async def go():
            async with httpx.AsyncClient(transport=httpx.MockTransport(lambda r:response("fixture final text")),
                event_hooks={"request":[meter.on_request],"response":[meter.on_response]}) as client:
                async def invoke(prompt,turns):
                    r=await client.post(CFG["base_url"]+"/chat/completions",
                        json={"messages":[{"role":"user","content":prompt}],"max_tokens":65536})
                    return r.json()["choices"][0]["message"]["content"]
                return await investigate(w,meter,box,invoke,lambda x:x)
        text,complete=asyncio.run(go())
        self.assertTrue(complete);self.assertEqual(text,"fixture final text")
        self.assertEqual(meter.calls,1);self.assertEqual(w.coverage()["read"],1)
        self.assertIn("fixture final text",(w.stage_dir/(w.run_id+".md")).read_text("utf-8"))

class GeometryKernelTests(unittest.TestCase):
    def test_real_occt_cylinder_occupancy(self):
        from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
        from cad.spatial_evidence import classify_point,box_occupancy
        shape=BRepPrimAPI_MakeBox(10.,10.,10.).Shape()
        r=cylinder_occupancy(shape,[5,5,0],[0,0,1],2,10)
        self.assertAlmostEqual(r["occupied_volume_mm3"],math.pi*40,places=5)
        r=cylinder_occupancy(shape,[15,15,0],[0,0,1],2,10)
        self.assertAlmostEqual(r["occupied_volume_mm3"],0,places=7)
        self.assertEqual(classify_point(shape,[5,5,5])["classification"],"inside")
        self.assertAlmostEqual(box_occupancy(shape,[0,0,0],[5,5,5])["occupied_volume_mm3"],125.,places=6)
    def test_actual_step_extraction(self):
        from cad.brep_analyzer import analyze_step_brep
        path=Path(__file__).resolve().parents[1]/"examples"/"through_hole.step"
        r=analyze_step_brep(str(path))
        self.assertEqual(r["status"],"ok",r)
        self.assertGreater(r["face_count"],0)
        self.assertGreater(len(r["structured_topology"]["nodes"]),0)
        self.assertIn("extraction",r)
        self.assertEqual(r["solid_count"],1)

if __name__=="__main__":unittest.main()
