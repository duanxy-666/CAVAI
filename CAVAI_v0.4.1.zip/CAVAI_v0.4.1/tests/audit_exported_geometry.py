"""Exercise the new application engine against an exported CAD JSON.

Uses the actual geometry and actual HTTPX hooks, with controlled HTTP
response text. No fake SDK modules, no live API, no engineering-quality
claims. The genuine SDK contract is covered separately by test_real_sdk.
"""
import argparse
import asyncio
import json
import tempfile
import uuid
from pathlib import Path
from unittest.mock import patch
import httpx
from cad.review_document import CADDocument,restore
from cad.geometry_transport import size,payload_estimate
from agent.work import ReviewWork,Store
from agent.provider import Meter
from agent.tools import ToolBox
from agent.engine import investigate
from agent import live_progress,usage_ledger
from tests.test_harness import CFG,response,SKILL

def audit(path):
    data=json.loads(Path(path).read_text("utf-8"))
    doc=CADDocument(data,CFG)
    assert doc.reconstruct()==data
    for u in doc.units:
        if u["kind"]=="region":
            present={r["value"]["id"] for r in u["owned"] if isinstance(r.get("value"),dict) and "id" in r["value"]}
            present.update(n["id"] for n in u["support"])
            assert all(doc.descendants(f)<=present for f in u["face_ids"])
    print("SOURCE_JSON_BYTES",size(data))
    print("WINDOWS",len(doc.units))
    print("COMPLETE_SOURCE_EQUALITY",True)
    print("NORMAL_REGIONAL_DEPENDENCY_CLOSURE",True)
    captured=[]
    with tempfile.TemporaryDirectory() as td:
        temp=Path(td);store=Store(temp/"memory.sqlite3")
        cad=temp/"identity.CATPart";cad.write_bytes(b"identity fixture only; no invented CAD")
        upload={"path":str(cad),"filename":"exported fixture","file_id":"actual-export-test"}
        def new():
            rid=uuid.uuid4().hex;live_progress.begin(rid,"offline audit")
            return ReviewWork(store,doc,upload,CFG,"Review supplied geometry","fixture workspace",rid,
                              stage_dir=temp/"stages")
        async def execute(w,fail_unit=None):
            meter=Meter(CFG,w);box=ToolBox(w,meter)
            # Direct calls exercise the actual tool bodies. They are
            # not a substitute for the real SDK's tool invocation test.
            tools={fn.__name__:fn for fn in box.build(lambda f:f)}
            def provider(req):
                body=json.loads(req.content)
                prompt=body["messages"][0]["content"]
                packet=json.loads(prompt.split("\n",1)[1])
                captured.append(packet)
                assert payload_estimate(body,CFG)+body["max_tokens"]<=1048576
                uid=packet["window_id"]
                if uid==fail_unit:raise httpx.ReadTimeout("controlled interruption")
                return response("CONTROLLED_VISIBLE_"+uid)
            async with httpx.AsyncClient(transport=httpx.MockTransport(provider),
                event_hooks={"request":[meter.on_request],"response":[meter.on_response]}) as client:
                async def invoke(prompt,turns):
                    r=await client.post(CFG["base_url"]+"/chat/completions",
                        json={"messages":[{"role":"user","content":prompt}],"max_tokens":65536})
                    packet=json.loads(prompt.split("\n",1)[1]);uid=packet["window_id"]
                    if uid==doc.units[0]["id"]:
                        assert "faces" in packet["global_geometry"] or doc.units[0]["kind"]=="full"
                        assert json.loads(tools["load_skill"](SKILL))["name"]==SKILL
                        registered=json.loads(tools["record_finding"](
                            "Controlled fixture observation","Test record transfer","function_hypothesis",
                            "insufficient","test only","fixture, not engineering judgment",
                            "fixture outcome","fixture recommendation",[packet["input_evidence_id"]],
                            "F-AUDIT"))
                        assert registered["saved"],registered
                        q=json.loads(tools["read_geometry"]("/geometry/face_count"))
                        assert q["data"]["value"]==data["geometry"]["face_count"]
                    elif uid!="SYNTHESIS":
                        assert any(f["id"]=="F-AUDIT" for f in packet["work_memory"]["findings"])
                        assert any(s["name"]==SKILL for s in packet["work_memory"]["skills"])
                    return r.json()["choices"][0]["message"]["content"]
                try:
                    text,complete=await investigate(w,meter,box,invoke,lambda x:x)
                    w.finish("completed" if complete else "paused",final_text=text)
                    return meter.finish("completed" if complete else "partial"),text
                except Exception as exc:
                    reason=meter.reason(exc);w.finish("paused",reason)
                    return meter.finish("incomplete",reason),""
        with patch.object(usage_ledger,"LEDGER_PATH",temp/"events.jsonl"):
            first=new()
            assert len(doc.units)>2,"audit requires oversized model"
            usage,_=asyncio.run(execute(first,doc.units[2]["id"]))
            assert usage["calls"]==3 and usage["failed_requests"]==1
            assert first.coverage()["read"]==2
            assert "CONTROLLED_VISIBLE_"+doc.units[0]["id"] in first.stage_markdown()
            assert first.findings["F-AUDIT"]["status"]=="insufficient"
            assert first.snapshot()["stage_download_url"]
            print("FIRST_WINDOW_IMMEDIATE_FINDINGS_AND_VISIBLE_OUTPUT",True)
            print("INTERRUPTION_RETURNS_STAGE_RESULTS",True)
            print("INTERRUPTED_REQUEST_TERMINAL_ACCOUNTING",True)
            first_capture=list(captured);captured.clear()
            resumed=new();assert resumed.identity==first.identity and resumed.resumed
            usage,text=asyncio.run(execute(resumed))
            assert usage["status"]=="completed" and text=="CONTROLLED_VISIBLE_SYNTHESIS"
            assert usage["calls"]==len(doc.units)-2+1
            assert not any(p["window_id"] in {doc.units[0]["id"],doc.units[1]["id"]} for p in captured)
            unique={p["window_id"]:p["current_exact_geometry"] for p in first_capture[:2]+captured
                    if p["window_id"]!="SYNTHESIS"}
            actual=restore(r for u in doc.units for r in unique[u["id"]]["owned"])
            assert actual==data
            assert resumed.coverage()["read"]==len(doc.units)
            print("PREVIOUS_ENGINEERING_MEMORY_PRESENT_IN_LATER_WINDOWS",True)
            print("RESUME_SKIPS_FINISHED_WINDOWS",True)
            print("ACTUAL_OUTGOING_SOURCE_FIELDS_EQUAL_ORIGINAL",True)
            print("RESUME_REQUESTS_INCLUDING_SYNTHESIS",usage["calls"])
            print("ALL_SOURCE_WINDOWS_NATURALLY_FINISHED_IN_CONTROLLED_TEST",True)
            print("MODEL_QUALITY_NOT_EVALUATED",True)
if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("json")
    audit(parser.parse_args().json)
