import math
import tempfile
import unittest
from pathlib import Path

try:
    import OCP
except ImportError:
    OCP = None

if OCP is not None:
    from OCP.BRep import BRep_Builder
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
    from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeFace, BRepBuilderAPI_MakePolygon, BRepBuilderAPI_Transform
    from OCP.BRepPrimAPI import BRepPrimAPI_MakePrism
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeCylinder
    from OCP.STEPControl import STEPControl_AsIs, STEPControl_Writer
    from OCP.TopoDS import TopoDS_Compound
    from OCP.gp import gp_Pnt, gp_Trsf, gp_Vec

from cad.brep_analyzer import analyze_step_brep


def write_step(shape, path):
    writer = STEPControl_Writer()
    writer.Transfer(shape, STEPControl_AsIs)
    status = writer.Write(str(path))
    if "RetDone" not in str(status):
        raise RuntimeError("Could not write STEP test fixture: {}".format(status))
    return str(path)


def translated(shape, z):
    transform = gp_Trsf()
    transform.SetTranslation(gp_Vec(0, 0, z))
    return BRepBuilderAPI_Transform(shape, transform, True).Shape()


def make_hex_prism(radius=8.0, height=5.0):
    polygon = BRepBuilderAPI_MakePolygon()
    for i in range(6):
        angle = math.radians(60 * i)
        polygon.Add(gp_Pnt(radius * math.cos(angle), radius * math.sin(angle), 0))
    polygon.Close()
    face = BRepBuilderAPI_MakeFace(polygon.Wire()).Face()
    return BRepPrimAPI_MakePrism(face, gp_Vec(0, 0, height)).Shape()


def make_fake_three_bosses():
    # Solid hexagonal boss + two solid cylindrical bosses; no bore or inner cylinder.
    hex_boss = make_hex_prism()
    cylinder_a = translated(__import__("OCP.BRepPrimAPI", fromlist=["BRepPrimAPI_MakeCylinder"]).BRepPrimAPI_MakeCylinder(3.0, 10.0).Shape(), 5.0)
    cylinder_b = translated(__import__("OCP.BRepPrimAPI", fromlist=["BRepPrimAPI_MakeCylinder"]).BRepPrimAPI_MakeCylinder(4.0, 3.0).Shape(), 15.0)
    builder = BRep_Builder()
    compound = TopoDS_Compound()
    builder.MakeCompound(compound)
    builder.Add(compound, hex_boss)
    builder.Add(compound, cylinder_a)
    builder.Add(compound, cylinder_b)
    return compound


def make_through_hole():
    outer = BRepPrimAPI_MakeCylinder(10.0, 20.0).Shape()
    cutter = translated(BRepPrimAPI_MakeCylinder(2.0, 22.0).Shape(), -1.0)
    return BRepAlgoAPI_Cut(outer, cutter).Shape()


def make_blind_hole():
    outer = BRepPrimAPI_MakeCylinder(10.0, 20.0).Shape()
    cutter = translated(BRepPrimAPI_MakeCylinder(2.0, 12.0).Shape(), 8.0)
    return BRepAlgoAPI_Cut(outer, cutter).Shape()


@unittest.skipIf(OCP is None, "未安装cadquery-ocp，跳过本地OCP回归测试")
class TestBRepAnalyzer(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory(prefix="cavai_brep_tests_")
        self.base = Path(self.temp_dir.name)

    def tearDown(self):
        self.temp_dir.cleanup()

    def parse_shape(self, shape, filename):
        path = self.base / filename
        write_step(shape, path)
        result = analyze_step_brep(str(path))
        self.assertEqual(result.get("status"), "ok", result)
        return result

    def test_solid_hex_and_two_solid_cylinders_have_no_hole(self):
        result = self.parse_shape(make_fake_three_bosses(), "fake_three_bosses.stp")
        self.assertEqual(result["solid_count"], 3)
        self.assertEqual(result["cylindrical_face_counts"]["inner"], 0)
        self.assertEqual(result["hole_candidate_count"], 0)

    def test_through_hole_candidate(self):
        result = self.parse_shape(make_through_hole(), "through_hole.stp")
        self.assertEqual(result["solid_count"], 1)
        self.assertEqual(result["cylindrical_face_counts"]["inner"], 1)
        self.assertEqual(result["hole_candidates"][0]["topology_class"], "through_hole_candidate")

    def test_blind_hole_candidate(self):
        result = self.parse_shape(make_blind_hole(), "blind_hole.stp")
        self.assertEqual(result["solid_count"], 1)
        self.assertEqual(result["cylindrical_face_counts"]["inner"], 1)
        self.assertEqual(result["hole_candidates"][0]["topology_class"], "blind_hole_candidate")


if __name__ == "__main__":
    unittest.main(verbosity=2)
