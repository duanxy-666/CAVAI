"""Controlled replay on a real CAD JSON, with actual local read tools.

Uses SDK input item dictionaries and the production filter. Not a live
provider, official SDK execution or engineering-quality benchmark.
"""
import argparse
import json
import tempfile
import uuid
from pathlib import Path
from types import SimpleNamespace
from dataclasses import dataclass
from unittest.mock import patch
from cad.review_document import CADDocument,restore
from cad.geometry_transport import size,encode,payload_estimate
from agent.work import Store,ReviewWork
from agent.engine import make_prompt
from agent.working_context import WorkingContext
from agent.provider import Meter
from agent.tools import ToolBox
from agent import live_progress,usage_ledger
from tests.test_harness import CFG,SKILL
from tests.test_working_context import InputData,call,result

def audit(path):
    data=json.loads(Path(path).read_text("utf-8"))
    doc=CADDocument(data,CFG)
    assert doc.reconstruct()==data
    print("EXACT_SOURCE_BYTES",size(data))
    print("SOURCE_WINDOWS",len(doc.units))
    with tempfile.TemporaryDirectory() as td,patch.object(usage_ledger,"LEDGER_PATH",Path(td)/"events.jsonl"):
        p=Path(td);cad=p/"fixture.step";cad.write_bytes(b"identity fixture only")
        rid=uuid.uuid4().hex;live_progress.begin(rid,"context replay")
        work=ReviewWork(Store(p/"memory.sqlite3"),doc,
            {"path":str(cad),"filename":"real export fixture","file_id":"fixture"},
            CFG,"Controlled context replay","test",rid,stage_dir=p/"stages")
        meter=Meter(CFG,work);box=ToolBox(work,meter)
        tools={f.__name__:f for f in box.build(lambda f:f)}
        old_total=new_total=0;requests=compacted=0
        new_owned=[]
        for unit in doc.units:
            work.start_unit(unit["id"]);meter.start_phase(unit["id"]);box.new_window()
            prompt=make_prompt(work,unit)
            history=[{"role":"user","content":prompt}]
            filt=WorkingContext(work,meter,InputData)
            def compare():
                nonlocal old_total,new_total,requests,compacted
                old=size(history)
                filtered=filt(SimpleNamespace(model_data=InputData(history,"test instructions"))).input
                new=size(filtered)
                assert new<=old
                assert payload_estimate({"messages":filtered,"max_tokens":65536},CFG)+65536<=1048576
                old_total+=old;new_total+=new;requests+=1
                compacted+=int(meter.context_metrics.get("mode")=="active_working_set")
                return filtered
            first=compare()
            obj=json.loads(first[0]["content"].split("\n",1)[1])
            assert obj["current_exact_geometry"]==unit
            new_owned.extend(obj["current_exact_geometry"].get("owned",[]))
            # Actual local read results, not pretend engineering findings.
            queries=[("/geometry/solid_count",),
                     ("/geometry/face_count",),("/geometry/edge_count",),
                     ("/geometry/bounding_box_mm",),("/geometry/face_type_counts",),
                     ("/geometry/local_rules",)]
            if unit==doc.units[0]:
                value=tools["load_skill"](SKILL)
                history.extend([call("load_skill",{"name":SKILL},"s-"+unit["id"]),
                                result("s-"+unit["id"],value)])
                applied=compare()
                assert json.loads(applied[0]["content"].split("\n",1)[1])["current_exact_geometry"]==unit
            for index,(pointer,) in enumerate(queries):
                ident=unit["id"]+"-"+str(index)
                args={"pointer":pointer,"offset":0,"limit":20}
                value=tools["read_geometry"](**args)
                history.extend([call("read_geometry",args,ident),result(ident,value)])
                out=compare()
                assert out[-2:]==history[-2:]
            work.finish_unit(unit["id"],"Controlled replay only",True)
        if doc.units[0]["kind"]=="full":
            assert doc.units[0]["data"]==data
        else:
            assert restore(new_owned)==data
        print("OUTGOING_EXACT_SOURCE_EQUALITY",True)
        print("CONTROLLED_REQUESTS",requests)
        print("COMPACTED_REQUESTS",compacted)
        print("UNFILTERED_INPUT_ITEM_BYTES",old_total)
        print("FILTERED_INPUT_ITEM_BYTES",new_total)
        print("INPUT_ITEM_BYTE_REDUCTION_PERCENT",round(100*(1-new_total/old_total),2))
        print("EXACT_TOOL_PAIRS_ARCHIVED",len(work.interactions))
        print("LOCAL_EXACT_REUSE_COUNT",work.cache_hits)
        print("LIVE_MODEL_QUALITY_AND_COST_NOT_EVALUATED",True)
if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("json")
    audit(parser.parse_args().json)
