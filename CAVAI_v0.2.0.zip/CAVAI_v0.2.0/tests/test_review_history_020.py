"""Local, non-billable acceptance tests for CAVAI v0.2.0.

A fake Agent is used only for endpoint tests. The v0.1.13 geometry tests
and independent SDK tests remain separate; these tests DO NOT imply a live
DeepSeek run happened.
"""
from __future__ import annotations

import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from fastapi.testclient import TestClient

import main
import workspace_store as store
from cad import evidence_store
from reports import agent_report


class TestReviewHistory020(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='cavai-v020-')
        self.root = Path(self.temp.name)
        self.usr = self.root / 'uploads'
        self.usr.mkdir()
        self.patches = [
            patch.object(main, 'UPLOAD_DIR', self.usr),
            patch.object(store, 'UPLOAD_DIR', self.usr),
            patch.object(store, 'WORKSPACE_DIR', self.root / 'workspaces'),
            patch.object(store, 'REPORT_DIR', self.root / 'reports'),
            patch.object(store, 'EVIDENCE_DIR', self.root / 'evidence'),
            patch.object(evidence_store, 'EVIDENCE_DIR', self.root / 'evidence'),
            patch.object(main, 'REPORT_DIR', self.root / 'reports'),
            patch.object(agent_report, 'REPORT_DIR', self.root / 'reports'),
            patch.object(main, 'inspect_model', self.inspect_model),
        ]
        for change in self.patches:
            change.start()
        self.old_uploads = dict(main.UPLOADS)
        main.UPLOADS.clear()
        self.client = TestClient(main.app)
        self.inspect_count = 0
        self.calls = []

    def tearDown(self):
        self.client.close()
        main.UPLOADS.clear()
        main.UPLOADS.update(self.old_uploads)
        for change in reversed(self.patches):
            change.stop()
        self.temp.cleanup()

    def inspect_model(self, name):
        self.inspect_count += 1
        return {
            'status': 'ok', 'document_type': 'STEP',
            'geometry': {'status': 'ok', 'solid_count': 1, 'face_count': 8,
                         'edge_count': 14, 'hole_candidate_count': 0,
                         'faces': [], 'edges': [], 'solids': [],
                         'feature_graph': {'status': 'ok', 'feature_count': 1,
                                           'relation_count': 0},
                         'preview': {'status': 'unavailable'}},
        }

    def upload(self, name='fixture.STEP'):
        resp = self.client.post('/api/upload', files={'file':
            (name, b'fake local CAD bytes for mocked inspection', 'application/octet-stream')})
        self.assertEqual(resp.status_code, 200, resp.text)
        return resp.json()['file_id']

    def fake_agent(self, **kwargs):
        self.calls.append(kwargs)
        version = len(self.calls)
        if version == 2:
            assert kwargs.get('report_context'), 'second run must receive prior engineering state'
        else:
            assert not kwargs.get('report_context')
        message = 'Agent模型输出V{}：{}'.format(version, kwargs['message'])
        report = agent_report.save_agent_markdown(
            markdown='# CAVAI Agent 报告 V{}\n\n{}'.format(version, message),
            filename=kwargs['upload']['filename'],
            file_id=kwargs['upload']['file_id'], model_id='test-mock-model',
            loaded_skills=['fixture-review'], tool_trace=[{'tool':'load_skill', 'ok':True}],
            geometry_fact_ids=['BREP-SUMMARY'], usage={'calls': 1, 'prompt_tokens': 20,
                                                       'completion_tokens': 10, 'status':'completed'},
        )
        return {
            'reply': report['report']['markdown_report'], 'provider': 'mocked_agent',
            'tool_trace': [{'tool': 'load_skill', 'ok': True}],
            'loaded_skills': ['fixture-review'], 'report': report['report'],
            'report_id': report['report_id'], 'report_download_url': report['download_url'],
            'turn_id': 'offline-no-api', 'usage': {'status':'completed', 'calls':1,
                                                  'prompt_tokens':20, 'completion_tokens':10},
        }

    def test_initial_report_restart_restore_continue_two_versions_no_reparse(self):
        file_id = self.upload()
        with patch.object(main, 'run_review', side_effect=self.fake_agent):
            first = self.client.post('/api/chat', json={
                'file_id': file_id, 'mode': 'review', 'message': '首次检查夹具结构'})
            self.assertEqual(first.status_code, 200, first.text)
            first_json = first.json()
            self.assertEqual(first_json['report_version'], 1)
            self.assertEqual(self.inspect_count, 1)
            session_id = first_json['session_id']
            old_id = first_json['report_id']
            original_text = (self.root / 'reports' / (old_id + '.md')).read_text('utf-8')

            # Simulate full application process restart: in-memory model entries gone.
            main.UPLOADS.clear()
            restored = self.client.get('/api/history/{}'.format(session_id))
            self.assertEqual(restored.status_code, 200, restored.text)
            self.assertTrue(restored.json()['model_available'])
            self.assertEqual(len(restored.json()['reports']), 1)
            preview = self.client.get('/api/models/{}/summary'.format(file_id))
            self.assertEqual(preview.status_code, 200)
            self.assertEqual(self.inspect_count, 1, 'cached evidence must avoid CATIA/OCP reparse')

            second = self.client.post('/api/chat', json={
                'session_id': session_id, 'mode': 'continue',
                'message': '补充：其实要检查夹紧和定位功能，请修改评测结论'})
            self.assertEqual(second.status_code, 200, second.text)
            body = second.json()
            self.assertEqual(body['report_version'], 2)
            self.assertEqual(body['session_id'], session_id)
            self.assertNotEqual(body['report_id'], old_id)
            self.assertEqual(self.inspect_count, 1)
            self.assertIn('首次检查夹具结构', self.calls[1]['report_context']['prior_markdown_excerpt'])
            self.assertEqual(body['report']['based_on_report_id'], old_id)
            self.assertEqual(body['report']['report_version'], 2)
            self.assertEqual(body['report']['review_mode'], 'continue')

        listing = self.client.get('/api/history').json()['items']
        item = next(x for x in listing if x['session_id'] == session_id)
        self.assertEqual(item['report_count'], 2)
        self.assertTrue(item['model_available'])
        state = self.client.get('/api/history/{}'.format(session_id)).json()
        self.assertEqual(len(state['reports']), 2)
        self.assertEqual(state['reports'][0]['version'], 1)
        self.assertEqual(state['reports'][1]['version'], 2)
        self.assertEqual(len([x for x in state['messages'] if x['role'] == 'user']), 2)
        self.assertEqual((self.root / 'reports' / (old_id + '.md')).read_text('utf-8'), original_text)
        self.assertEqual(self.client.get('/api/reports/{}/download/markdown'.format(old_id)).status_code, 200)
        self.assertEqual(len(self.calls), 2)

    def test_continuation_without_prior_report_prevented_without_agent_call(self):
        file_id = self.upload()
        created = store.create_workspace(file_id, 'fixture.STEP')
        with patch.object(main, 'run_review', side_effect=RuntimeError('should not call')):
            result = self.client.post('/api/chat', json={
                'session_id': created['session_id'], 'mode':'continue', 'message':'继续分析'})
        self.assertEqual(result.status_code, 409)

    def test_cross_model_session_switch_blocked(self):
        file_id = self.upload()
        other_id = self.upload('other.STEP')
        session = store.create_workspace(file_id, 'fixture.STEP')
        with patch.object(main, 'run_review', side_effect=RuntimeError('should not call')):
            result = self.client.post('/api/chat', json={
                'session_id': session['session_id'], 'file_id': other_id,
                'mode': 'review', 'message':'错误混合两个模型'})
        self.assertEqual(result.status_code, 409)

    def test_concurrent_same_session_denied_without_model_call(self):
        file_id = self.upload()
        session = store.create_workspace(file_id, 'fixture.STEP')
        self.assertTrue(store.begin_session_run(session['session_id']))
        try:
            with patch.object(main, 'run_review', side_effect=RuntimeError('should not call')):
                result = self.client.post('/api/chat', json={
                    'session_id': session['session_id'], 'mode':'review', 'message':'重复请求'})
            self.assertEqual(result.status_code, 409)
        finally:
            store.end_session_run(session['session_id'])

    def test_history_open_is_purely_local(self):
        file_id = self.upload()
        store.create_workspace(file_id, 'fixture.STEP')
        with patch.object(main, 'run_review', side_effect=RuntimeError('would charge')):
            response = self.client.get('/api/history')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.inspect_count, 0)

    def test_legacy_013_report_imported_when_data_copied(self):
        file_id = self.upload()
        old_id = 'f' * 32
        report_dir = self.root / 'reports'
        report_dir.mkdir(exist_ok=True)
        payload = {
            'report_id': old_id, 'report_source':'agent_llm_output',
            'model_file_id':file_id, 'model_filename':'fixture.STEP',
            'markdown_report':'# 旧版 Agent 真正生成过的报告',
            'created_at':'2026-11-23T12:00:00+00:00'
        }
        (report_dir / (old_id + '.json')).write_text(json.dumps(payload, ensure_ascii=False), 'utf-8')
        (report_dir / (old_id + '.md')).write_text(payload['markdown_report'], 'utf-8')
        first = self.client.get('/api/history').json()['items']
        second = self.client.get('/api/history').json()['items']
        matches = [x for x in second if x['file_id'] == file_id]
        self.assertEqual(len(matches), 1)
        self.assertEqual(matches[0]['report_count'], 1)
        self.assertEqual(len(first), len(second))
        detail = self.client.get('/api/history/{}'.format(matches[0]['session_id'])).json()
        self.assertEqual(detail['reports'][0]['report_id'], old_id)
        self.assertTrue(detail['model_available'])

    def test_paid_agent_report_delivered_even_if_history_index_write_fails(self):
        file_id = self.upload()
        with patch.object(main, 'run_review', side_effect=self.fake_agent), \
             patch.object(store, 'save_turn', side_effect=OSError('disk full')):
            result = self.client.post('/api/chat', json={
                'file_id': file_id, 'mode':'review', 'message':'检查夹具'})
        self.assertEqual(result.status_code, 200, result.text)
        data = result.json()
        self.assertTrue(store.valid_id(data['report_id']))
        self.assertIn('历史保存失败', data['history_save_error'])
        self.assertTrue((self.root / 'reports' / (data['report_id'] + '.md')).exists())
        self.assertIn('Agent 报告', data['reply'])

    def test_continuation_prompt_contains_prior_report_and_current_changes(self):
        from agent.sdk_agent import _create_input
        context = {'report_id': 'a' * 32, 'report_version': 2,
                   'prior_markdown_excerpt': '# 上轮报告\n待确认工件夹紧力',
                   'confirmed_user_updates': ['这是夹具，不是装饰平台']}
        prompt = _create_input('新的补充：这是一个软质工件',
                               {'filename': 'fixture.step', 'solid_count': 1},
                               [], [{'name': 'fixture-review'}], report_context=context)
        self.assertIn('上轮报告', prompt)
        self.assertIn('软质工件', prompt)
        self.assertIn('这是夹具', prompt)
        self.assertIn('本轮续评', prompt)
        self.assertNotIn('\x00', prompt)

    def test_concise_context_never_sends_full_geometry_or_all_report_history(self):
        file_id = self.upload()
        session = store.create_workspace(file_id, 'fixture.STEP')
        fake_id = 'd' * 32
        self.root.joinpath('reports').mkdir(exist_ok=True)
        (self.root / 'reports' / (fake_id + '.json')).write_text(json.dumps({
            'markdown_report': '旧报告' * 5000}), encoding='utf-8')
        session['reports'] = [{'report_id':fake_id,'version':1}]
        session['current_report_id'] = fake_id
        store._atomic_json(store.WORKSPACE_DIR / (session['session_id'] + '.json'), session)
        context = store.concise_report_context(store.load_workspace(session['session_id']))
        self.assertLess(len(context['prior_markdown_excerpt']), 4300)
        self.assertTrue(context['prior_report_excerpt'] if 'prior_report_excerpt' in context else True)


if __name__ == '__main__':
    unittest.main()
