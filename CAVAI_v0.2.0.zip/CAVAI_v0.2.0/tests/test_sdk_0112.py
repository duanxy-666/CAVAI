"""CAVAI 0.1.12 offline contract tests, zero external API charges.

These exercise real OCP + FastAPI + local Skills + HTTPX ledger with a mocked SDK
Runner and mocked provider replies. They DO NOT claim to test real installed
openai-agents==0.8.4 or a live DeepSeek service.
"""
from __future__ import annotations
import asyncio
import ast
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

import httpx
from fastapi.testclient import TestClient

from agent import sdk_agent, usage_ledger
from reports import agent_report
from tests.test_brep_analyzer import OCP, write_step, make_through_hole
import main

ROOT = Path(__file__).resolve().parent.parent


class FakeAgent:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


class FakeModelSettings:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


class FakeRunConfig:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


class FakeSDKModel:
    def __init__(self, model, openai_client):
        self.model = model
        self.client = openai_client


class FakeClient:
    def __init__(self, api_key, base_url, http_client, **kwargs):
        self.base_url = base_url.rstrip('/')
        self.http = http_client
        self.api_key = api_key

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        return None

    async def call_once(self, content):
        response = await self.http.post(self.base_url + '/chat/completions',
                                        json={'model': 'offline-test', 'messages': [
                                            {'role': 'user', 'content': str(content)[:700]}], 'max_tokens': 450},
                                        headers={'Authorization': 'Bearer ' + self.api_key})
        response.raise_for_status()
        return response.json()


class FakeRunner:
    behavior = 'success'

    @classmethod
    async def run(cls, agent, input, max_turns, run_config):
        assert run_config.tracing_disabled, 'Remote trace must be disabled'
        assert 1 <= max_turns <= 12
        if cls.behavior == 'no_network':
            return types.SimpleNamespace(final_output='# fake report generated without API')
        result = await agent.model.client.call_once(input)
        if not agent.tools:
            return types.SimpleNamespace(final_output='疑似安装支架，用途尚需用户确认。')
        if cls.behavior != 'no_tools':
            tools = {x.__name__: x for x in agent.tools}
            skill = json.loads(tools['load_skill']('part-geometry-review'))
            assert skill['name'] == 'part-geometry-review'
            facts = json.loads(tools['get_current_model_facts']())
            graph = json.loads(tools['get_structure_overview']())
            assert graph['status'] == 'ok' and graph['feature_count'] > 0
            cyls = json.loads(tools['find_structure_features']('cylindrical_region', limit=2))
            assert cyls['total'] >= 1
            detail = json.loads(tools['get_structure_feature'](cyls['items'][0]['feature_id']))
            assert 'feature' in detail
            hits = json.loads(tools['search_model_geometry']('faces', surface_type='cylinder', limit=2))
            assert facts.get('solid_count') == 1 and 'error' not in hits
            output = ('# 模拟模型返回的工程评测报告\n\n'
                      '## 用途与设计意图\n可能用于安装固定，待确认。\n\n'
                      '## 结构证据\nSolid={}；Face={}。\n\n'
                      '## 问题与建议\n建议核对通孔尺寸与装配公差，缺材料信息无法进行强度计算。'
                     ).format(facts.get('solid_count'), facts.get('face_count'))
        else:
            output = '模型自动给出的初步意见；但此轮没有实际调用本地工具。'
        return types.SimpleNamespace(final_output=output)


def fake_sdk_modules():
    root = types.ModuleType('agents')
    root.__path__ = []
    root.Agent = FakeAgent
    root.Runner = FakeRunner
    root.RunConfig = FakeRunConfig
    root.ModelSettings = FakeModelSettings
    root.set_tracing_disabled = lambda value: None
    root.function_tool = lambda fn: fn
    models = types.ModuleType('agents.models')
    models.__path__ = []
    cm = types.ModuleType('agents.models.openai_chatcompletions')
    cm.OpenAIChatCompletionsModel = FakeSDKModel
    return {'agents': root, 'agents.models': models, 'agents.models.openai_chatcompletions': cm}


def api_response(prompt=100, output=50, http_status=200, finish='stop'):
    if http_status >= 400:
        return httpx.Response(http_status, json={'error': {'type': 'insufficient_quota', 'code': 'insufficient_quota', 'message': '账户余额不足'}})
    return httpx.Response(200, json={
        'id': 'mock-request-no-billing', 'choices': [{'finish_reason': finish, 'message': {'role': 'assistant', 'content': 'test'}}],
        'usage': {'prompt_tokens': prompt, 'completion_tokens': output, 'prompt_cache_hit_tokens': 20}
    })


class TestHttpMeter(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.ledger = Path(self.temp.name) / 'events.jsonl'
        self.patch_ledger = patch.object(usage_ledger, 'LEDGER_PATH', self.ledger)
        self.patch_ledger.start()
        self.config = {'api_key': 'sk-secret-super-long-key', 'base_url': 'https://api.deepseek.com',
                       'model': 'deepseek-flash', 'limits_enabled': False,
                       'max_requests': 8, 'max_turn_est_tokens': 30000}

    def tearDown(self):
        self.patch_ledger.stop()
        self.temp.cleanup()

    def lines(self):
        return [json.loads(x) for x in self.ledger.read_text('utf-8').splitlines()]

    def execute(self, responses, bodies=None, cfg=None):
        meter = sdk_agent.HttpUsageMeter(cfg or self.config, 'test-turn', 'agent_review')
        calls = []
        backend = iter(responses)

        def mock_transport(request):
            calls.append(request)
            return next(backend)

        async def go():
            async with httpx.AsyncClient(transport=httpx.MockTransport(mock_transport),
                                        event_hooks={'request': [meter.on_request],
                                                     'response': [meter.on_response]}) as client:
                for body in bodies or [{'model': 'deepseek-flash', 'messages':[{'role':'user','content':'A'}]}]:
                    try:
                        await client.post('https://api.deepseek.com/chat/completions', json=body,
                                          headers={'Authorization':'Bearer sk-secret-super-long-key'})
                    except (sdk_agent.RequestBudgetError, sdk_agent.RepeatedRequestError,
                            sdk_agent.OutputCutoffError):
                        break
            return meter.finish('completed')
        usage = asyncio.run(go())
        return usage, calls

    def test_provider_usage_and_cache_are_reported_without_key(self):
        usage, calls = self.execute([api_response(90, 30)])
        self.assertEqual(usage['calls'], 1)
        self.assertEqual(usage['prompt_tokens'], 90)
        self.assertEqual(usage['completion_tokens'], 30)
        self.assertEqual(usage['cached_input_tokens'], 20)
        self.assertEqual(len(calls), 1)
        self.assertNotIn('sk-secret-super-long-key', self.ledger.read_text('utf8'))
        self.assertEqual([x for x in self.lines() if x['event']=='api_request_completed'][0]['finish_reason'], 'stop')

    def test_402_is_logged_once_without_silent_retry(self):
        usage, calls = self.execute([api_response(http_status=402)])
        self.assertEqual(usage['calls'], 1)
        self.assertEqual(usage['unknown_cost_requests'], 1)
        self.assertEqual([x['http_status'] for x in self.lines() if x['event']=='api_request_failed'], [402])

    def test_same_payload_third_time_is_blocked_before_send(self):
        body = {'model':'deepseek-flash', 'messages':[{'role':'user','content':'same'}]}
        usage, calls = self.execute([api_response(), api_response()], bodies=[body,body,body])
        self.assertEqual(len(calls), 2)
        self.assertEqual(usage['calls'], 2)
        self.assertTrue(any(x['event']=='budget_blocked' for x in self.lines()))

    def test_budget_opt_in_blocks_before_any_request(self):
        cfg = dict(self.config, limits_enabled=True, max_turn_est_tokens=1000)
        large = {'model':'deepseek-flash', 'max_tokens':2700, 'messages':[{'role':'user','content':'A' * 1500}]}
        usage, calls = self.execute([], bodies=[large], cfg=cfg)
        self.assertEqual(len(calls), 0)
        self.assertEqual(usage['calls'], 0)

    def test_cutoff_stops_instead_of_reusing_incomplete_json(self):
        usage, calls = self.execute([api_response(finish='length')])
        self.assertEqual(len(calls), 1)
        self.assertEqual(usage['calls'], 1)

    def test_hard_safety_limit_without_custom_budget(self):
        meter = sdk_agent.HttpUsageMeter(self.config, 't', 'review')
        self.assertEqual(meter.hard_max, 12)


@unittest.skipIf(OCP is None, 'OCP not installed')
class TestApiWorkflow(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.home = Path(self.temp.name)
        self.cfg = {'base_url':'https://api.deepseek.com', 'api_key':'sk-offline-no-charge',
                    'model':'deepseek-flash', 'limits_enabled':False,
                    'max_requests':8, 'max_turn_est_tokens':30000}
        self.patches = [
            patch.object(main,'UPLOAD_DIR',self.home/'uploads'),
            patch.object(main,'REPORT_DIR',self.home/'reports'),
            patch.object(agent_report,'REPORT_DIR',self.home/'reports'),
            patch.object(usage_ledger,'LEDGER_PATH',self.home/'ledger.jsonl'),
            patch.object(main,'save_inspection_evidence',lambda *a,**k:self.home/'evidence.json'),
            patch.object(sdk_agent,'get_llm_settings',lambda: self.cfg),
        ]
        for p in self.patches: p.start()
        main.UPLOADS.clear(); main.SESSIONS.clear()
        self.client = TestClient(main.app)
        self.base_client = httpx.AsyncClient

    def tearDown(self):
        self.client.close()
        main.UPLOADS.clear(); main.SESSIONS.clear()
        for p in reversed(self.patches): p.stop()
        self.temp.cleanup()

    def upload_step(self):
        path = self.home/'through.step'
        write_step(make_through_hole(), path)
        result = self.client.post('/api/upload', files={'file':('through.step',path.read_bytes(),'application/octet-stream')})
        self.assertEqual(result.status_code, 200, result.text)
        return result.json()['file_id']

    def fake_run(self, file_id, status_code=200, behavior='success'):
        FakeRunner.behavior = behavior
        client_type = self.base_client
        responses = []
        def mock_handler(request):
            responses.append(request)
            return api_response(prompt=120, output=75, http_status=status_code)
        def client_factory(*args, **kwargs):
            kwargs['transport'] = httpx.MockTransport(mock_handler)
            return client_type(*args, **kwargs)
        fake_modules = fake_sdk_modules()
        openai_stub = types.ModuleType('openai')
        openai_stub.AsyncOpenAI = FakeClient
        fake_modules['openai'] = openai_stub
        with patch.dict(sys.modules, fake_modules), \
             patch.object(httpx, 'AsyncClient', side_effect=client_factory):
            result = self.client.post('/api/chat', json={
                'file_id': file_id, 'message': '检查这个零件的通孔是否能安装固定', 'mode':'review'})
        return result, responses

    def test_local_preview_has_no_paid_model_request(self):
        file_id = self.upload_step()
        r = self.client.get('/api/models/{}/summary'.format(file_id))
        self.assertEqual(r.status_code, 200, r.text)
        data = r.json()
        self.assertEqual(data['inspection']['geometry']['status'], 'ok')
        self.assertGreater(data['inspection']['geometry']['structure_feature_count'], 0)
        self.assertTrue(data['preview_url'])
        self.assertEqual(self.client.get(data['preview_url']).status_code, 200)
        self.assertFalse((self.home/'ledger.jsonl').exists(),
                         'Local preview must never invoke paid model API')

    def test_real_step_upload_sdk_tools_agent_report_download(self):
        file_id = self.upload_step()
        result, requests = self.fake_run(file_id)
        self.assertEqual(result.status_code, 200, result.text)
        data = result.json()
        self.assertEqual(data['inspection']['geometry']['solid_count'], 1)
        self.assertEqual(len(requests), 2)  # one visual observation + one Agent tool round
        self.assertEqual(data['usage']['calls'], 2)
        self.assertEqual(data['usage']['prompt_tokens'], 240)
        self.assertEqual(data['provider'], 'openai_agents_sdk')
        self.assertIsNotNone(data['report_id'], data['reply'])
        self.assertIn('Face=', data['reply'])
        tools = [x['tool'] for x in data['tool_trace']]
        self.assertIn('load_skill', tools)
        self.assertIn('search_model_geometry', tools)
        self.assertEqual(data['report']['report_source'], 'agent_llm_output')
        self.assertEqual(data['report']['report_status'], 'completed')
        self.assertEqual(self.client.get(data['report_download_url']).status_code, 200)
        self.assertEqual(self.client.get(f"/api/reports/{data['report_id']}").json()['report_id'], data['report_id'])
        four_views = self.client.get('/api/models/{}/preview'.format(file_id))
        self.assertEqual(four_views.status_code, 200)
        self.assertEqual(four_views.headers.get('content-type'), 'image/jpeg')
        self.assertGreater(len(four_views.content), 10000)
        self.assertGreater(data['inspection']['geometry']['structure_feature_count'], 0)

    def test_visual_observation_cached_for_same_file(self):
        file_id = self.upload_step()
        first, first_requests = self.fake_run(file_id)
        self.assertIsNotNone(first.json()['report_id'], first.json()['reply'])
        self.assertEqual(len(first_requests), 2)
        second, second_requests = self.fake_run(file_id)
        self.assertIsNotNone(second.json()['report_id'], second.json()['reply'])
        self.assertEqual(len(second_requests), 1, 'JPEG should not be resent on later reviews')
        self.assertEqual(second.json()['usage']['calls'], 1)

    def test_unknown_vision_provider_no_extra_request(self):
        file_id = self.upload_step()
        self.cfg['base_url'] = 'https://example.org/v1'
        self.cfg['model'] = 'a-text-only-model'
        result, requests = self.fake_run(file_id)
        self.assertIsNotNone(result.json()['report_id'], result.json()['reply'])
        self.assertEqual(len(requests), 1)

    def test_402_returns_error_and_preserves_ledger(self):
        file_id = self.upload_step()
        result, requests = self.fake_run(file_id, status_code=402)
        data = result.json()
        self.assertEqual(result.status_code, 200)
        self.assertEqual(len(requests), 1)
        self.assertIsNone(data['report_id'])
        self.assertEqual(data['usage']['calls'], 1)
        self.assertTrue(any(json.loads(line)['event']=='api_request_failed' for line in (self.home/'ledger.jsonl').read_text('utf8').splitlines()))

    def test_no_tools_yields_marked_partial_real_response(self):
        file_id = self.upload_step()
        result, requests = self.fake_run(file_id, behavior='no_tools')
        data = result.json()
        self.assertEqual(len(requests), 2)
        self.assertEqual(data['report']['report_status'], 'partial')
        self.assertEqual(data['loaded_skills'], [])
        self.assertIn('未完整完成', data['reply'])

    def test_no_real_http_request_never_creates_fake_report(self):
        file_id = self.upload_step()
        result, requests = self.fake_run(file_id, behavior='no_network')
        data = result.json()
        self.assertEqual(len(requests), 0)
        self.assertIsNone(data['report_id'])
        self.assertEqual(data['usage']['calls'], 0)

    def test_missing_geometry_never_charges(self):
        result = self.client.post('/api/chat', json={'message':'请评测模型', 'mode':'review'})
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.json()['usage']['calls'], 0)
        self.assertIsNone(result.json()['report_id'])


class TestPythonCompatibility(unittest.TestCase):
    def test_python_39_parse(self):
        # Syntax and grammar check; NOT equivalent to executing Python 3.9 interpreter.
        for p in ROOT.rglob('*.py'):
            if '__pycache__' not in p.parts:
                ast.parse(p.read_text('utf8'), filename=str(p), feature_version=(3, 9))

    def test_sdk_pinned(self):
        requirement = (ROOT/'requirements.txt').read_text('utf8')
        self.assertIn('openai-agents==0.8.4', requirement)
        self.assertNotIn('langchain>=', requirement)
        self.assertNotIn('langgraph>=', requirement)

    def test_no_report_save_function_tool(self):
        sdk_text = (ROOT/'agent/sdk_agent.py').read_text('utf8')
        self.assertNotIn('def save_review_report(', sdk_text)
        self.assertIn('Runner.run(agent', sdk_text)


if __name__ == '__main__': unittest.main()
