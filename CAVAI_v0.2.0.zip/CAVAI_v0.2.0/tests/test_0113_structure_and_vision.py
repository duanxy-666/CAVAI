"""CAVAI 0.1.13: real OCP geometry, conservative feature grouping and local views."""
from __future__ import annotations

import ast
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from cad.feature_graph import build_feature_graph, brief_feature_graph, query_feature_graph
from cad.format_router import inspect_model
from tests.test_brep_analyzer import (OCP, write_step, make_through_hole,
                                      make_blind_hole, make_fake_three_bosses)


@unittest.skipIf(OCP is None, 'CAD/OCP dependency not installed')
class TestStructureGraphAndViews(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='cavai013-')
        self.folder = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def step(self, shape, name):
        path = self.folder / name
        write_step(shape, path)
        result = inspect_model(str(path))
        self.assertEqual(result['status'], 'ok', result.get('error'))
        geo = result['geometry']
        self.assertEqual(geo['status'], 'ok', geo)
        return path, geo

    def test_through_hole_becomes_queryable_feature(self):
        _, geo = self.step(make_through_hole(), 'through_hole.step')
        graph = geo['feature_graph']
        self.assertEqual(graph['status'], 'ok')
        self.assertEqual(graph['feature_type_counts']['hole_topology_candidate'], 1)
        holes = query_feature_graph(geo, kind='hole_topology_candidate')['items']
        self.assertEqual(len(holes), 1)
        full = query_feature_graph(geo, feature_id=holes[0]['feature_id'])
        self.assertEqual(full['feature']['topology_class'], 'through_hole_candidate')
        self.assertTrue(full['feature']['evidence_face_ids'])
        self.assertTrue(any(r['relation'] == 'candidate_derived_from_surface'
                            for r in full['related']))
        self.assertEqual(geo['cylindrical_face_counts']['inner'], 1)

    def test_blind_hole_is_candidate_not_confirmed_fastener(self):
        _, geo = self.step(make_blind_hole(), 'blind_hole.step')
        h = query_feature_graph(geo, kind='hole_topology_candidate')['items'][0]
        self.assertEqual(h['topology_class'], 'blind_hole_candidate')
        self.assertIn('candidate', h['type'])
        self.assertNotIn('fastener', h['type'])

    def test_three_solid_bosses_not_labeled_as_nuts_or_holes(self):
        _, geo = self.step(make_fake_three_bosses(), 'three_bosses.step')
        self.assertEqual(geo['solid_count'], 3)
        graph = geo['feature_graph']
        self.assertEqual(graph['feature_type_counts'].get('hole_topology_candidate', 0), 0)
        self.assertGreaterEqual(graph['feature_type_counts'].get('cylindrical_region', 0), 1)
        self.assertNotIn('nut', ' '.join(r['type'] for r in graph['features']).lower())
        self.assertNotIn('screw', ' '.join(r['type'] for r in graph['features']).lower())

    def test_real_model_four_view_jpeg_exists_locally(self):
        path, geo = self.step(make_through_hole(), 'fourviews.step')
        preview = geo['preview']
        self.assertEqual(preview['status'], 'ok', preview)
        image_path = Path(preview['preview_path'])
        self.assertTrue(image_path.is_file())
        self.assertEqual(image_path.parent, path.parent)
        self.assertLess(image_path.stat().st_size, 350000)
        from PIL import Image
        with Image.open(image_path) as im:
            self.assertEqual(im.format, 'JPEG')
            self.assertEqual(im.size, (1040, 800))
            # A through hole must be visibly open in the top image tile.
            top_cx, top_cy = 260, 600
            center = im.getpixel((top_cx, top_cy))
            surrounding = im.getpixel((top_cx + 85, top_cy))
            self.assertGreater(sum(center), sum(surrounding) + 60)

    def test_preview_failure_does_not_invalidate_geometry(self):
        path = self.folder / 'failure.step'
        write_step(make_through_hole(), path)
        with patch('cad.model_views.render_four_views', side_effect=OSError('render test failed')):
            result = inspect_model(str(path))
        self.assertEqual(result['status'], 'ok')
        self.assertEqual(result['geometry']['preview']['status'], 'unavailable')
        self.assertEqual(result['geometry']['hole_candidate_count'], 1)

    def test_brief_graph_is_bounded_for_model_api(self):
        _, geo = self.step(make_through_hole(), 'brief.step')
        brief = brief_feature_graph(geo, max_features=2, max_relations=1)
        self.assertLessEqual(len(brief['features_preview']), 2)
        self.assertLessEqual(len(brief['relationships_preview']), 1)
        self.assertEqual(brief['status'], 'ok')
        self.assertNotIn('evidence_face_ids', brief['features_preview'][0])

    def test_preview_contains_only_software_rendered_cad_mesh(self):
        _, geo = self.step(make_through_hole(), 'no_cloud.step')
        preview = geo['preview']
        self.assertIn('B-Rep', preview['note'])
        self.assertNotIn('data:', str(preview))


class TestPatchGroupingInMemory(unittest.TestCase):
    @staticmethod
    def geometry(off_axis=False):
        faces = []
        for n in range(2):
            faces.append({'face_id': 'F{}'.format(n), 'surface_type': 'cylinder',
                          'radius': 3.0, 'diameter': 6.0, 'cylindrical_side': 'outer',
                          'axis_origin': [float(10 if off_axis and n else 0), 0.0, 0.0],
                          'axis_direction': [0.0, 0.0, 1.0],
                          'solid_ids': ['S0001'], 'area': 12, 'center_of_mass': [0, 0, 2],
                          'edge_ids': ['E_shared', 'E{}'.format(n)]})
        return {'status': 'ok', 'faces': faces, 'edges': [], 'hole_candidates': []}

    def test_adjacent_same_coaxial_faces_form_one_region(self):
        graph = build_feature_graph(self.geometry())
        self.assertEqual(graph['feature_type_counts']['cylindrical_region'], 1)
        self.assertEqual(graph['features'][0]['face_count'], 2)

    def test_parallel_but_offset_faces_do_not_merge(self):
        graph = build_feature_graph(self.geometry(off_axis=True))
        self.assertEqual(graph['feature_type_counts']['cylindrical_region'], 2)
        self.assertFalse(any(r['relation'] == 'coaxial_geometry_only' for r in graph['relationships']))

    def test_python39_syntax(self):
        from cad import feature_graph, model_views
        for path in (Path(feature_graph.__file__), Path(model_views.__file__)):
            ast.parse(path.read_text('utf-8'), feature_version=(3, 9))


if __name__ == '__main__':
    unittest.main()
