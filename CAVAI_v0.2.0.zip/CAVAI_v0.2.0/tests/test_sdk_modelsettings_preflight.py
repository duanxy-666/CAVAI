"""Offline regression: CAVAI detects malformed model settings before server start."""
import sys
import types
import unittest
from unittest.mock import patch

from agent import sdk_agent
from run import check_agents_model_settings_compatibility


class TestModelSettingsStartupGuard(unittest.TestCase):
    def test_accepts_single_native_extra_body(self):
        stub = types.ModuleType("agents")

        class CompatibleSettings:
            def __init__(self, **kwargs):
                self.extra_body = kwargs.get("extra_body")
                self.extra_args = kwargs.get("extra_args")

        stub.ModelSettings = CompatibleSettings
        with patch.dict(sys.modules, {"agents": stub}):
            check_agents_model_settings_compatibility()

    def test_rejects_old_duplicate_keyword_before_network(self):
        stub = types.ModuleType("agents")

        class CompatibleSettings:
            def __init__(self, **kwargs):
                self.extra_body = kwargs.get("extra_body")
                self.extra_args = kwargs.get("extra_args")

        stub.ModelSettings = CompatibleSettings
        broken = {
            "max_tokens": 2800,
            "extra_args": {"extra_body": {"thinking": {"type": "disabled"}}}
        }
        with patch.dict(sys.modules, {"agents": stub}), \
             patch.object(sdk_agent, "_sdk_model_options", return_value=broken):
            with self.assertRaises(SystemExit) as caught:
                check_agents_model_settings_compatibility()
        self.assertEqual(caught.exception.code, 1)


if __name__ == "__main__":
    unittest.main()
