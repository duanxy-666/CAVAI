"""Offline tests for the known cache_write_tokens / Usage() incompatibility."""
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from run import check_agents_usage_schema_compatibility


class TestDependencyGuard(unittest.TestCase):
    def test_requirements_pin_exact_known_compatible_openai(self):
        content = (Path(__file__).resolve().parents[1] / "requirements.txt").read_text(encoding="utf-8")
        self.assertIn("openai-agents==0.8.4", content)
        self.assertIn("openai==2.44.0", content)
        self.assertNotIn("openai>=1.70,<2.49", content)

    def test_reject_incompatible_sdk_schema_before_server_start(self):
        agents = types.ModuleType("agents")
        agents.__path__ = []
        usage = types.ModuleType("agents.usage")
        class BrokenUsage:
            def __init__(self):
                raise ValueError("InputTokensDetails cache_write_tokens Field required")
        usage.Usage = BrokenUsage
        with patch.dict(sys.modules, {"agents": agents, "agents.usage": usage}):
            with self.assertRaises(SystemExit) as caught:
                check_agents_usage_schema_compatibility()
            self.assertEqual(caught.exception.code, 1)

    def test_accept_compatible_sdk_schema_without_network(self):
        agents = types.ModuleType("agents")
        agents.__path__ = []
        usage = types.ModuleType("agents.usage")
        class WorkingUsage:
            def __init__(self):
                self.input_tokens = 0
        usage.Usage = WorkingUsage
        with patch.dict(sys.modules, {"agents": agents, "agents.usage": usage}):
            check_agents_usage_schema_compatibility()


if __name__ == "__main__":
    unittest.main()
