"""Zero-cost wire-contract test for OpenAI Agents SDK + local CAD tool.

When the real SDK is installed, HTTPX MockTransport intercepts ALL outgoing
requests and returns local fake Chat Completions responses. No API fees.
"""
import asyncio
import importlib.util
import json
import unittest

import httpx

from agent.sdk_agent import _sdk_model_options


class TestModelOptionsNoNetwork(unittest.TestCase):
    def test_deepseek_extra_body_single_channel(self):
        cfg = {"base_url": "https://api.deepseek.com", "model": "deepseek-flash"}
        options = _sdk_model_options(cfg, intent=False)
        self.assertEqual(options["extra_body"], {"thinking": {"type": "disabled"}})
        self.assertNotIn("extra_args", options)
        self.assertEqual(options["max_tokens"], 2800)

    def test_third_party_has_no_deepseek_parameter(self):
        options = _sdk_model_options(
            {"base_url": "https://example.org/v1", "model": "my-model"},
            intent=False
        )
        self.assertNotIn("extra_body", options)
        self.assertNotIn("extra_args", options)

    def test_deceptive_domain_is_not_official(self):
        options = _sdk_model_options(
            {"base_url": "https://api.deepseek.com.other.invalid/v1",
             "model": "deepseek-flash"},
            intent=True
        )
        self.assertEqual(options, {"max_tokens": 350})

    def test_previous_duplicate_argument_bug(self):
        def sdk_call(*, extra_body=None, **kwargs):
            return extra_body, kwargs
        with self.assertRaises(TypeError):
            sdk_call(extra_body=None, **{"extra_body": {"thinking": {"type": "disabled"}}})
        body, other = sdk_call(extra_body={"thinking": {"type": "disabled"}}, **{})
        self.assertEqual(body["thinking"]["type"], "disabled")
        self.assertFalse(other)


@unittest.skipUnless(importlib.util.find_spec("agents") is not None,
                     "real Agents SDK absent; only the offline model-option tests will run")
class TestRealSdkMockTransport(unittest.TestCase):
    def test_actual_runner_accepts_one_shot_image_without_network(self):
        """Run the user's Python 3.9-installed SDK through HTTPX local interception."""
        from agents import Agent, ModelSettings, Runner, RunConfig, set_tracing_disabled
        from agents.models.openai_chatcompletions import OpenAIChatCompletionsModel
        from openai import AsyncOpenAI
        import base64

        seen = []
        set_tracing_disabled(True)
        fake_jpeg = base64.b64encode(b'not-a-real-jpeg-image').decode('ascii')
        def local_response(request):
            body = json.loads(request.content.decode('utf8'))
            seen.append(body)
            messages = body.get('messages') or []
            user = next((m for m in reversed(messages) if m.get('role') == 'user'), {})
            content = user.get('content')
            self.assertIsInstance(content, list)
            self.assertTrue(any(item.get('type') == 'image_url' for item in content))
            return httpx.Response(200, json={
                'id': 'fake-vision', 'object': 'chat.completion', 'created': 1795000000,
                'model': 'deepseek-flash',
                'choices': [{'index': 0, 'message': {'role': 'assistant',
                             'content': '可见圆柱形结构，其用途待核实'},
                             'finish_reason': 'stop'}],
                'usage': {'prompt_tokens': 50, 'completion_tokens': 24,
                          'total_tokens': 74,
                          'prompt_tokens_details': {'cached_tokens': 0}}
            })

        async def execute():
            async with httpx.AsyncClient(transport=httpx.MockTransport(local_response)) as client_http:
                async with AsyncOpenAI(api_key='sk-never-used',
                                       base_url='https://api.deepseek.com',
                                       http_client=client_http, max_retries=0) as client:
                    model = OpenAIChatCompletionsModel(model='deepseek-flash', openai_client=client)
                    agent = Agent(name='Vision offline', model=model, tools=[],
                                  instructions='Describe observed geometry.',
                                  model_settings=ModelSettings(max_tokens=160))
                    return await Runner.run(agent, input=[{'role': 'user', 'content': [
                        {'type': 'input_text', 'text': 'Describe the CAD image.'},
                        {'type': 'input_image', 'image_url': 'data:image/jpeg;base64,' + fake_jpeg,
                         'detail': 'low'}]}], max_turns=1,
                         run_config=RunConfig(tracing_disabled=True))
        result = asyncio.run(execute())
        self.assertEqual(len(seen), 1)
        self.assertIn('圆柱', result.final_output)

    def test_actual_runner_tool_then_report_without_network(self):
        from agents import Agent, ModelSettings, Runner, RunConfig, function_tool, set_tracing_disabled
        from agents.models.openai_chatcompletions import OpenAIChatCompletionsModel
        from openai import AsyncOpenAI

        seen = []
        called_tools = []
        set_tracing_disabled(True)

        @function_tool
        def check_local_geometry(entity_id: str) -> str:
            """Read a CAD entity from local geometry evidence."""
            called_tools.append(entity_id)
            return "LOCAL CAD EVIDENCE: {} is a solid".format(entity_id)

        def fake_provider(request):
            self.assertEqual(request.url.path, "/chat/completions")
            body = json.loads(request.content.decode("utf-8"))
            seen.append(body)
            self.assertEqual(body["model"], "deepseek-flash")
            self.assertEqual(body["thinking"], {"type": "disabled"})
            index = len(seen)
            if index == 1:
                message = {
                    "role": "assistant", "content": None,
                    "tool_calls": [{
                        "id": "call_geometry_1", "type": "function",
                        "function": {
                            "name": "check_local_geometry",
                            "arguments": json.dumps({"entity_id": "SOLID-1"})
                        }
                    }]
                }
                finish_reason = "tool_calls"
            elif index == 2:
                message = {
                    "role": "assistant",
                    "content": "# Agent 工程评测报告\n\n"
                               "SOLID-1 为封闭实体，功能仍需用户确认。"
                }
                finish_reason = "stop"
            else:
                self.fail("Unexpected third API request during mock test")
            return httpx.Response(200, json={
                "id": "mock-no-billing-{}".format(index),
                "object": "chat.completion",
                "created": 1795000000,
                "model": "deepseek-flash",
                "choices": [{
                    "index": 0, "message": message,
                    "finish_reason": finish_reason, "logprobs": None
                }],
                "usage": {
                    "prompt_tokens": 80, "completion_tokens": 40,
                    "total_tokens": 120,
                    "prompt_tokens_details": {"cached_tokens": 0}
                }
            })

        async def run_local_mock():
            async with httpx.AsyncClient(transport=httpx.MockTransport(fake_provider)) as http:
                async with AsyncOpenAI(
                    api_key="sk-no-real-api-key",
                    base_url="https://api.deepseek.com",
                    http_client=http,
                    max_retries=0
                ) as client:
                    model = OpenAIChatCompletionsModel(
                        model="deepseek-flash", openai_client=client
                    )
                    settings = ModelSettings(**_sdk_model_options({
                        "base_url": "https://api.deepseek.com",
                        "model": "deepseek-flash"
                    }, intent=False))
                    agent = Agent(
                        name="CAVAI offline SDK integration",
                        model=model,
                        tools=[check_local_geometry],
                        model_settings=settings,
                        instructions="Call the CAD tool and output the final Markdown report."
                    )
                    return await Runner.run(
                        agent, input="检查 SOLID-1",
                        max_turns=3, run_config=RunConfig(tracing_disabled=True)
                    )

        final = asyncio.run(run_local_mock())
        self.assertEqual(len(seen), 2)
        self.assertEqual(called_tools, ["SOLID-1"])
        self.assertIn("Agent 工程评测报告", final.final_output)
        self.assertTrue(any(msg.get("role") == "tool" for msg in seen[1]["messages"]))


if __name__ == "__main__":
    unittest.main()
