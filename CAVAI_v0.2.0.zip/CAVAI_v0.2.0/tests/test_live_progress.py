"""Local execution progress contract: no paid API, no model private thoughts."""
import ast
import unittest
from pathlib import Path
from unittest.mock import patch

from fastapi.testclient import TestClient

import main
from agent import live_progress

ROOT = Path(__file__).resolve().parents[1]


class TestExecutionTrace(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(main.app)
        self.saved_uploads = main.UPLOADS.copy()
        main.UPLOADS.clear()
        self.saved_sessions = main.SESSIONS.copy()
        main.SESSIONS.clear()
        live_progress._RUNS.clear()

    def tearDown(self):
        self.client.close()
        main.UPLOADS.clear()
        main.UPLOADS.update(self.saved_uploads)
        main.SESSIONS.clear()
        main.SESSIONS.update(self.saved_sessions)
        live_progress._RUNS.clear()

    def test_local_progress_can_be_polled_without_api(self):
        run_id = 'a' * 32
        live_progress.begin(run_id, '本机解析')
        live_progress.event(run_id, 'tool', '完成 load_skill', '参数 fastener-review')
        r = self.client.get('/api/runs/{}/events'.format(run_id))
        self.assertEqual(r.status_code, 200)
        data = r.json()
        self.assertFalse(data['done'])
        self.assertEqual(len(data['events']), 2)
        self.assertIn('load_skill', data['events'][1]['label'])
        self.assertIn('内部思维', data['note'])
        live_progress.finish(run_id, 'completed', '报告已保存')
        self.assertEqual(self.client.get('/api/runs/{}/events'.format(run_id)).json()['status'], 'completed')
        self.assertEqual(self.client.get('/api/runs/../events').status_code, 404)

    def test_real_chat_route_hands_off_id_and_surfaces_tool(self):
        run_id, file_id = 'b' * 32, 'c' * 32
        main.UPLOADS[file_id] = {
            'file_id': file_id, 'filename': 'demo.STEP', 'path': 'not_visited.step',
            'inspection': {'status': 'ok', 'geometry': {
                'status': 'ok', 'solid_count': 1, 'face_count': 12,
                'edge_count': 24, 'hole_candidate_count': 0}}
        }

        def mock_review(**kwargs):
            self.assertEqual(kwargs['trace_id'], run_id)
            live_progress.event(run_id, 'tool', '完成 load_skill', '参数: fixture-review')
            live_progress.event(run_id, 'tool', '完成 search_model_geometry', '查询圆柱面')
            return {'reply': '# AI生成的示例报告', 'provider': 'mock',
                    'report_id': 'saved-id', 'report': None,
                    'tool_trace': [{'tool': 'load_skill', 'ok': True}],
                    'loaded_skills': ['fixture-review'],
                    'usage': {'status': 'completed', 'calls': 1, 'prompt_tokens': 100, 'completion_tokens': 50}}

        with patch.object(main, 'run_review', side_effect=mock_review):
            r = self.client.post('/api/chat', json={
                'message': '检查夹具', 'file_id': file_id, 'mode': 'review', 'trace_id': run_id})
        self.assertEqual(r.status_code, 200, r.text)
        self.assertEqual(r.json()['trace_id'], run_id)
        data = self.client.get('/api/runs/{}/events'.format(run_id)).json()
        self.assertEqual(data['status'], 'completed')
        labels = [ev['label'] for ev in data['events']]
        self.assertTrue(any('load_skill' in label for label in labels))
        self.assertTrue(any('search_model_geometry' in label for label in labels))
        self.assertTrue(any('几何解析完成' in label for label in labels))

    def test_invalid_trace_id_rejected(self):
        r = self.client.post('/api/chat', json={'message': '测试', 'trace_id': '../x'})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.client.get('/api/runs/not-a-valid-id/events').status_code, 404)

    def test_ui_titles_and_explanation(self):
        ui = (ROOT / 'frontend/index.html').read_text('utf-8')
        js = (ROOT / 'frontend/app.js').read_text('utf-8')
        self.assertIn('CAVAI^_^', ui)
        self.assertIn('CATIA 设计评测', ui)
        self.assertNotIn('CAVAI Assistant', ui)
        self.assertIn('createTracePanel(mode)', js)
        self.assertIn('trace_id: traceId', js)
        self.assertIn('模型未公开的内部思维不会伪造显示', js)

    def test_python39_syntax(self):
        for file in ('agent/live_progress.py', 'agent/sdk_agent.py', 'main.py'):
            ast.parse((ROOT / file).read_text('utf-8'), filename=file, feature_version=(3, 9))
