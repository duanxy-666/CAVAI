# CAVAI v0.2.0 技术路线与状态管理

1. FastAPI 上传 CAD，模型与预览保存在本机 `data/uploads/<file_id>`；`metadata.json` 持久化上传索引。
2. CATIA V5 + pycatia 和 Open CASCADE/OCP 提取几何与结构关系；完整 JSON 保存在 `data/evidence`，通过源文件 SHA256 验证缓存是否仍可用。
3. 用户配置的 OpenAI 兼容 API 接收有限长度的几何摘要、可选单次多视角图；Agents SDK 0.8.4 的 `Runner` 管理多轮工具调用，Skill 与 Python 工具留在本机。
4. 首次评测：Agent 生成 Markdown V1，本地保存 JSON 元数据与 Markdown；工作空间记录模型 ID、消息和报告 ID。
5. 用户续评：在同一 `session_id` 下，加载最近报告有界摘录及用户补充，沿用缓存几何，Agent 对新问题按需执行工具；默认不重新发送图片；返回 Markdown V2，新建文件、记录前一版 ID。
6. 历史：`GET /api/history` 本机列出会话；`GET /api/history/<id>` 恢复模型、消息及报告目录；报告切换 GET 本地 JSON/Markdown，不付费。
7. 节省 Token：几何只发送有界摘要和工具结果；续评报告摘录封顶，短历史封顶；同一会话并发请求被禁止；错误停止、不自动重试、不覆盖旧报告。账本逐笔记录 HTTPX 实际计费调用。
8. 历史数据从 0.1.13 `data/reports`、`data/uploads` 和 `data/evidence` 导入，恢复没有记录在磁盘上的旧聊天消息是不可能的。

技术边界：MCP 可选，不作为本版依赖；不新增 Benchmark；不开新 Skill；没有材料/载荷与接触条件时不提供虚构的强度结论。
