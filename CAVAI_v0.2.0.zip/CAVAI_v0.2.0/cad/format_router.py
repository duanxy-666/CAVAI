"""Local CAD format adapter: STEP is opened by OCP; CATIA V5 uses COM then OCP.

This module never sends CAD file bytes to an external API.
"""
from __future__ import annotations
from pathlib import Path
from typing import Dict, Any

from cad.brep_analyzer import analyze_step_brep
from cad.catia_reader import inspect_catia_document


def inspect_model(path: str) -> Dict[str, Any]:
    suffix = Path(path).suffix.lower()
    if suffix in ('.stp', '.step'):
        try:
            geometry = analyze_step_brep(str(path), view_output_path=str(Path(path).parent / (Path(path).stem + "_four_views.jpg")))
        except Exception as exc:
            return {'status': 'error', 'document_type': 'STEP',
                    'error': 'STEP/OCP解析失败：' + str(exc)[:220],
                    'geometry': {'status': 'error', 'error': str(exc)[:220]}}
        return {
            'status': 'ok' if geometry.get('status') == 'ok' else 'error',
            'document_type': 'STEP',
            'part': {'body_count': None, 'bodies': []},
            'geometry': geometry,
            'error': geometry.get('error') if geometry.get('status') != 'ok' else None,
            'limitations': ['STEP只包含导出后的几何，不提供可靠的CATIA原始建模历史。'],
        }
    if suffix in ('.catpart', '.catproduct'):
        return inspect_catia_document(str(path))
    return {'status': 'error', 'error': '不支持的模型格式：' + suffix}
