from __future__ import annotations

import json
import os
import re
import shutil
import uuid
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from agent.sdk_agent import run_review, run_intent
from agent import live_progress
from agent.model_capabilities import detect_model_capabilities
from cad.format_router import inspect_model
from cad.evidence_store import save_inspection_evidence
from skills.registry import list_skills
from settings_store import get_llm_settings, save_llm_settings, public_settings, validate_limits, normalize_base_url
from reports.store import read_review_report
from reports.agent_report import save_agent_markdown
from agent.usage_ledger import Tracker, get_ledger_summary, scrub
from agent import usage_ledger
import workspace_store as ws_store

load_dotenv()

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
REPORT_DIR = DATA_DIR / "reports"
FRONTEND_DIR = ROOT / "frontend"
STATIC_DIR = ROOT / "static"

for folder in (UPLOAD_DIR, REPORT_DIR):
    folder.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="CAVAI", version="0.2.0-agents-sdk")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.mount("/frontend", StaticFiles(directory=str(FRONTEND_DIR)), name="frontend")

SESSIONS: Dict[str, List[Dict[str, str]]] = {}
UPLOADS: Dict[str, Dict[str, Any]] = {}

ALLOWED_EXTENSIONS = {".catpart", ".catproduct", ".step", ".stp", ".zip"}


class ChatRequest(BaseModel):
    session_id: Optional[str] = None
    message: str
    file_id: Optional[str] = None
    mode: str = "review"  # review / intent / continue (continue a previously saved Agent report)
    trace_id: Optional[str] = None  # Browser-generated UUID, local progress polling only


class SettingsRequest(BaseModel):
    base_url: str
    api_key: str = ""
    model: str
    limits_enabled: bool = False
    max_requests: int = 4
    max_turn_est_tokens: int = 30000


class SettingsTestRequest(SettingsRequest):
    test_mode: str = "basic"  # basic (no tools) or tools (test native FC)


def safe_extract_zip(zip_path: Path, destination: Path) -> List[Path]:
    """Extract a user ZIP while rejecting path traversal entries."""
    extracted: List[Path] = []
    destination_resolved = destination.resolve()
    with zipfile.ZipFile(zip_path, "r") as archive:
        for member in archive.infolist():
            if member.is_dir():
                continue
            target = (destination / member.filename).resolve()
            if destination_resolved not in target.parents and target != destination_resolved:
                raise HTTPException(status_code=400, detail="ZIP中包含不安全的路径，已拒绝解压。")
            archive.extract(member, destination)
            extracted.append(target)
    return extracted


@app.get("/", response_class=HTMLResponse)
def home():
    return FileResponse(FRONTEND_DIR / "index.html")


@app.get("/api/health")
def health():
    return {
        "ok": True,
        "app": "CAVAI",
        "version": "0.2.0-agents-sdk",
        "python_note": "Python 3.9 compatible; openai-agents==0.8.4",
        "llm_configured": public_settings()["configured"],
        "llm_model": public_settings()["model"],
        "catia_adapter": "CATIA COM + OCP; STEP direct OCP",
        "agent_runtime": "OpenAI Agents SDK 0.8.4 Runner",
        "python_version": os.sys.version.split()[0],
        "pycatia_installed": __import__("importlib.util").util.find_spec("pycatia") is not None,
        "pywin32_installed": __import__("importlib.util").util.find_spec("win32com") is not None,
        "catia_available_check": "not_checked",
        "skills_count": len(list_skills())
    }


@app.get("/api/skills")
def get_skills():
    """Return skill metadata only; full skill files are loaded on demand by the Agent."""
    return {"skills": list_skills()}


@app.get("/api/settings")
def get_settings():
    data = public_settings()
    data["model_capabilities"] = detect_model_capabilities(data["base_url"], data["model"])
    return data


@app.post("/api/settings")
def update_settings(request: SettingsRequest):
    existing = get_llm_settings()
    api_key = request.api_key.strip() or existing["api_key"]
    if not request.base_url.strip() or not api_key or not request.model.strip():
        raise HTTPException(status_code=400, detail="API Base URL、API Key和模型名称都必须填写。")
    try:
        options = request.dict(exclude={"base_url", "api_key", "model"})
        save_llm_settings(request.base_url, api_key, request.model, **options)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True, "settings": public_settings()}


@app.post("/api/settings/test")
def test_settings(request: SettingsTestRequest):
    """An explicitly paid API diagnostic; not executed during normal upload/review."""
    existing = get_llm_settings()
    cfg = {**existing, **request.dict(exclude={"test_mode"})}
    cfg["api_key"] = request.api_key.strip() or existing["api_key"]
    cfg["model"] = request.model.strip() or existing["model"]
    try:
        cfg["base_url"] = normalize_base_url(request.base_url.strip() or existing["base_url"])
        validate_limits(cfg)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    if not cfg["api_key"] or not cfg["model"] or not cfg["base_url"]:
        raise HTTPException(status_code=400, detail="请先填好完整的Base URL、Key和模型名称。")
    if request.test_mode not in ("basic", "tools"):
        raise HTTPException(status_code=400, detail="未知测试模式")

    import uuid as _uuid
    from openai import OpenAI
    tracker = Tracker(cfg, _uuid.uuid4().hex[:16], stage="connectivity_test_" + request.test_mode)
    try:
        client = OpenAI(api_key=cfg["api_key"], base_url=cfg["base_url"], max_retries=0, timeout=35.0)
        spec = [{"type": "function", "function": {
            "name": "load_skill", "description": "Call CAVAI's selected local skill",
            "parameters": {"type": "object", "properties": {"skill_name": {"type": "string"}},
                           "required": ["skill_name"], "additionalProperties": False}}}]
        messages = [{"role": "user", "content": "测试：请调用load_skill，skill_name设为cad-model-intake。不要生成报告。"}] \
            if request.test_mode == "tools" else [{"role": "user", "content": "只回答OK"}]
        response = tracker.completion(client, messages, spec if request.test_mode == "tools" else None,
                                      "native_test" if request.test_mode == "tools" else "basic_test", 1, max_tokens=90)
        calls = getattr(response.choices[0].message, "tool_calls", None) or []
        tool_ok = any(getattr(getattr(c, "function", None), "name", None) == "load_skill" for c in calls)
        if request.test_mode == "tools" and not tool_ok:
            result = tracker.finish("incomplete", "原生tools请求成功，但没有获得真实load_skill指令")
            return {"ok": True, "tool_calling_verified": False, "usage": result,
                    "message": "API基本请求成功，但模型未返回原生load_skill。不能认定Tool Calling已兼容。请核对模型是否支持原生工具调用。"}
        result = tracker.finish("completed")
        return {"ok": True, "tool_calling_verified": tool_ok if request.test_mode == "tools" else None,
                "usage": result,
                "message": ("成功收到原生load_skill工具指令；此测试未真正执行Skill。" if tool_ok else
                            "基础Chat Completions请求成功。没有测试Function Calling。")}
    except Exception as exc:
        result = tracker.finish("failed", scrub(exc, cfg["api_key"]))
        raise HTTPException(status_code=400,
                            detail="API测试失败：{}。本次尝试已写入Token账本：{}".format(scrub(exc, cfg["api_key"]), result["turn_id"]))


@app.get("/api/usage/summary")
def usage_summary(limit: int = 70):
    return get_ledger_summary(limit=limit)


@app.get("/api/usage/download")
def usage_download():
    ledger = usage_ledger.LEDGER_PATH
    if not ledger.exists():
        raise HTTPException(status_code=404, detail="还没有产生API调用日志。")
    return FileResponse(ledger, media_type="application/x-ndjson", filename="CAVAI_0.2.0_Token_Ledger.jsonl")


@app.get("/api/reports/{report_id}/download")
def download_report(report_id: str):
    if not re.fullmatch(r"[0-9a-f]{32}", report_id):
        raise HTTPException(status_code=400, detail="无效报告ID")
    report_path = REPORT_DIR / (report_id + ".json")
    if not report_path.is_file():
        raise HTTPException(status_code=404, detail="报告不存在。")
    return FileResponse(
        report_path,
        media_type="application/json",
        filename="CAVAI_Report_{}.json".format(report_id[:8])
    )


@app.get("/api/reports/{report_id}/download/markdown")
def download_markdown_report(report_id: str):
    if not re.fullmatch(r"[0-9a-f]{32}", report_id):
        raise HTTPException(status_code=400, detail="无效报告ID")
    target = REPORT_DIR / f"{report_id}.md"
    if not target.is_file():
        raise HTTPException(status_code=404, detail="Agent Markdown报告不存在")
    return FileResponse(target, media_type="text/markdown; charset=utf-8",
                        filename=f"CAVAI_Agent_Report_{report_id[:8]}.md")


def _get_upload(file_id: Optional[str]) -> Optional[Dict[str, Any]]:
    """Recover uploaded CAD file after process restart, without network access."""
    if not file_id or not ws_store.valid_id(file_id):
        return None
    cached = UPLOADS.get(file_id)
    if cached is not None:
        return cached
    restored = ws_store.load_upload(file_id)
    if restored is not None:
        UPLOADS[file_id] = restored
    return restored


@app.get('/api/history')
def list_review_history(limit: int = 80):
    """Pure local filesystem operation; this must never call the model API."""
    return {'items': ws_store.list_workspaces(limit)}


@app.get('/api/history/{session_id}')
def read_review_history(session_id: str):
    snapshot = ws_store.get_workspace(session_id)
    if snapshot is None:
        raise HTTPException(status_code=404, detail='找不到本地评测历史')
    upload = _get_upload(snapshot.get('file_id'))
    if upload is not None:
        # Geometry preview is from an already generated image; never re-run CAD on opening history.
        snapshot['model_available'] = True
        snapshot['preview_url'] = ('/api/models/{}/preview'.format(snapshot['file_id'])
                                   if upload.get('auto_view_path') else None)
        snapshot['model_size'] = upload.get('size', 0)
    else:
        snapshot['model_available'] = False
        snapshot['preview_url'] = None
    return snapshot


@app.post("/api/models/{file_id}/view")
async def upload_model_view(file_id: str, file: UploadFile = File(...)):
    """Optional local screenshot. Never sent by default; only with verified vision provider."""
    upload = _get_upload(file_id)
    if upload is None:
        raise HTTPException(status_code=404, detail="模型不存在")
    if Path(file.filename or '').suffix.lower() not in {'.png', '.jpg', '.jpeg', '.webp'}:
        raise HTTPException(status_code=400, detail="仅支持PNG/JPG/WebP视图")
    raw = await file.read(4 * 1024 * 1024 + 1)
    if len(raw) > 4 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="视图超过4MB")
    try:
        from PIL import Image
        from io import BytesIO
        im = Image.open(BytesIO(raw))
        im.verify()
        im = Image.open(BytesIO(raw)).convert('RGB')
        im.thumbnail((720, 720))
        out = Path(upload['original_path']).parent / 'cad_view_preview.jpg'
        im.save(out, format='JPEG', quality=68, optimize=True)
        upload['view_path'] = str(out)
        ws_store.save_upload(upload)
    except Exception:
        raise HTTPException(status_code=400, detail="无法读取视图图像")
    caps = detect_model_capabilities(get_llm_settings()['base_url'], get_llm_settings()['model'])
    return {'ok': True, 'stored_locally': True,
            'vision_usable': caps['vision'], 'capability_status': caps['status'],
            'note': '识别用途或评测时，对已确认视觉能力的模型进行单次视图观察，随后仅传文本摘要；不发送原始CAD文件。'}


@app.post("/api/upload")
async def upload_model(file: UploadFile = File(...)):
    filename = Path(file.filename or "uploaded_model").name
    suffix = Path(filename).suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail="目前支持 .CATPart、.CATProduct、.STEP/.STP 和包含模型的 .ZIP。"
        )

    file_id = uuid.uuid4().hex
    session_dir = UPLOAD_DIR / file_id
    session_dir.mkdir(parents=True, exist_ok=True)
    target = session_dir / filename

    size = 0
    with target.open("wb") as out:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            if size > 500 * 1024 * 1024:
                shutil.rmtree(session_dir, ignore_errors=True)
                raise HTTPException(status_code=413, detail="文件超过500MB限制。")
            out.write(chunk)

    extracted_files: List[str] = []
    primary_document: Optional[Path] = None

    if suffix == ".zip":
        try:
            extracted = safe_extract_zip(target, session_dir / "extracted")
        except zipfile.BadZipFile:
            shutil.rmtree(session_dir, ignore_errors=True)
            raise HTTPException(status_code=400, detail="上传文件不是有效ZIP。")
        cad_files = [p for p in extracted if p.suffix.lower() in {".catproduct", ".catpart", ".stp", ".step"}]
        products = [p for p in cad_files if p.suffix.lower() == ".catproduct"]
        primary_document = products[0] if products else (cad_files[0] if cad_files else None)
        extracted_files = [str(p.relative_to(session_dir)) for p in cad_files]
    else:
        primary_document = target

    if primary_document is None:
        shutil.rmtree(session_dir, ignore_errors=True)
        raise HTTPException(status_code=400, detail="ZIP中没有找到CATPart、CATProduct或STEP文件。")

    UPLOADS[file_id] = {
        "file_id": file_id,
        "filename": filename,
        "path": str(primary_document),
        "original_path": str(target),
        "extension": primary_document.suffix.lower(),
        "size": size,
        "extracted_files": extracted_files,
    }

    ws_store.save_upload(UPLOADS[file_id])

    return {
        "file_id": file_id,
        "filename": filename,
        "size": size,
        "model_type": primary_document.suffix.lower().lstrip(".").upper(),
        "primary_document": primary_document.name,
        "extracted_cad_files": extracted_files,
        "message": "文件已接收；CATPart/CATProduct由本机CATIA解析，STEP由本地OCP直接解析。"
    }


def _brief_inspection(inspection: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not inspection:
        return None
    geo = inspection.get("geometry") or {}
    keys = ("status", "solid_count", "face_count", "edge_count", "hole_candidate_count",
            "catia_body_count", "error", "face_type_counts", "cylindrical_face_counts")
    summary = {k: geo[k] for k in keys if k in geo} if geo else None
    if summary is not None:
        graph = geo.get('feature_graph') or {}
        summary['structure_feature_count'] = graph.get('feature_count', 0)
        summary['structure_relation_count'] = graph.get('relation_count', 0)
        summary['auto_view_available'] = (geo.get('preview') or {}).get('status') == 'ok'
    return {
        "status": inspection.get("status"),
        "error": inspection.get("error"),
        "document_type": inspection.get("document_type"),
        "geometry": summary,
    }


def _ensure_model_inspection(upload: Dict[str, Any]) -> Dict[str, Any]:
    """Run expensive local CAD inspection once; never call an external model API."""
    if 'inspection' not in upload:
        cached = ws_store.load_cached_inspection(upload)
        if cached is not None:
            upload['inspection'] = cached
        else:
            upload['inspection'] = inspect_model(upload['path'])
        if cached is None:
            try:
                upload['evidence_path'] = str(save_inspection_evidence(
                    upload['file_id'], upload['path'], upload['inspection']))
            except (OSError, ValueError) as exc:
                upload['evidence_save_error'] = str(exc)[:250]
    inspection = upload['inspection']
    geometry = (inspection or {}).get('geometry') or {}
    preview = geometry.get('preview') or {}
    if preview.get('status') == 'ok':
        path = Path(preview.get('preview_path') or '')
        local_home = Path(upload['path']).resolve().parent
        if path.is_file() and path.resolve().parent == local_home:
            upload['auto_view_path'] = str(path)
        else:
            local_view = local_home / (Path(upload['path']).stem + '_four_views.jpg')
            if local_view.is_file():
                upload['auto_view_path'] = str(local_view)
    return inspection


@app.get('/api/models/{file_id}/summary')
def get_model_local_summary(file_id: str):
    """Free local preview: no API key, no network and zero Token charges."""
    upload = _get_upload(file_id)
    if not upload:
        raise HTTPException(status_code=404, detail='模型文件不存在')
    inspection = _ensure_model_inspection(upload)
    return {'file_id': file_id, 'inspection': _brief_inspection(inspection),
            'preview_url': ('/api/models/{}/preview'.format(file_id)
                            if upload.get('auto_view_path') else None),
            'note': '仅本地CATIA/OCP解析与结构关系分组，不调用收费API。'}


@app.get("/api/runs/{trace_id}/events")
def read_run_events(trace_id: str):
    """Local read-only execution trace, never a provider API request."""
    snapshot = live_progress.snapshot(trace_id)
    if snapshot is None:
        raise HTTPException(status_code=404, detail="找不到本次分析记录")
    return snapshot


@app.post("/api/chat")
def chat(request: ChatRequest):
    """Per-model review workspace; continuation and history are local-first."""
    if request.mode not in {'review', 'intent', 'continue'}:
        raise HTTPException(status_code=400, detail='仅支持识别用途、首次评测、继续评测')
    trace_id = request.trace_id or uuid.uuid4().hex
    if not live_progress.valid_id(trace_id):
        raise HTTPException(status_code=400, detail='无效本地追踪ID')
    if request.session_id and not ws_store.valid_id(request.session_id):
        raise HTTPException(status_code=400, detail='无效会话ID')

    session = ws_store.get_workspace(request.session_id) if request.session_id else None
    if request.session_id and not session:
        raise HTTPException(status_code=404, detail='历史会话不存在，请从评测历史重新选择')
    file_id = request.file_id or (session.get('file_id') if session else None)
    if session and request.file_id and request.file_id != session.get('file_id'):
        raise HTTPException(status_code=409, detail='当前会话绑定的是另一份模型，请新建评测后上传')
    upload = _get_upload(file_id) if file_id else None
    if not upload:
        if request.file_id or session:
            raise HTTPException(status_code=404, detail='模型文件不存在。请上传模型，或从评测历史恢复包含模型的会话')
        # Preserve the 0.1.13 zero-fee local block for a missing model.
        result = run_review(message=request.message, history=[], upload=None, inspection=None,
                            trace_id=trace_id)
        return {'session_id': None, 'trace_id': trace_id, 'reply': result['reply'],
                'inspection': None, 'report': None, 'report_id': None,
                'report_download_url': None, 'tool_trace': [], 'loaded_skills': [],
                'provider': result.get('provider'), 'usage': result.get('usage')}

    if session is None:
        if request.mode == 'continue':
            raise HTTPException(status_code=409, detail='首次评测尚未完成，不能续评')
        session = ws_store.create_workspace(file_id, upload.get('filename', 'CAD模型'))
    session_id = session['session_id']
    if request.mode == 'continue' and not session.get('reports'):
        raise HTTPException(status_code=409, detail='尚无上一版报告，请先完成首次评测')
    if not ws_store.begin_session_run(session_id):
        raise HTTPException(status_code=409, detail='此会话正在评测中，已阻止重复付费请求')

    try:
        live_progress.begin(trace_id, '已收到本次识别/续评任务' if request.mode == 'continue' else '已收到本次识别/评测任务')
        if 'inspection' not in upload:
            live_progress.event(trace_id, 'cad', '检查本机模型几何缓存', '优先使用既有B-Rep证据，避免重复解析或重新上传')
        inspection = _ensure_model_inspection(upload)
        geometry = (inspection or {}).get('geometry') or {}
        if inspection.get('status') == 'ok' and geometry.get('status') == 'ok':
            live_progress.event(trace_id, 'cad', '本地几何解析完成 · 已就绪',
                                'Solid {} · Face {} · Edge {} · 孔候选 {}'.format(
                                    geometry.get('solid_count', '?'), geometry.get('face_count', '?'),
                                    geometry.get('edge_count', '?'), geometry.get('hole_candidate_count', '?')))
        else:
            live_progress.event(trace_id, 'error', 'CAD几何尚未成功解析', '评测将阻止收费请求')

        history = [{'role': m.get('role'), 'content': m.get('content', '')}
                   for m in (session.get('messages') or [])[-16:]
                   if m.get('role') in {'user', 'assistant'}]
        continuation = ws_store.concise_report_context(session) if request.mode == 'continue' else None
        if request.mode == 'continue' and not continuation:
            raise HTTPException(status_code=409, detail='上一版报告丢失或损坏；不能盲目续评')
        version = len(session.get('reports') or []) + 1
        parent = session.get('current_report_id') if request.mode == 'continue' else None
        if request.mode == 'intent':
            result = run_intent(request.message, upload, inspection, trace_id=trace_id)
        elif request.mode == 'continue':
            result = run_review(message=request.message, history=history,
                                upload=upload, inspection=inspection, trace_id=trace_id,
                                report_context=continuation)
        else:
            # Preserve existing 0.1.13 tool/Runner API for initial reviews.
            result = run_review(message=request.message, history=history,
                                upload=upload, inspection=inspection, trace_id=trace_id)

        history_error = None
        if result.get('report_id') and ws_store.valid_id(result['report_id']):
            # A generated Agent report must remain deliverable even if writing
            # history metadata fails. It can be imported into history later.
            try:
                ws_store.annotate_report(result['report_id'], session_id, version, parent,
                                         request.message, request.mode)
                result['report'] = ws_store.load_report(result['report_id'])
            except FileNotFoundError:
                # Compatibility with purely synthetic unit-test responses.
                pass
            except (OSError, ValueError) as exc:
                history_error = '报告版本元数据保存失败：' + str(exc)[:150]
        try:
            new_session = ws_store.save_turn(session_id, request.mode, request.message,
                                             result, version, parent)
        except (OSError, ValueError) as exc:
            # Never hide a paid Agent report behind a local history write error.
            history_error = '本地评测历史保存失败：' + str(exc)[:150]
            new_session = session
        try:
            if upload.get('vision_observations'):
                ws_store.save_upload(upload)
        except (OSError, ValueError) as exc:
            history_error = (history_error or '模型图片观察缓存保存失败：' + str(exc)[:150])
        final_status = (result.get('usage') or {}).get('status')
        if final_status in {'completed', 'partial'}:
            live_progress.finish(trace_id, 'completed',
                                 '续评报告 V{} 已保存'.format(version) if result.get('report_id') and request.mode == 'continue'
                                 else ('报告已保存' if result.get('report_id') else '模型用途识别完成'))
        else:
            live_progress.finish(trace_id, 'failed', '本轮已结束，详细错误见回复或Token账本')
        return {
            'session_id': session_id, 'trace_id': trace_id,
            'reply': result.get('reply'), 'inspection': _brief_inspection(inspection),
            'provider': result.get('provider', 'local_cad_review'),
            'tool_trace': result.get('tool_trace', []),
            'loaded_skills': result.get('loaded_skills', []),
            'evidence_saved_locally': bool(upload.get('evidence_path')),
            'evidence_save_error': upload.get('evidence_save_error'),
            'vision_capability': detect_model_capabilities(get_llm_settings()['base_url'], get_llm_settings()['model']),
            'report': result.get('report'),
            'report_id': result.get('report_id'),
            'report_version': version if result.get('report_id') else None,
            'report_download_url': result.get('report_download_url'),
            'report_versions': new_session.get('reports', []),
            'history_save_error': history_error,
            'mode': request.mode, 'turn_id': result.get('turn_id'), 'usage': result.get('usage'),
        }
    except HTTPException:
        live_progress.finish(trace_id, 'failed', '续评准备失败，没有发送请求')
        raise
    except Exception as exc:
        live_progress.finish(trace_id, 'failed', '本地会话保存或准备失败')
        raise HTTPException(status_code=500, detail='本地会话处理失败：{}'.format(str(exc)[:200]))
    finally:
        ws_store.end_session_run(session_id)


@app.get('/api/models/{file_id}/preview')
def get_model_preview(file_id: str):
    """Local-only four-view image generated from the uploaded CAD geometry."""
    upload = _get_upload(file_id)
    if upload is None:
        raise HTTPException(status_code=404, detail='找不到上传模型')
    preview = Path(upload.get('auto_view_path') or '')
    if not preview.is_file() or preview.resolve().parent != Path(upload['path']).resolve().parent:
        raise HTTPException(status_code=404, detail='尚未成功生成模型四视图')
    return FileResponse(preview, media_type='image/jpeg', filename='CAVAI_CAD_Four_Views.jpg')


@app.get("/api/models/{file_id}/geometry")
def get_model_geometry(file_id: str):
    upload = _get_upload(file_id)
    if not upload:
        raise HTTPException(status_code=404, detail="找不到上传模型，请重新上传。")
    inspection = _ensure_model_inspection(upload)
    geometry = inspection.get("geometry") if inspection else None
    if not geometry:
        raise HTTPException(status_code=404, detail="当前模型没有几何解析结果。")
    if geometry.get("status") != "ok":
        raise HTTPException(status_code=409, detail=geometry.get("error", "B-Rep解析未完成。"))
    return geometry


@app.get("/api/reports/{report_id}")
def get_report(report_id: str):
    path = REPORT_DIR / f"{report_id}.json"
    if not path.exists():
        raise HTTPException(status_code=404, detail="报告不存在。")
    return json.loads(path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=False)
