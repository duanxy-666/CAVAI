# CAVAI_v0.2.0 — CATIA 模型评测续接与历史版本

> Windows + Python 3.9 + CATIA V5 / Open CASCADE + OpenAI Agents SDK 0.8.4。
> **v0.2.0 的新目标：在真实 Agent 首次报告生成后，用户继续补充信息，Agent 沿用本地证据、上一版报告进行续评，生成独立的 V2/V3 版本。**

## 使用方法（用户端）

1. 上传 CATPart、CATProduct、STEP/STP，选择“本地预览”查看几何；本地预览不计费。
2. 点击“开始评测”，由 Agents SDK 自主调用本地 Skill/几何查询，生成 **Agent 实际输出**的 Markdown 报告 V1。
3. 看完 V1，在聊天输入框补充或修正设计要求，直接点击“继续评测”：Agent 能访问上一版报告摘要、最近对话与原模型，按需进一步调用工具，生成 V2。
4. 点击左侧“评测历史”，恢复已保存的工作空间；右侧“报告版本”可切换 V1、V2，历史报告不被覆盖。
5. 历史浏览/切换报告/本地模型预览均不调用云端 API；只有识别用途、开始或继续评测才会使用用户所配置的模型。

**重要：** 不需要手工创建长提示词；若没有已保存报告，“继续评测”会在本地被拒绝，避免无效付费请求。用户关闭限额时仍保留硬性安全熔断。

## 从 0.1.13 升级（必须保留原有数据）

新版本源码包不包含你的 API Key、CAD 模型或历史账本。建议先关闭旧版本，然后：

1. 解压 `CAVAI_v0.2.0.zip` 到**新的目录**，不要直接覆盖运行中的旧项目。
2. 将旧项目的 **整个 `data/` 文件夹的内容** 复制到新项目 `data/` 对应目录（包括 `settings.json`、`uploads/`、`evidence/`、`reports/`、`usage/`）。注意：这些包含个人 API Key、工程模型和日志，**不要发到公网**。
3. 在你的 Python 3.9 虚拟环境执行 `python -m pip install -r requirements.txt` 和 `python -m pip install -r requirements-catia.txt`，然后 `python run.py`。
4. 打开 `http://127.0.0.1:8000`，点击“评测历史”。0.1.13 留在 `data/reports/` 的真实 Agent 报告会被**本地导入索引**，原报告文件不会被改写；如果对应 `data/uploads/` 已复制，即可继续评测。
5. 老版仅保存在 RAM 的聊天记录无法恢复；可恢复的是已经保存的 Agent Markdown 报告和模型证据。

## 核心实现

- `workspace_store.py`：本地 `data/workspaces/<session_id>.json` 原子存储会话、消息、报告版本；把旧版 Agent 报告导入历史索引。
- `main.py`：新增 `GET /api/history`、`GET /api/history/{session_id}`，`POST /api/chat` 支持 `mode=continue`；工作空间绑定单个 CAD 模型。
- `agent/sdk_agent.py`：首次多轮工具调用保留；续评增加**有限长度**的上轮 Agent 报告摘要及用户修改要求，完整 B-Rep 仍在本地；续评默认不重复发送视觉图片。
- `reports/agent_report.py`：继续保存真实 Agent 返回的 Markdown；历史元数据含 `session_id`、`report_version`、`based_on_report_id`，每一版独立文件。
- `frontend/`：评测历史导航、本地恢复聊天与模型、V1/V2 切换、智能“继续评测”按钮。
- `data/usage/events.jsonl`：保留逐笔 HTTP 计费记录；历史恢复不会新增任何模型请求。

**模型没有修改就是同一份几何证据。** 如上传修改后的 CATPart，CAVAI 创建新会话，不会把两个模型的几何视为相同。材料、载荷、装配约束未知时，不能把可能的力学风险写成已验证结论。

## 运行与零费用验证

```powershell
python -m pip install -r requirements.txt
python -m pip install -r requirements-catia.txt
python -m unittest tests.test_review_history_020 -v
python run.py
```

历史与续评测试采用模拟 Agent 输出，**没有使用付费 API**。构建环境没有真实 Agents SDK 0.8.4，因此 SDK 运行时/Windows CATIA/实际 DeepSeek 在线端到端仍需在用户电脑验证。测试通过不等于已验证真实模型准确率。

---

## 0.1.13 功能与技术背景（沿用）

# CAVAI_v0.1.13 — CATIA 结构证据增强版

> 本版重点：**结构几何关系图 + 自动生成四视图 + Agent按证据查询**。
> 保留 Python 3.9 / OpenAI Agents SDK 0.8.4 / 现有本地 Skill / 用户选择 DeepSeek 等 API。
> 不是训练好的 CAD 特征识别神经网络，也不保证专业工程判断准确。

## 第一件事：可以不花 Token 看到效果

```powershell
python -m pip install -r requirements.txt
python -m pip install -r requirements-catia.txt
python -m unittest tests.test_0113_structure_and_vision -v
python run.py
```

网页上传模型后，点击 **「本地预览 · 免费」**：会在本机解析几何、生成结构关系与四视图，不需要 API Key，也不会调用收费模型。确认本地预览正确后再点击「识别用途」或「开始评测」。

`examples/through_hole_four_views.jpg` 是本地 OCP 真实渲染的示例，不是 AI 生成的图。
`examples/through_hole_structure.json` 是对应 B-Rep 分组示例；`examples/through_hole.step` 可用于上传测试。
示例旨在检查几何功能，不包含预置 Agent 评测结论。

## 真正增加的能力

1. `cad/feature_graph.py`：从 face/edge 邻接关系分组共圆柱、共平面的相邻区域；保留圆柱内外侧、轴线、孔候选、同轴（纯几何）关系及每项的原始 Face ID。
2. `cad/model_views.py`：本地 OCP 网格化 + Pillow 生成等轴、正、俯、右视图，默认仅保存用户电脑；预览不影响 B-Rep 分析的成功与否。
3. `agent/model_context.py`：优先将结构区域与关联关系的**有界摘要**送给 API，避免把原始 392 个 Face 全塞进去。
4. `agent/sdk_agent.py`：保留 Agent SDK 工具循环，新增 `get_structure_overview`、`get_structure_feature`、`find_structure_features`；先提出功能假设、再依据结构图/局部几何查询验证。
5. **单次视觉观察并缓存：** 仅对于已确认支持图片的模型（如 DeepSeek 官方 `deepseek-flash`），在第一次正式评测时**额外发起一次**小图片的识别请求，再把视觉摘要交给多轮工具 Agent；后续请求**不再附图**。后续针对同一文件、同一模型的评测在本进程内复用视觉观察。用户开启低请求上限时跳过可选的视觉阶段。
6. 网页模型卡片可看本机四视图；Token账本继续记录每次 HTTP API 请求。图片不会绕过预算限制，也不会把原始 CATPart/STEP 发给 API。

### 关键限制

- **圆柱面聚合成区域 != 自动识别出轴、螺栓或螺母。** 孔仍是拓扑候选，没有孔候选不代表所有异形孔都不存在。
- **同轴 != 配合/约束/接触。** 没有材料、载荷和工况时不能声称通过了力学强度分析。
- 多视图是软件网格渲染的几何辅助，局部遮挡和曲面可能存在视觉误差，不作为精确测量依据。
- 复杂模型视图网格超过 100000 三角形时，本地渲染可能跳过，但几何数据依然有效。
- 视觉阶段如果支持则增加一次模型请求和可能的费用；不会隐瞒或免费假装。支持未知的服务商默认只用结构化文本。
- 实际 Windows CATIA V5 与用户 DeepSeek API 尚未在本构建环境完成实测。测试中的 Agent 回复均为模拟返回，不是用户模型真实 AI 报告。

### 开源依据与实现边界

- [AAGNet](https://github.com/whjdark/AAGNet) 使用 B-Rep 几何属性邻接图表示 CAD 特征。CAVAI **只借鉴邻接图的表示思路**，本版没有集成 AAGNet 权重、神经网络或完整特征分割。
- [OCCT Mesh](https://www.occt3d.com/dev/doc/overview/html/occt_user_guides__mesh.html) 说明 `BRepMesh_IncrementalMesh` 和几何网格提取，本版通过 OCP 使用。
- [DeepSeek Vision](https://api-docs.deepseek.com/guides/vision/) 说明已支持模型的图片输入方式；第三方兼容接口不盲测视觉能力。
- [OpenAI Agents SDK](https://pypi.org/project/openai-agents/0.8.4/) 提供 SDK Runner 工具循环。这个项目不自写 LLM while 循环。

---

## v0.1.12 ExtraBodyFix — 修复重复 extra_body 参数（零费用检查）

**故障现象：**

`AsyncCompletions.create() got multiple values for keyword argument 'extra_body'`

**已定位根因：** `agent/sdk_agent.py` 将 `extra_body` 塞在 `ModelSettings.extra_args` 内，
但 OpenAI Agents SDK 的 Chat Completions 适配器已经使用独立的 `extra_body` 参数。
Python 在发起 HTTP 请求前发现重复命名的函数参数，直接抛出 `TypeError`。
这和 CATIA、模型文件、DeepSeek 账户余额无关。故障当次账本通常显示 0 请求和 0 Token。

**修复：** 使用 `ModelSettings(extra_body={'thinking': {'type': 'disabled'}})`，
不使用 `extra_args={'extra_body': ...}`。仅对官方 DeepSeek 域名及明确的
`deepseek-flash` / `deepseek-v4-pro` 模型设置该选项，其他 API 不传。
启动前的 SDK 模型设置预检与本地模拟 HTTP 端到端测试也已加入。

**用户已有依赖无需再次升级或降级**，只需使用修复后的代码，或将
`agent/sdk_agent.py` 中错误的 `extra_args` 改成 `extra_body`。重启后，在同一
PyCharm Python 3.9 解释器中先执行以下命令（完全不联网、不扣费）：

```powershell
python -m unittest tests.test_sdk_mock_http -v
python -m unittest tests.test_sdk_runtime_smoke -v
python run.py
```

如果第一条出现 `skipped`，表示该 Python 解释器内没有实际安装 Agents SDK，
这时不能宣称真实 SDK 兼容性已验证。若 `test_actual_runner_tool_then_report_without_network`
通过，则说明**真实 SDK 0.8.4 → 模拟 Chat Completions → 本地工具 → 最终报告**
在本地通路通过，未使用 DeepSeek API。

此包仍未在用户 Windows、CATIA 和真实 DeepSeek 账户上完成付费端到端验证。

# CAVAI_v0.1.12 —（上一版说明） CATIA 设计评测 Agent

**目标：上传 CATPart、CATProduct 或 STEP → Python/CATIA/OCP 解析 → 云端 Agent 自主调用本地 Skill 和几何查询 → Agent 写出工程报告 → 网页展示/下载。** 评测正确率是后续提高的目标，不用预写产品类型或强迫用户会写提示词。

## 紧急兼容性修复：Agent 尚未调用 API 就报 cache_write_tokens

2026-11-20：原版本 `requirements.txt` 错误地允许 `openai==2.48.0`。
旧版 Agents SDK 调用 `Usage()` 时只传入 `cached_tokens=0`，但
`openai>=2.45.0` 的 `InputTokensDetails` 又要求必填 `cache_write_tokens`。
导致 Agent 在发送请求前抛出 `ValidationError`。对应官方 issue：
https://github.com/openai/openai-agents-python/issues/3772

本包已经将 `openai==2.44.0` 固定，参考官方报告的 workaround，并在 `run.py`
添加**不产生 Token 的启动前 Usage() 兼容性检查**。如果你已经安装了旧包，
先关闭 CAVAI，在原来的 PyCharm Terminal 运行：

```powershell
python -m pip install --force-reinstall --no-deps "openai==2.44.0"
python -m pip check
python -c "from agents.usage import Usage; Usage(); print('SDK Usage OK')"
```

通过后再运行 `python run.py`。不能仅替换 ZIP 而不重新安装依赖：
旧环境中的 `openai==2.48.0` 不会自动降级。

本修复只覆盖已经由截图和官方 issue 确认的依赖兼容故障；
没有宣称真实 DeepSeek API 端到端评测已经通过。

## 技术选型（有出处）

- Agent：**OpenAI Agents SDK `0.8.4`**，PyPI 官方元数据明确支持 **Python ≥3.9**。使用其 `Agent`、`Runner.run`、`function_tool`、`OpenAIChatCompletionsModel` 和 `max_turns`；不自行编写多轮 LLM 调度循环。源码 `agent/sdk_agent.py`。
- API：用户填写自己的 OpenAI **Chat Completions 兼容** Base URL、API Key、模型名。首选验证对象是 DeepSeek 官方 `https://api.deepseek.com` + `deepseek-flash`；其他服务商要支持对应的原生工具调用协议。Agent SDK 是运行框架，不代表必须购买 OpenAI API。
- CAD：`cad/format_router.py`、`cad/catia_reader.py`、`cad/brep_analyzer.py`。STEP/STP 本地直接 OCP；CATPart/CATProduct 需 Windows CATIA V5 COM，先本地导出 STEP，再 OCP 提取几何。
- Skill：`skills/*/SKILL.md` 完全在本机，Agent **真正调用** `load_skill` 后才读到该文件；具体面、边、孔和尺寸由 Python `get_current_model_facts`、`search_model_geometry`、`get_geometry_entity_by_id` 等工具读取，不是 Skill 文件直接执行几何计算。
- Skill选择：随代码包预装，用户不需要下载或配置GitHub项目；按模型类别选择 `fastener-review`（紧固/孔）、`fixture-review`（夹具定位）、`manufacturing-dfm-review`（制造性）或已有的通用Skill。支持 `read_skill_reference` **按需加载**规则文件，并提供只读的 `check_fastener_hole_evidence` 本地几何检查工具。**这些是独立编写并注明来源的适配Skill，不代表已将第三方FreeCAD或text-to-cad的几何运行时代码移植进项目。**
- 报告：SDK Runner 的**最终实际文本输出**被本机 `reports/agent_report.py` 保存为 Markdown 和 JSON；**没有 `save_review_report` 工具**，不再用过长 JSON 参数让模型反复写文件。
- 用量：`agent/sdk_agent.py` 将 HTTPX 钩子挂在实际 OpenAI-compatible Chat Completions HTTP 请求上。每笔开始/成功/402/超时、服务商返回的 Token 与缓存 Token 都写入 `data/usage/events.jsonl`，不存 API Key 或完整模型。默认关闭 SDK/HTTP 自动重试。未得到 usage 时标记为未知；金额以服务商账单为准。

官方资料：

- Python 3.9 兼容 SDK 版本：https://pypi.org/project/openai-agents/0.8.4/
- Agents SDK Runner/本地 function tools：https://openai.github.io/openai-agents-python/running_agents/ 和 https://openai.github.io/openai-agents-python/tools/
- 官方 DeepSeek Chat Completions：https://api-docs.deepseek.com/api/create-chat-completion/
- CATIA Python Automation：https://github.com/evereux/pycatia
- Open CASCADE：https://dev.opencascade.org/

> 当前项目使用 **0.8.4** 的公共接口。官方文档网站的默认页面可能描述更高版本；因此固定了依赖版本。**本压缩包不内置第三方软件包**，须从可用的 PyPI 源安装。没有安装到真实 SDK 的环境不能宣称完成了真实框架集成测试。

## 在你的 Python 3.9 / PyCharm 上运行

1. 关闭旧 CAVAI；解压完整 ZIP；在 PyCharm 打开 `CAVAI_0.1.12` 文件夹，使用 **64 位 Python 3.9** 解释器（不需要升级 Python）。
2. 打开 PyCharm Terminal，在项目文件夹执行：

```powershell
python -m pip install -r requirements.txt
python -m pip install -r requirements-catia.txt
python -m unittest tests.test_sdk_runtime_smoke -v
python run.py
```

3. Ctrl + 左键点击终端打印的 `http://127.0.0.1:8000`，在 **API 设置** 里填 Base URL、Key、模型 ID，保存。
4. 上传 CATPart、CATProduct 或 STEP。可以不输入提示词；也可以先点击 **识别用途**（可选），检查系统对功能的猜测，补充或修正目标。然后点击 **开始评测**。
5. 查看 Agent 实际生成的报告和逐笔 Token 账本。报告存放在 `data/reports/`，完整 B-Rep 在 `data/evidence/`，用户文件在 `data/uploads/`。

**提示：** 如果只是 STEP，可不安装/启动 CATIA；如果是 CATPart/CATProduct，必须有本机可用的 CATIA V5 和 STEP 导出能力。运行 CAVAI 不要求访问 GitHub、LangSmith 或 OpenAI tracing 服务，**但云端 AI 评测必须能访问用户所选的 API 服务商**。

## Skill 与 Benchmark 的取舍

- **运行时用 Skill 组织检查方法和调用工具**；没有额外开发Benchmark打分模块。每个检查结论都要求来自CAD几何证据或用户要求；缺证据时报告“未验证”。
- 按 [Agent Skills规范](https://github.com/agentskills/agentskills/blob/main/docs/specification.mdx) 使用 `SKILL.md`、`references/` 渐进加载：启动只传Skill目录，Agent需要时才读取其正文与引用。
- 参考 [text-to-cad 的 DFM Skill](https://github.com/earthtojake/text-to-cad/blob/main/skills/dfm/SKILL.md) 的制造工艺分流方法以及 [freecad-automation](https://github.com/dooosp/freecad-automation) 的阶段式工程审查；**未安装/复制他们的CAD解析引擎**，只适配其公开的方法。第三方仓库许可与能力边界见 `references/SKILL_PROVENANCE.md`。
- 已可由Agent调用 `check_fastener_hole_evidence` 查询内外圆柱面/孔候选，仍不等于自动证明螺纹、力学强度或加工合格。

## Token 保护（界面只有一个可选开关）

默认不限制**用户预算**，仍有应用内硬性 **12 次请求**安全熔断；开启后可单独设置 **本次 Token 上限（估算）** 与 **API 请求次数上限**。Python 工具结果分页、按ID查询；重复的本地工具调用复用缓存，同样的完整 HTTP 请求超过两次会在发送前熔断。`max_retries=0`，不因 402/输出截断自动付费重试。Token 是按请求字节估算，上限不是服务商绝对计费承诺；实际 Token 以返回 usage 和服务商账单为准。

## 视觉输入

用户可上传可选截图。本版本 **仅在点击“识别用途”** 且模型能力表确认支持图像时，发送一次压缩视图。多轮正式评测主要传结构化几何文本、按需工具结果；不反复转发图像，也不直接把 CATPart 原文件发送给不支持 CAD 的 API。未知模型视觉能力默认禁用，不发付费探测请求。**用户可以不上传任何截图。**

## 闭环边界与已验证范围

- **本地已测试**：真实 OCP 创建并解析的 STEP（通孔、盲孔、实心凸台），FastAPI 上传→几何读取→模拟框架/模型调用→本地 Skill 工具→Markdown 报告下载；HTTPX 模拟 402、相同请求熔断、预算拦截、用量账本；Python 3.9 **语法**检查。
- **尚未验证**：真实安装的 `openai-agents==0.8.4` 与全部依赖在用户 Windows/Python 3.9 上运行；真实 DeepSeek 工具调用/视觉调用；用户 CATIA V5 的 STEP 导出。**请先运行零费用 smoke test**，确认 SDK 接口构造成功；只有在用户愿意并有可用额度的情况下才发起付费评测。
- API 不支持 Tool Calling 或模型未正常完成时会报告失败，不会假装已执行 Skill。模型给出最终报告但未调用任何本地工具时会明确标记为 **partial**，不能冒充已验证的工程报告。
- 几何拓扑检测不是力学求解器；材料、载荷、强度和装配关系缺失时应在报告中明确标注未验证，不能编造强度或配合数据。

## 主要代码

```
run.py                       # 启动网页（Python 3.9）
main.py                      # FastAPI 上传/评测/报告/账本接口
agent/sdk_agent.py           # OpenAI Agents SDK Runner + 本地工具 + HTTP Token 审计
agent/model_context.py       # CAD几何摘要/分页/按ID查询
agent/model_capabilities.py  # 不收费的保守视觉能力规则
cad/format_router.py         # CATIA文件和STEP的本地解析路由
cad/catia_reader.py          # CATIA COM读取和STEP导出
cad/brep_analyzer.py         # OCP B-Rep Face/Edge/Solid/孔候选
skills/                      # 预装的 Agent Skills 及按需参考文件（无需用户下载GitHub）
reports/agent_report.py      # Agent最终Markdown原文落盘
frontend/                    # 保留原界面和logo
```

## 本版界面与分析过程展示

- 评测页标题使用 **CATIA 设计评测**，顶部状态标识为 **CAVAI^_^**。
- 用户发起评测后会看到可展开的「Agent 分析过程」，本地网页每 900 毫秒查询一次 **本地** `/api/runs/{trace_id}/events`，不会为展示进度增加任何收费模型请求。
- 进度内容来自真实的模型解析、SDK 执行的本地 Skill/几何工具、API HTTP 请求与用量回执；有参数及截断后的工具结果预览。不会伪造模型私有思维链。
- Agent 最终 Markdown 要有简短「判断依据摘要」，用于解释可核验的工程推断。**这不是 DeepSeek/其他模型未公开的逐步推理原文**。原版默认关闭 DeepSeek 的 thinking 模式，本版没有偷偷开启，因此不额外增加推理 Token。
- 目前云端 API 收到的是 **Chat Completions JSON 消息：本地 B-Rep 摘要文本、用户要求、按需返回的局部几何 JSON**；原始 CATPart/STEP 文件和整份几何 JSON 不会上传。用户手动附加的视图在支持视觉的模型上，仅用于「识别用途」阶段一次。
- 本地进度记录存放内存（非永久审计日志），正式 HTTP Token 账本仍在 `data/usage/events.jsonl`。多进程或服务器重启会清空内存中的实时轨迹；推荐单进程启动。

