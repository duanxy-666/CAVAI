## CAVAI v0.2.0 — 评测续接 + 本地评测历史

- 保存工作空间会话、模型绑定、聊天内容和所有 Agent 报告版本（V1/V2/...）。
- 评测后的下一次输入可选择 `continue`，沿用上一次真实 Agent 报告与已确认设计意图，多轮查本地 CAD 证据，输出新报告。
- 原始报告只读不覆盖；后续报告写入版本及来源关联；网页可查看、下载每一版。
- 新增历史列表和一键恢复：包括 0.1.13 的历史 Agent Markdown 报告；旧的未持久化对话不能凭空恢复。
- 本地几何缓存使用原始源文件 SHA256 校验；仅相同模型复用；续评不自动重发四视图。
- 防止同一会话重复并发付费请求，续评前检查报告与模型是否存在。
- 不更换 OpenAI Agents SDK 0.8.4；保持 Python 3.9、CATIA/OCP、Skill 和 Token 账本机制。
- 新增历史/续评离线测试。真实 DeepSeek/CATIA 完整联调仍需用户环境验证。

## CAVAI v0.1.13 — 结构关系图与四视图（2026-11-24）

- 基于真实 B-Rep 面边邻接关系，分组相邻同轴圆柱和共面区域；保留候选孔、同轴几何关系与证据 ID。
- 新增 `get_structure_overview` / `get_structure_feature` / `find_structure_features` 只读工具。
- 新增本地 OCP 三角化四视图；网页预览可在本地打开，不发送原始 CAD 文件。
- DeepSeek 官方已确认支持视觉的型号可以进行一次额外视觉观察、缓存描述并传入 Agent 后续几何工具循环；未知型号不发送图片。
- 继续保留 API 逐笔账本、去重、防循环和用户可选预算；SDK/前次 extra_body 修复未删除。
- 未引入 Benchmark、MCP 或额外 Skill；本地确定性结构图不是机器学习识别出的机械功能。

## CAVAI v0.1.12 ExtraBodyFix · 2026-11-20

- 修复 DeepSeek 配置 `ModelSettings.extra_args['extra_body']` 与 SDK 传参冲突。
- 统一使用 `ModelSettings.extra_body`；新增启动前模型参数校验。
- 新增真实 Agents SDK + HTTPX MockTransport 的零费用集成测试（若环境有 SDK 才执行）。
- 不修改 CATIA/OCP、Skill 内容、界面、模型报告流程、依赖版本及用户配置。
- 尚未运行实际 DeepSeek / Windows CATIA 联调。

## v0.1.12 DependencyFix · 2026-11-20\n\n- 固定 openai==2.44.0，避免旧 Agents SDK 与 2.45+ InputTokensDetails 必填字段冲突。\n- 服务启动前本地执行 Usage() 检查；不通过则停止，避免产生 API 费用。\n- 在无付费请求的 SDK smoke test 中加入 Usage() 回归检查。\n- UI、CATIA/OCP、Skill 和 Agent 工作流维持原版。\n\n## CAVAI_v0.1.12 · 分类Skill补充（保持 0.1.12 版本号）

- 增加紧固件/孔、夹具、制造性三个专用Skill和按需加载参考文件。
- Agent新增`read_skill_reference`与`check_fastener_hole_evidence`工具，结果来自本地几何，不能声称更高级力学或DFM算法已集成。
- 补充开源方法出处和真实复用范围；不新增Benchmark打分服务。
- 继续沿用OpenAI Agents SDK 0.8.4、Python 3.9目标、Token账本及多轮工具调用。

# CAVAI 更新日志

## 0.1.12 — Python 3.9 / OpenAI Agents SDK

1. 正式将 Agent 引擎更换为 **`openai-agents==0.8.4`**，使用其 `Runner.run` 与 `function_tool` 完成多轮工具调用。删除旧 `LangChain/create_agent` 入口和自写 Agent 循环。
2. 保留 CATIA V5 COM、OCP STEP解析、结构化几何查询、所有本地Skill、原聊天网页与Logo。
3. Agent 自主加载 `skills/*/SKILL.md`，调用本地 Python 工具查询真实 CAD 几何，再直接输出 Markdown 工程报告；Python 保存最终 Agent 原文，不暴露 `save_review_report` 函数工具。
4. 将逐笔 Token 日志放到 HTTPX 请求/响应钩子：真实发出前记录，收到 usage 时记录 Input/Output/Cache，402/截断/超时明确终止。
5. 消除重复模型完整上传；多轮评测只发送有限几何摘要，详情经工具分页；完全相同的请求第三次拦截，无用户限制时仍有12次安全上限。
6. 视觉模型仅在单轮用途识别阶段传一张压缩截图，防止多轮不断重复发送图片；不需要图像才能完成评测。
7. 增加 Python 3.9 语法及 HTTP/OCP 离线回归测试和安装后不收费的 SDK smoke test。

**验收边界：** 本地离线闭环是模拟 SDK Runner / API，不代表在用户 Windows CATIA 和 DeepSeek 官方账户真实端到端成功。真实安装和支付服务联调需在相应环境验证。

## CAVAI_v0.1.12 页面/可观察分析轨迹修订
- 评测页文字改为 CATIA 设计评测，顶部显示 CAVAI^_^。
- 可展开的实时 Agent 工具/几何/API 执行步骤（只读本地轮询），不额外产生模型费用。
- Agent 最终报告包含简短的工程判断依据摘要；不开启额外的 DeepSeek thinking 模式。
