$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$python = "python"
if (Test-Path ".venv\Scripts\python.exe") { $python = ".venv\Scripts\python.exe" }
elseif (Test-Path "venv\Scripts\python.exe") { $python = "venv\Scripts\python.exe" }
Write-Host "CAVAI 0.2.0 - OpenAI Agents SDK (Python 3.9 compatible)"
& $python --version
& $python "run.py"
