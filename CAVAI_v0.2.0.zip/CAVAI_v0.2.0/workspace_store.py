"""CAVAI v0.2.0: durable local review workspaces and report history.

All model data stays on disk in this installation. A session binds to exactly one
uploaded CAD file. No cloud storage, no automatic API calls when opening history.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent
UPLOAD_DIR = ROOT / 'data' / 'uploads'
WORKSPACE_DIR = ROOT / 'data' / 'workspaces'
EVIDENCE_DIR = ROOT / 'data' / 'evidence'
REPORT_DIR = ROOT / 'data' / 'reports'
ID_PATTERN = re.compile(r'[0-9a-f]{32}\Z')
CAD_SUFFIXES = {'.catproduct', '.catpart', '.step', '.stp'}
_LOCK = threading.RLock()
_RUNNING = set()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def valid_id(value: Any) -> bool:
    return isinstance(value, str) and bool(ID_PATTERN.fullmatch(value))


def _atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with temp.open('w', encoding='utf-8') as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2, default=str)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(str(temp), str(path))
    finally:
        if temp.exists():
            temp.unlink()


def _read_json(path: Path) -> dict:
    obj = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(obj, dict):
        raise ValueError('本地工作空间文件格式不正确')
    return obj


def _within(path: Path, root: Path) -> bool:
    return path.resolve() != root.resolve() and root.resolve() in path.resolve().parents


def save_upload(upload: dict) -> None:
    ident = upload.get('file_id')
    if not valid_id(ident):
        raise ValueError('无效模型ID')
    path = Path(upload['path'])
    original = Path(upload['original_path'])
    # Respect FastAPI's configured upload directory (also makes isolated test
    # upload roots safe); metadata is always written beside this upload.
    home = original.parent
    if not home.is_dir() or home.name != ident:
        raise FileNotFoundError('上传模型目录不存在')
    if not _within(path, home) or not path.is_file() or not _within(original, home):
        raise ValueError('上传模型路径必须位于本地模型目录')
    payload = {
        'file_id': ident,
        'filename': str(upload.get('filename') or path.name)[:255],
        'primary_rel': str(path.relative_to(home)),
        'original_rel': str(original.relative_to(home)),
        'extension': path.suffix.lower(),
        'size': int(upload.get('size') or path.stat().st_size),
        'extracted_files': list(upload.get('extracted_files') or [])[:100],
        'vision_observations': {
            str(k)[:200]: str(v)[:600]
            for k, v in list((upload.get('vision_observations') or {}).items())[:8]
        },
    }
    with _LOCK:
        _atomic_json(home / 'metadata.json', payload)


def load_upload(file_id: str) -> Optional[dict]:
    if not valid_id(file_id):
        return None
    home = UPLOAD_DIR / file_id
    if not home.is_dir():
        return None
    metadata = home / 'metadata.json'
    try:
        if metadata.is_file():
            info = _read_json(metadata)
            if info.get('file_id') != file_id:
                return None
            path = home / str(info['primary_rel'])
            original = home / str(info['original_rel'])
            if not _within(path, home) or not path.is_file() or not _within(original, home) or not original.is_file():
                return None
        else:
            # Migration for 0.1.13 uploads: metadata was previously RAM-only.
            models = [p for p in home.rglob('*') if p.is_file() and p.suffix.lower() in CAD_SUFFIXES]
            if not models:
                return None
            models.sort(key=lambda p: (p.suffix.lower() != '.catproduct', len(p.parts), p.name.lower()))
            path = models[0]
            top = [p for p in home.iterdir() if p.is_file()]
            original = next((p for p in top if p.suffix.lower() == '.zip'), path)
            info = {'file_id': file_id, 'filename': original.name, 'size': original.stat().st_size,
                    'extension': path.suffix.lower(), 'extracted_files': [], 'vision_observations': {}}
        upload = {
            'file_id': file_id, 'filename': str(info.get('filename') or path.name),
            'path': str(path), 'original_path': str(original),
            'extension': path.suffix.lower(), 'size': int(info.get('size') or original.stat().st_size),
            'extracted_files': list(info.get('extracted_files') or []),
            'vision_observations': dict(info.get('vision_observations') or {}),
        }
        view_path = home / 'cad_view_preview.jpg'
        if view_path.is_file():
            upload['view_path'] = str(view_path)
        # Images are stored with the original upload. Do not follow paths
        # embedded in old evidence snapshots if a data folder was moved.
        candidates = list(path.parent.glob('*_four_views.jpg'))
        if not candidates:
            candidates = list(home.rglob('*_four_views.jpg'))
        if candidates:
            upload['auto_view_path'] = str(candidates[0])
        if not metadata.exists():
            save_upload(upload)
        return upload
    except (OSError, KeyError, ValueError, TypeError, json.JSONDecodeError):
        return None


def load_cached_inspection(upload: dict) -> Optional[dict]:
    """Use 0.1.13's existing evidence cache only for an unchanged CAD file."""
    ident = upload.get('file_id')
    if not valid_id(ident):
        return None
    file = EVIDENCE_DIR / (ident + '.json')
    if not file.is_file():
        return None
    try:
        payload = _read_json(file)
        if payload.get('file_id') != ident:
            return None
        file_hash = hashlib.sha256(Path(upload['path']).read_bytes()).hexdigest()
        if payload.get('source_sha256') != file_hash:
            return None
        inspection = payload.get('inspection')
        if isinstance(inspection, dict):
            upload['evidence_path'] = str(file)
            return inspection
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        pass
    return None


def _workspace_path(session_id: str) -> Path:
    if not valid_id(session_id):
        raise ValueError('无效会话ID')
    return WORKSPACE_DIR / (session_id + '.json')


def load_workspace(session_id: str) -> Optional[dict]:
    if not valid_id(session_id):
        return None
    path = _workspace_path(session_id)
    if not path.is_file():
        return None
    try:
        result = _read_json(path)
        if result.get('session_id') != session_id:
            return None
        return result
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None


def create_workspace(file_id: str, filename: str) -> dict:
    if not valid_id(file_id):
        raise ValueError('必须绑定已经上传的模型')
    ident = uuid.uuid4().hex
    timestamp = utc_now()
    result = {
        'schema_version': 'cavai-workspace-0.2.0',
        'session_id': ident, 'file_id': file_id,
        'filename': str(filename or 'CAD 模型')[:255], 'title': str(filename or 'CAD 模型')[:90],
        'created_at': timestamp, 'updated_at': timestamp,
        'messages': [], 'reports': [], 'current_report_id': None,
    }
    with _LOCK:
        _atomic_json(_workspace_path(ident), result)
    return result


def save_turn(session_id: str, mode: str, user_text: str, result: dict,
              expected_version: int = 0, parent_report_id: Optional[str] = None) -> dict:
    """Persist review messages and version metadata after the Agent returns."""
    with _LOCK:
        item = load_workspace(session_id)
        if item is None:
            raise ValueError('工作空间不存在')
        now = utc_now()
        report_id = result.get('report_id')
        item['messages'].extend([
            {'role': 'user', 'content': str(user_text)[:4000], 'mode': mode, 'at': now},
            {'role': 'assistant', 'content': str(result.get('reply') or '')[:22000],
             'mode': mode, 'at': now, 'report_id': report_id,
             'status': (result.get('usage') or {}).get('status')},
        ])
        # Long local transcript is okay; the cloud prompt remains bounded.
        item['messages'] = item['messages'][-100:]
        if report_id and valid_id(report_id):
            if any(record.get('report_id') == report_id for record in item['reports']):
                raise ValueError('报告已保存到历史，拒绝重复追加')
            current_version = len(item['reports']) + 1
            if expected_version and expected_version != current_version:
                raise ValueError('报告版本冲突，请刷新历史')
            item['reports'].append({
                'report_id': report_id, 'version': current_version, 'created_at': now,
                'report_status': (result.get('report') or {}).get('report_status', 'completed'),
                'source': 'agent_llm_output', 'based_on_report_id': parent_report_id,
                'user_instruction': str(user_text)[:4000],
                'model_id': (result.get('report') or {}).get('model_id', ''),
            })
            item['current_report_id'] = report_id
        item['updated_at'] = now
        _atomic_json(_workspace_path(session_id), item)
        return item


def begin_session_run(session_id: str) -> bool:
    with _LOCK:
        if session_id in _RUNNING:
            return False
        _RUNNING.add(session_id)
        return True


def end_session_run(session_id: str) -> None:
    with _LOCK:
        _RUNNING.discard(session_id)


def _import_existing_reports() -> None:
    """Make existing 0.1.13 saved reports visible when a user copies data/.

    No API calls, no re-generated LLM text, no dependence on old ephemeral RAM IDs.
    """
    with _LOCK:
        known_ids = set()
        by_file = {}
        if WORKSPACE_DIR.is_dir():
            for path in WORKSPACE_DIR.glob('*.json'):
                ws = load_workspace(path.stem)
                if not ws:
                    continue
                for r in ws.get('reports') or []:
                    known_ids.add(r.get('report_id'))
                if ws.get('file_id'):
                    by_file.setdefault(ws['file_id'], ws['session_id'])
        if not REPORT_DIR.is_dir():
            return
        orphan = []
        for path in REPORT_DIR.glob('*.json'):
            if not valid_id(path.stem) or path.stem in known_ids:
                continue
            try:
                report = _read_json(path)
                file_id = report.get('model_file_id')
                if not valid_id(file_id) or report.get('report_source') != 'agent_llm_output':
                    continue
                if not (UPLOAD_DIR / file_id).is_dir():
                    continue
                orphan.append((report.get('created_at') or '', path.stem, report))
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                continue
        for _, rid, report in sorted(orphan):
            file_id = report['model_file_id']
            session_id = report.get('session_id')
            if not valid_id(session_id) or load_workspace(session_id) is None:
                session_id = by_file.get(file_id)
            session = load_workspace(session_id) if session_id else None
            if not session:
                session = create_workspace(file_id, str(report.get('model_filename') or 'CAD 模型'))
            by_file[file_id] = session['session_id']
            if any(r['report_id'] == rid for r in session['reports']):
                continue
            session['reports'].append({
                'report_id': rid, 'version': len(session['reports']) + 1,
                'created_at': report.get('created_at') or utc_now(),
                'report_status': report.get('report_status') or 'completed',
                'source': 'agent_llm_output', 'based_on_report_id': report.get('based_on_report_id'),
                'user_instruction': str(report.get('user_instruction') or ''),
                'model_id': str(report.get('model_id') or ''),
            })
            session['current_report_id'] = rid
            session['updated_at'] = max(session.get('updated_at') or '', report.get('created_at') or '')
            # Legacy report content remains the original Agent output, not rewritten.
            session['messages'].extend([
                {'role': 'assistant', 'content': str(report.get('markdown_report') or '')[:22000],
                 'mode': 'review', 'report_id': rid,
                 'at': report.get('created_at') or utc_now(), 'status': 'completed'},
            ])
            _atomic_json(_workspace_path(session['session_id']), session)


def list_workspaces(limit: int = 100) -> list:
    _import_existing_reports()
    items = []
    if not WORKSPACE_DIR.is_dir():
        return items
    for path in WORKSPACE_DIR.glob('*.json'):
        ws = load_workspace(path.stem)
        if not ws:
            continue
        items.append({k: ws.get(k) for k in (
            'session_id', 'file_id', 'filename', 'title', 'created_at', 'updated_at', 'current_report_id')})
        items[-1]['report_count'] = len(ws.get('reports') or [])
        items[-1]['message_count'] = len(ws.get('messages') or [])
        items[-1]['model_available'] = load_upload(str(ws.get('file_id') or '')) is not None
    items.sort(key=lambda x: x.get('updated_at') or '', reverse=True)
    return items[:max(1, min(int(limit), 200))]


def get_workspace(session_id: str) -> Optional[dict]:
    _import_existing_reports()
    return load_workspace(session_id)


def concise_report_context(session: dict) -> dict:
    """Pass only a bounded summary of earlier report and user updates to next Agent run."""
    report_id = session.get('current_report_id')
    if not valid_id(report_id):
        return {}
    try:
        report = _read_json(REPORT_DIR / (report_id + '.json'))
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return {}
    text = str(report.get('markdown_report') or '')
    if len(text) > 4600:
        text = text[:3400] + '\n……[原报告剩余内容保存在本地，可从评测历史查看]\n' + text[-650:]
    return {
        'report_id': report_id,
        'report_version': len(session.get('reports') or []),
        'prior_markdown_excerpt': text,
        'confirmed_user_updates': [
            str(message.get('content') or '')[:450]
            for message in (session.get('messages') or []) if message.get('role') == 'user'
        ][-8:],
    }


def load_report(report_id: str) -> dict:
    if not valid_id(report_id):
        raise ValueError('无效报告ID')
    path = REPORT_DIR / (report_id + '.json')
    if not path.is_file():
        raise FileNotFoundError('报告不存在')
    return _read_json(path)


def annotate_report(report_id: str, session_id: str, version: int,
                    parent_report_id: Optional[str], instruction: str, mode: str) -> None:
    """Add local version metadata to a genuine model-produced report; never rewrite Markdown."""
    with _LOCK:
        payload = load_report(report_id)
        payload['session_id'] = session_id
        payload['report_version'] = int(version)
        payload['based_on_report_id'] = parent_report_id
        payload['user_instruction'] = str(instruction)[:4000]
        payload['review_mode'] = mode
        _atomic_json(REPORT_DIR / (report_id + '.json'), payload)
