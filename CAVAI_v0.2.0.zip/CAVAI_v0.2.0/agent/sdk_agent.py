"""CAVAI 0.2.0: OpenAI Agents SDK 0.8.4 / Python 3.9 Agent.

SDK Runner owns the LLM/tool loop. CAVAI only supplies local CAD tools, request
metering (HTTPX hooks), local report persistence and a finite safety ceiling.
The model's final text is the report; there is no save_review_report tool.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import math
import threading
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import urlsplit

from agent.model_context import (summarize_model, geometry_page, geometry_lookup,
                                 geometry_search, structure_feature_query)
from agent.model_capabilities import detect_model_capabilities
from agent import live_progress
from agent.usage_ledger import record, scrub
from reports.agent_report import save_agent_markdown
from settings_store import get_llm_settings
from skills.registry import (list_skills, load_skill as registry_load_skill,
                             read_skill_reference as registry_read_skill_reference)


MAX_HARD_REQUESTS = 12  # Emergency loop breaker even when user disables custom budgets.
MAX_LOCAL_TOOL_CALLS = 24
MODEL_MAX_OUTPUT_TOKENS = 2800


class RequestBudgetError(RuntimeError):
    pass


class RepeatedRequestError(RuntimeError):
    pass


class OutputCutoffError(RuntimeError):
    pass


def _json_small(value: Any, cap: int = 3000) -> str:
    """Return valid JSON; never replace a malformed/long argument with {}."""
    raw = json.dumps(value, ensure_ascii=False, separators=(',', ':'), default=str)
    if len(raw) <= cap:
        return raw
    if isinstance(value, dict):
        compact = {}
        for key, item in value.items():
            if isinstance(item, list):
                compact[key] = item[:2]
            elif isinstance(item, str):
                compact[key] = item[:140]
            else:
                compact[key] = item
        raw = json.dumps(compact, ensure_ascii=False, separators=(',', ':'), default=str)
        if len(raw) <= cap:
            return raw
    return json.dumps({'result_too_large': True,
                       'preview': raw[:max(100, cap - 160)],
                       'instruction': '请按实体ID或分页查询。'}, ensure_ascii=False)


def _is_provider_request(request: Any) -> bool:
    return str(request.url.path).rstrip('/').endswith('/chat/completions')


class HttpUsageMeter:
    """Audit each actual HTTP API attempt, including 402 and unknown usage.

    Event hooks run inside AsyncOpenAI's HTTPX client, not in a hand-written
    agent/model loop. The SDK and HTTPX clients have retries disabled.
    """
    def __init__(self, cfg: dict, run_id: str, stage: str):
        self.cfg = cfg
        self.run_id = run_id
        self.stage = stage
        self.attempts = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self.cached_tokens = 0
        self.known_usage_calls = 0
        self.unknown_cost_requests = 0
        self.estimated_reserved = 0
        self.pending: Dict[str, dict] = {}
        self.digests: Dict[str, int] = {}
        self.request_ids: List[str] = []
        self.hard_max = min(MAX_HARD_REQUESTS, int(cfg.get('max_requests', 8))) if cfg.get('limits_enabled') else MAX_HARD_REQUESTS
        record({'event': 'turn_started', 'turn_id': run_id, 'stage': stage,
                'model': cfg.get('model'), 'limits_enabled': bool(cfg.get('limits_enabled')),
                'max_requests': cfg.get('max_requests') if cfg.get('limits_enabled') else None,
                'hard_safety_limit': self.hard_max})

    async def on_request(self, request: Any) -> None:
        if not _is_provider_request(request):
            return
        payload = request.content
        digest = hashlib.sha256(payload).hexdigest()
        repeated = self.digests.get(digest, 0)
        estimated_input = max(1, math.ceil(len(payload) / 3.0))
        try:
            parsed = json.loads(payload)
            reserve_output = int(parsed.get('max_tokens') or parsed.get('max_completion_tokens') or MODEL_MAX_OUTPUT_TOKENS)
        except (ValueError, TypeError):
            reserve_output = MODEL_MAX_OUTPUT_TOKENS
        reserve_output = max(0, min(reserve_output, 12000))
        reason = None
        if self.attempts >= self.hard_max:
            reason = '达到API请求安全上限，已在实际发送前停止。'
        elif repeated >= 2:
            reason = '检测到完全相同的请求已发送两次，为防止死循环，停止本轮。'
        elif self.cfg.get('limits_enabled') and (self.estimated_reserved + estimated_input + reserve_output > int(self.cfg.get('max_turn_est_tokens', 30000))):
            reason = '预计本轮Token超过你设置的上限，本次请求未发送。'
        if reason:
            record({'event': 'budget_blocked', 'turn_id': self.run_id, 'stage': self.stage,
                    'reason': reason, 'estimated_input_tokens': estimated_input,
                    'repeated_payload': repeated >= 2})
            raise RepeatedRequestError(reason) if repeated >= 2 else RequestBudgetError(reason)

        ident = uuid.uuid4().hex[:16]
        request.extensions['cavai_meter_request_id'] = ident
        self.pending[ident] = {'estimate': estimated_input, 'payload_digest': digest}
        self.request_ids.append(ident)
        self.digests[digest] = repeated + 1
        self.attempts += 1
        self.estimated_reserved += estimated_input + reserve_output
        live_progress.event(self.run_id, 'api', '向所选模型发送第{}次请求'.format(self.attempts),
                            '本轮请求约{} KB；完整CAD文件没有发送'.format(round(len(payload) / 1024, 1)))
        record({'event': 'api_request_started', 'turn_id': self.run_id, 'request_id': ident,
                'stage': self.stage, 'round': self.attempts,
                'model': self.cfg.get('model'), 'endpoint': 'chat/completions',
                'request_bytes': len(payload), 'estimated_input_tokens': estimated_input,
                'max_output_tokens': reserve_output,
                'repeated_request_count': repeated + 1,
                'note': '请求体仅记录大小和摘要，不存储Key、几何原文或模型回复。'})

    async def on_response(self, response: Any) -> None:
        if not _is_provider_request(response.request):
            return
        ident = response.request.extensions.get('cavai_meter_request_id')
        if not ident:
            return
        self.pending.pop(ident, None)
        raw = await response.aread()
        data = {}
        try:
            parsed = json.loads(raw)
            data = parsed if isinstance(parsed, dict) else {}
        except (ValueError, UnicodeDecodeError):
            pass
        status = response.status_code
        if status >= 400:
            self.unknown_cost_requests += 1
            live_progress.event(self.run_id, 'error', '模型接口返回 HTTP {}'.format(status),
                                '请求已停止或失败；请查看本地Token账本')
            err = data.get('error') if isinstance(data.get('error'), dict) else {}
            record({'event': 'api_request_failed', 'turn_id': self.run_id,
                    'request_id': ident, 'stage': self.stage, 'http_status': status,
                    'error_code': str(err.get('code') or '')[:80],
                    'error_type': str(err.get('type') or '')[:80],
                    'billing_status': '未知，请以服务商账单为准'})
            return
        usage = data.get('usage') if isinstance(data.get('usage'), dict) else {}
        prompt = usage.get('prompt_tokens', usage.get('input_tokens'))
        output = usage.get('completion_tokens', usage.get('output_tokens'))
        details = usage.get('prompt_tokens_details') or {}
        cache = (usage.get('prompt_cache_hit_tokens') or
                 (details.get('cached_tokens') if isinstance(details, dict) else None))
        choice = (data.get('choices') or [{}])[0]
        finish = choice.get('finish_reason') if isinstance(choice, dict) else None
        if isinstance(prompt, int):
            self.prompt_tokens += prompt
        if isinstance(output, int):
            self.completion_tokens += output
        if isinstance(cache, int):
            self.cached_tokens += cache
        if not isinstance(prompt, int) or not isinstance(output, int):
            self.unknown_cost_requests += 1
        else:
            self.known_usage_calls += 1
        record({'event': 'api_request_completed', 'turn_id': self.run_id,
                'request_id': ident, 'stage': self.stage,
                'prompt_tokens': prompt if isinstance(prompt, int) else None,
                'completion_tokens': output if isinstance(output, int) else None,
                'cached_input_tokens': cache if isinstance(cache, int) else None,
                'finish_reason': finish, 'provider_request_id': str(data.get('id') or '')[:100],
                'billing_status': 'API返回的Token用量，具体金额以服务商为准'})
        live_progress.event(self.run_id, 'api', '模型请求已返回',
                            '输入{} / 输出{} Token；状态{}'.format(
                                prompt if isinstance(prompt, int) else '?',
                                output if isinstance(output, int) else '?', finish or '未知'))
        if finish == 'length':
            # Never resubmit a truncated tool-call JSON object and spend another 25 rounds.
            raise OutputCutoffError('模型输出达到上限，停止本次评测；不会将残缺工具参数转换为{}或自动重试。')

    def finish(self, status: str, trace: Optional[list] = None, error: str = '') -> dict:
        # Network timeouts may have reached the provider even if no response was seen.
        for ident in list(self.pending):
            self.unknown_cost_requests += 1
            record({'event': 'api_request_failed', 'turn_id': self.run_id, 'request_id': ident,
                    'stage': self.stage, 'error_type': 'network_or_interrupted',
                    'billing_status': '状态未知，可能已计费'})
            self.pending.pop(ident, None)
        usage = {'turn_id': self.run_id, 'status': status, 'calls': self.attempts,
                 'prompt_tokens': self.prompt_tokens, 'completion_tokens': self.completion_tokens,
                 'cached_input_tokens': self.cached_tokens,
                 'known_usage_calls': self.known_usage_calls,
                 'unknown_cost_requests': self.unknown_cost_requests,
                 'estimated_cost_cny': None, 'request_ids': self.request_ids}
        record({'event': 'turn_finished', **usage,
                'message': scrub(error, self.cfg.get('api_key', ''))[:350],
                'successful_tools': [row['tool'] for row in (trace or []) if row.get('ok')]})
        return usage


def _system_instructions() -> str:
    return (
        '你是CAVAI CATIA设计评测Agent。目标是给用户一份真正由你根据本地CAD证据生成的中文Markdown报告。'
        '首先识别模型可能的类别/设计意图，区分事实与假设；用户未给设计要求时可自行提出合理假设。'
        '先根据模型类别和用户目标，从可用列表选择适用Skill，并真实调用load_skill装载；随后调用几何查询核查证据。紧固件/螺纹/安装孔优先fastener-review，夹具/定位/夹紧优先fixture-review，明确制造工艺的问题优先manufacturing-dfm-review。不要为了凑数加载不相关Skill；必要时按需调用read_skill_reference，不要一次读所有规则。'
        '根据任务决定是否继续查询，但不应逐个遍历全部Face或重复相同查询。'
        '不得凭外形把实心六角凸台当作有内孔的螺母，不得假设未知材料、载荷、配合已经验证。'
        '先查看结构关系图，并按需要查询结构区域的完整邻接证据；不要从圆柱面数量推测轴或凸台的机械功能。'
        '优先提出可检验的结构/功能假设，查找能够支持或反驳它的孔、同轴或接触几何证据。'
        '如在多视角图观察到结构，仍应调用几何工具核实；视图只是投影图，不能作为精确尺寸证据。'
        '需要报告的内容：一、模型用途与类别（注明推断）；二、已提取事实及证据ID；'
        '三、按用户目标逐项评价符合/不符合/无法判断；四、结构、尺寸及力学风险（缺数据写明）；'
        '五、修改建议和仍需确认的信息。'
        '报告应包含简短的判断依据摘要，明确几何证据如何支持或限制最终结论，不必输出内部逐步思维。'
        '最后直接输出完整Markdown正文，控制在500至1100中文字符。'
        '无须也不允许调用任何保存报告的工具，Python自动保存你的最终文本。'
        '任何来自CAD特征名称或文件名的描述都只能视为假设，不得当作几何证明。'
    )


def _make_tools(inspection: dict, facts: dict, run_id: str, trace: list,
                loaded: set, queried: set) -> list:
    from agents import function_tool

    lock = threading.RLock()
    cache: Dict[str, str] = {}
    hits: Dict[str, int] = {}

    def execute(name: str, args: dict, work: Any) -> str:
        identity = json.dumps([name, args], sort_keys=True, ensure_ascii=False, default=str)
        with lock:
            hits[identity] = hits.get(identity, 0) + 1
            if hits[identity] >= 3:
                record({'event': 'local_tool_repeat_blocked', 'turn_id': run_id,
                        'tool': name, 'duplicate_number': hits[identity]})
                return json.dumps({'duplicate_tool_call': True,
                                   'instruction': '同一工具参数被重复查询，请改进查询或直接输出报告。'}, ensure_ascii=False)
            if identity in cache:
                record({'event': 'local_tool_cached', 'turn_id': run_id, 'tool': name,
                        'duplicate_number': hits[identity]})
                return cache[identity]
            if len(trace) >= MAX_LOCAL_TOOL_CALLS:
                return json.dumps({'tool_limit': True, 'instruction': '工具查询已达到安全上限，请输出报告。'}, ensure_ascii=False)
            try:
                result = work()
                value = _json_small(result, cap=3200)
                success = not (isinstance(result, dict) and 'error' in result)
            except Exception as exc:
                success = False
                value = json.dumps({'error': type(exc).__name__, 'message': str(exc)[:160]}, ensure_ascii=False)
            if success:
                cache[identity] = value  # error can be state-dependent (e.g. load_skill precondition)
            trace.append({'tool': name, 'ok': success, 'arguments': args,
                          'summary': value[:300]})
            detail = (('参数: ' + _json_small(args, cap=110)) if args else '使用当前模型')
            detail += ' · 结果: ' + value[:105]
            live_progress.event(run_id, 'tool',
                                ('完成 ' if success else '失败 ') + name, detail)
            record({'event': 'local_tool_executed', 'turn_id': run_id, 'tool': name,
                    'ok': success, 'argument_keys': sorted(args),
                    'result_length': len(value)})
            return value

    @function_tool
    def list_available_skills() -> str:
        """列出当前电脑安装的可用工程评测Skill及用途。"""
        return execute('list_available_skills', {}, lambda: list_skills()[:15])

    @function_tool
    def load_skill(skill_name: str) -> str:
        """从CAVAI本地skills目录加载指定Skill的工程评测方法；需先加载再按需检查几何。"""
        def work():
            selected = registry_load_skill(skill_name)
            loaded.add(selected['name'])
            return {'name': selected['name'], 'instructions': selected['content'][:2100],
                    'references_available': selected.get('reference_paths', [])}
        return execute('load_skill', {'skill_name': skill_name}, work)

    @function_tool
    def read_skill_reference(skill_name: str, reference_path: str) -> str:
        """只按需加载已启用Skill的references目录内一份Markdown规则，例如checklist.md，不允许访问其他本地路径。"""
        def work():
            if skill_name not in loaded:
                return {'error': '请先调用load_skill加载本Skill，再按需读取其references文件。'}
            reference = registry_read_skill_reference(skill_name, reference_path)
            content = reference['content']
            return {'skill_name': skill_name, 'reference_path': reference_path,
                    'content': content[:2300], 'truncated': len(content) > 2300}
        return execute('read_skill_reference', {'skill_name': skill_name,
                                                'reference_path': reference_path}, work)

    @function_tool
    def check_fastener_hole_evidence() -> str:
        """针对疑似紧固结构，依据真实B-Rep返回内外圆柱面、孔候选和可查询ID；不是螺纹或强度合格判定。"""
        def work():
            geometry = (inspection or {}).get('geometry') or {}
            if geometry.get('status') != 'ok':
                return {'error': 'B-Rep几何尚未成功解析。'}
            faces = [face for face in (geometry.get('faces') or []) if isinstance(face, dict)]
            inner = [face for face in faces if face.get('surface_type') == 'cylinder'
                     and face.get('cylindrical_side') == 'inner']
            outer = [face for face in faces if face.get('surface_type') == 'cylinder'
                     and face.get('cylindrical_side') == 'outer']
            candidates = [hole for hole in (geometry.get('hole_candidates') or []) if isinstance(hole, dict)]
            counts = geometry.get('cylindrical_face_counts') or {}
            queried.add('FASTENER-HOLE-EVIDENCE')
            return {
                'evidence_id': 'FASTENER-HOLE-EVIDENCE',
                'solid_count': geometry.get('solid_count'),
                'inner_cylindrical_faces': counts.get('inner', len(inner)),
                'outer_cylindrical_faces': counts.get('outer', len(outer)),
                'hole_candidate_count': geometry.get('hole_candidate_count', len(candidates)),
                'inner_face_sample_ids': [f.get('face_id') for f in inner[:6]],
                'outer_face_sample_ids': [f.get('face_id') for f in outer[:6]],
                'hole_candidate_sample_ids': [h.get('candidate_id') for h in candidates[:6]],
                'limitations': ('这只是对当前B-Rep内外圆柱面和常规孔候选的统计；'
                                '没有检测到候选不等于所有形式的孔都不存在；'
                                '不能据此外推螺纹、配合、载荷或装配成立。')
            }
        return execute('check_fastener_hole_evidence', {}, work)

    @function_tool
    def get_current_model_facts() -> str:
        """读取当前模型经过CATIA/OCP解析的真实实体、面、边、孔等几何摘要。"""
        def work():
            queried.add('BREP-SUMMARY')
            keys = ('filename', 'inspection_status', 'geometry_status', 'solid_count',
                    'face_count', 'edge_count', 'bounding_box_mm', 'hole_candidate_count',
                    'cylindrical_face_counts', 'catia_body_count', 'face_type_counts',
                    'geometry_limitations', 'auto_preview_available')
            return {key: facts[key] for key in keys if key in facts}
        return execute('get_current_model_facts', {}, work)

    @function_tool
    def search_model_geometry(kind: str, surface_type: str = '',
                              cylindrical_side: str = '', radius_mm: float = -1.0,
                              start: int = 0, limit: int = 5) -> str:
        """本地按面类型、内外圆柱、半径搜索CAD几何，支持分页返回真实实体ID。kind为faces/edges/solids/hole_candidates。"""
        args = dict(kind=kind, surface_type=surface_type, cylindrical_side=cylindrical_side,
                    radius_mm=radius_mm, start=start, limit=limit)
        def work():
            result = geometry_search(inspection, kind, surface_type=surface_type,
                                     cylindrical_side=cylindrical_side,
                                     radius_mm=None if radius_mm < 0 else radius_mm,
                                     start=start, limit=limit)
            if 'error' not in result:
                queried.add('BREP-SEARCH')
            return result
        return execute('search_model_geometry', args, work)

    @function_tool
    def get_geometry_entity_by_id(entity_id: str) -> str:
        """根据几何实体ID查询精确面/边/实体/孔候选的详细局部证据。"""
        def work():
            result = geometry_lookup(inspection, entity_id)
            if 'error' not in result:
                queried.add(entity_id)
            return result
        return execute('get_geometry_entity_by_id', {'entity_id': entity_id}, work)

    @function_tool
    def get_model_geometry_page(kind: str, start: int = 0, limit: int = 5) -> str:
        """分页读取本机CAD几何：faces/edges/solids/hole_candidates，每次至多8条。"""
        def work():
            result = geometry_page(inspection, kind, start, limit)
            if 'error' not in result:
                queried.add('BREP-PAGE-' + kind)
            return result
        return execute('get_model_geometry_page', {'kind': kind, 'start': start, 'limit': limit}, work)

    @function_tool
    def get_structure_overview() -> str:
        """读取按真实B-Rep邻接关系分组的机械几何结构概览，不直接推断机械功能。"""
        def work():
            from cad.feature_graph import brief_feature_graph
            result = brief_feature_graph((inspection or {}).get('geometry') or {},
                                         max_features=12, max_relations=10)
            if result.get('status') == 'ok':
                queried.add('BREP-STRUCTURE-GRAPH')
            return result
        return execute('get_structure_overview', {}, work)

    @function_tool
    def get_structure_feature(feature_id: str) -> str:
        """按CY-0001、PL-0001或HO-0001等结构ID查询关联的面、边及邻接/同轴证据。"""
        def work():
            result = structure_feature_query(inspection, feature_id=feature_id)
            if 'error' not in result:
                queried.add(feature_id)
            return result
        return execute('get_structure_feature', {'feature_id': feature_id}, work)

    @function_tool
    def find_structure_features(kind: str = '', start: int = 0, limit: int = 5) -> str:
        """按圆柱几何区域cylindrical_region、平面区域planar_region或hole_topology_candidate分页搜索结构。"""
        def work():
            result = structure_feature_query(inspection, kind=kind, start=start, limit=limit)
            if 'error' not in result:
                queried.add('BREP-FEATURE-SEARCH')
            return result
        return execute('find_structure_features', {'kind': kind, 'start': start, 'limit': limit}, work)

    return [list_available_skills, load_skill, read_skill_reference,
            get_structure_overview, get_structure_feature, find_structure_features,
            check_fastener_hole_evidence, get_current_model_facts,
            search_model_geometry, get_geometry_entity_by_id, get_model_geometry_page]


def _local_block(reason: str, run_id: str) -> dict:
    record({'event': 'local_review_blocked', 'turn_id': run_id, 'reason': reason})
    return {'reply': reason, 'provider': 'local_geometry_block', 'tool_trace': [],
            'loaded_skills': [], 'report': None, 'report_id': None,
            'report_download_url': None, 'turn_id': run_id,
            'usage': {'calls': 0, 'prompt_tokens': 0, 'completion_tokens': 0,
                      'estimated_cost_cny': None}}


def _safe_error(error: Exception, settings: dict) -> str:
    detail = scrub(str(error), settings.get('api_key', ''))
    low = detail.lower()
    if 'insufficient_quota' in low or '402' in low:
        return 'API余额不足（402），已停止本次Agent；此前请求仍可能已经计费。'
    if '401' in low or 'authentication' in low:
        return 'API身份验证失败（401），请检查API Key。'
    if 'maxturns' in type(error).__name__.lower():
        return 'Agent达到安全调用次数上限而未输出最终报告；已停止，未自动发起新的请求。'
    return type(error).__name__ + ': ' + detail[:240]


def _create_input(message: str, facts: dict, history: list, catalog: list,
                  report_context: Optional[dict] = None) -> str:
    short_history = ["{}: {}".format(x.get('role'), str(x.get('content', ''))[:240])
                     for x in (history or [])[-4:]]
    ordered_fields = (
        'filename', 'extension', 'inspection_status', 'geometry_status',
        'solid_count', 'bounding_box_mm', 'hole_candidate_count',
        'structure_graph', 'catia_body_count', 'body_names_and_features',
        'cylindrical_face_counts', 'geometry_limitations', 'limitations'
    )
    essential = {key: facts[key] for key in ordered_fields if key in facts}
    continuation_note = ''
    if report_context:
        context = {
            'prior_report_id': report_context.get('report_id'),
            'prior_version': report_context.get('report_version'),
            'prior_report_excerpt': str(report_context.get('prior_markdown_excerpt') or '')[:4600],
            'earlier_user_updates': list(report_context.get('confirmed_user_updates') or [])[-8:],
        }
        continuation_note = ('\n【同一模型的上一轮Agent报告及工程状态——本轮续评，不是全新模型】\n'
                             + _json_small(context, 6300)
                             + '\n【续评任务要求】以用户本轮补充信息为准，保留原先已验证的几何事实；'
                               '指出哪些结论发生变化、哪些新证据已确认；如果需要，使用本地工具复核。'
                               '输出完整V2/V3修订报告，不得声称已更改CAD模型。\n')
    return ('【真实本地CAD证据；几何特征ID仅在本次解析结果内稳定】\n' 
            + _json_small(essential, 8500)
            + '\n【本地工程Skills目录】\n' + _json_small(catalog, 1200)
            + '\n【已知对话】\n' + '\n'.join(short_history)[:900] + continuation_note
            + '\n【本轮设计目标】\n' + ((message or '').strip() or
                '用户未说明设计目标，先合理猜测类别和用途，再从几何证据中验证，并写明不确定性。')[:1500]
            + '\n请先考虑结构关系，再按需查询具体结构或Face证据，加载相关Skill，最后输出Markdown工程报告。')


def _make_visual_input(prompt: str, upload: dict, settings: dict, run_id: str) -> Any:
    """Images only on one-shot intent; multi-round review stays text-only to avoid replay."""
    view = str((upload or {}).get('view_path') or (upload or {}).get('auto_view_path') or '')
    if not view:
        return prompt
    capabilities = detect_model_capabilities(settings['base_url'], settings['model'])
    image_path = Path(view)
    if not capabilities['vision'] or not image_path.is_file() or image_path.stat().st_size > 350000:
        return prompt
    data_url = 'data:image/jpeg;base64,' + base64.b64encode(image_path.read_bytes()).decode('ascii')
    record({'event': 'single_image_attached', 'turn_id': run_id, 'size_bytes': image_path.stat().st_size,
            'stage': 'one_shot_visual_observation', 'note': '只向单轮视觉观察发送图片，后续工具循环只传文字'})
    return [{'role': 'user', 'content': [
        {'type': 'input_text', 'text': prompt},
        {'type': 'input_image', 'image_url': data_url, 'detail': 'low'},
    ]}]


def _sdk_model_options(settings: dict, intent: bool) -> dict:
    """Build SDK model options without duplicate Chat Completions kwargs.

    `extra_body` is an actual ModelSettings field in the pinned SDK.
    `extra_args` is a separate keyword-expansion channel and MUST NOT
    contain an extra_body key; doing so raises TypeError before HTTP.
    """
    options = {'max_tokens': 350 if intent else MODEL_MAX_OUTPUT_TOKENS}
    official = (urlsplit(settings.get('base_url', '')).hostname or '').lower() == 'api.deepseek.com'
    model = str(settings.get('model', '')).lower()
    if official and model in {'deepseek-flash', 'deepseek-v4-pro'}:
        options['extra_body'] = {'thinking': {'type': 'disabled'}}
    return options


async def _run_sdk(*, intent: bool, message: str, history: list,
                   upload: dict, inspection: dict, settings: dict,
                   report_context: Optional[dict] = None,
                   meter: HttpUsageMeter, trace: list, loaded: set, queried: set) -> str:
    """Call genuine SDK Runner, not an application-owned agent loop."""
    import httpx
    from openai import AsyncOpenAI
    from agents import Agent, Runner, RunConfig, ModelSettings, set_tracing_disabled
    from agents.models.openai_chatcompletions import OpenAIChatCompletionsModel

    set_tracing_disabled(True)  # Never send tracing or model data to OpenAI.
    facts = summarize_model(upload, inspection)
    catalog = [{'name': item.get('name'), 'description': str(item.get('description', ''))[:95]}
               for item in list_skills()][:12]
    prompt = _create_input(message, facts, history, catalog, report_context=report_context)
    live_progress.event(meter.run_id, 'agent',
                        '开始识别用途' if intent else 'Agent 开始选择 Skill 与查询证据',
                        '已准备本地几何摘要及工具列表；不发送原始模型')
    if intent:
        prompt = ('根据本地真实CAD几何，120字以内推断模型类别、可能用途，并列出需要用户确认的假设。'
                  '不准把没有孔的实心凸台认成真实螺母。\n' + prompt[:5700])
        input_data = _make_visual_input(prompt, upload, settings, meter.run_id)
        instructions = ('你是CAVAI工程模型用途识别助手。区分观察与推断，只用简明中文。'
                        '此阶段只输出候选用途供用户补充，不进行正式工程评测。')
        tools = []
        max_turns = 1
    else:
        input_data = prompt  # Multi-round image replay would waste tokens; keep B-Rep text.
        instructions = _system_instructions()
        if report_context:
            instructions += ('这是同一个CAD模型的后续评测。阅读先前报告以及用户最新补充，'
                             '明确列出修正的结论、维持的结论和新增发现。'
                             '可复用已保存证据；只对本轮争议或未知问题补充查询，'
                             '不要为了重复上一轮而重新遍历全部几何。')
        tools = _make_tools(inspection, facts, meter.run_id, trace, loaded, queried)
        max_turns = meter.hard_max

    async with httpx.AsyncClient(timeout=60.0, follow_redirects=False,
                                event_hooks={'request': [meter.on_request],
                                             'response': [meter.on_response]}) as http_client:
        async with AsyncOpenAI(api_key=settings['api_key'], base_url=settings['base_url'],
                               http_client=http_client, max_retries=0, timeout=60.0) as client:
            provider = OpenAIChatCompletionsModel(model=settings['model'], openai_client=client)
            # A one-shot visual observation (only on a documented vision-capable model)
            # can be converted to a short text note before the tool loop. This prevents
            # the SDK from replaying the JPEG in every later tool round.
            # Continuation already has local views and an earlier report; do not
            # automatically bill another visual-observation request each time.
            if not intent and not report_context and meter.hard_max >= 4:
                view_input = _make_visual_input(
                    '只描述这个真实CAD四视图中的可观察结构、位置和形状，100至180中文字符。'
                    '不要凭外观认定螺纹、配合、运动或强度；不要使用额外工具。',
                    upload, settings, meter.run_id)
                if not isinstance(view_input, str):
                    image_path = str(upload.get('view_path') or upload.get('auto_view_path') or '')
                    cache_key = settings['base_url'] + '/' + settings['model'] + '/' + hashlib.sha256(Path(image_path).read_bytes()).hexdigest()[:20]
                    view_note_cache = upload.setdefault('vision_observations', {})
                    observation = view_note_cache.get(cache_key)
                    if not observation:
                        if meter.attempts >= meter.hard_max - 2:
                            raise RequestBudgetError('剩余调用额度不足，停止额外视觉观察以保留评测请求。')
                        live_progress.event(meter.run_id, 'vision', '分析真实CAD多视角图',
                                            '单独一次视觉请求，后续工具轮次不会重复附图')
                        vision_agent = Agent(name='CAVAI CAD View Observer',
                            instructions='只描述CAD图像中确实可见的外形，不执行功能验证。',
                            model=provider, tools=[],
                            model_settings=ModelSettings(**_sdk_model_options(settings, True)))
                        vision_response = await Runner.run(
                            vision_agent, input=view_input, max_turns=1,
                            run_config=RunConfig(tracing_disabled=True))
                        observation = str(vision_response.final_output or '').strip()[:550]
                        if not observation:
                            raise RuntimeError('视觉模型未返回观察内容；已停止，不自动重发图片。')
                        view_note_cache[cache_key] = observation
                        record({'event': 'visual_observation_cached', 'turn_id': meter.run_id,
                                'stage': 'vision_once', 'note_chars': len(observation)})
                    input_data += '\n【本次模型四视图观察（AI视觉推测，不是CAD数值测量）】\n' + observation
                    max_turns = max(1, meter.hard_max - meter.attempts)
            elif not intent and not report_context:
                live_progress.event(meter.run_id, 'vision', '已跳过额外图片观察', '用户设置的API请求上限较低，优先保留多轮工具检查')
            elif report_context:
                live_progress.event(meter.run_id, 'vision', '续评复用上一轮模型证据',
                                    '不重复发送四视图或原始CAD；如需几何细节由工具按需查询')
            model_options = _sdk_model_options(settings, intent)
            agent = Agent(name='CAVAI CATIA Review Agent' if not intent else 'CAVAI Model Intent',
                          instructions=instructions, model=provider, tools=tools,
                          model_settings=ModelSettings(**model_options))
            result = await Runner.run(agent, input=input_data, max_turns=max_turns,
                                      run_config=RunConfig(tracing_disabled=True))
            value = result.final_output
            if isinstance(value, str):
                return value.strip()
            if value is None:
                return ''
            return json.dumps(value, ensure_ascii=False, default=str)


def run_review(message: str, history: list, upload: Optional[dict],
               inspection: Optional[dict], trace_id: Optional[str] = None,
               report_context: Optional[dict] = None) -> dict:
    run_id = trace_id if trace_id and live_progress.valid_id(trace_id) else uuid.uuid4().hex[:16]
    geometry = (inspection or {}).get('geometry') or {}
    if not upload or (inspection or {}).get('status') != 'ok' or geometry.get('status') != 'ok':
        return _local_block('没有成功读取真实CAD B-Rep几何，本次未调用付费API。请先检查CATIA或STEP解析。', run_id)
    settings = get_llm_settings()
    if not all(settings.get(k) for k in ('api_key', 'base_url', 'model')):
        return _local_block('请先填写API地址、Key及模型ID；本次未调用付费API。', run_id)
    meter = HttpUsageMeter(settings, run_id, 'agent_review_continuation' if report_context else 'agent_review')
    trace: List[dict] = []
    loaded, queried = set(), set()
    try:
        text = asyncio.run(_run_sdk(intent=False, message=message, history=history,
                                    upload=upload, inspection=inspection, settings=settings,
                                    meter=meter, trace=trace, loaded=loaded, queried=queried,
                                    report_context=report_context))
        if meter.attempts < 1:
            raise RuntimeError('未观察到实际API请求，不会将本地模拟返回伪装成真实Agent报告。')
        if not text:
            raise ValueError('Agent最终回复为空，未产生可保存的真实报告。')
        if len(text) > 20000:
            # Too long is still authentic output; cap UI/file size safely.
            text = text[:20000] + '\n\n> Agent输出过长，展示已截取。'
        status = 'completed' if loaded and queried else 'partial'
        if status == 'partial':
            text = ('> 注意：本次Agent未完整完成本地Skill和几何工具查询，以下为模型原文，'
                    '不能视为已验证的工程结论。\n\n' + text)
        usage = meter.finish(status, trace)
        live_progress.event(run_id, 'report', '模型已完成分析，正在保存报告',
                            '使用本轮模型实际返回的Markdown原文')
        report = save_agent_markdown(markdown=text,
                                     filename=str(upload.get('filename') or ''),
                                     file_id=str(upload.get('file_id') or ''),
                                     model_id=settings['model'],
                                     loaded_skills=sorted(loaded), tool_trace=trace,
                                     geometry_fact_ids=sorted(queried), usage=usage, status=status)
        record({'event': 'agent_report_saved', 'turn_id': run_id,
                'report_id': report['report_id'], 'source': 'actual_sdk_final_output',
                'real_skill_calls': len(loaded), 'geometry_query_count': len(queried)})
        return {'reply': text, 'provider': 'openai_agents_sdk',
                'tool_trace': [{'tool': x['tool'], 'ok': x['ok']} for x in trace],
                'loaded_skills': sorted(loaded), 'report': report['report'],
                'report_id': report['report_id'],
                'report_download_url': report['download_url'],
                'turn_id': run_id, 'usage': usage}
    except ImportError as exc:
        reason = '没有安装OpenAI Agents SDK 0.8.4及其依赖，请执行 python -m pip install -r requirements.txt。' + str(exc)[:120]
    except Exception as exc:
        reason = _safe_error(exc, settings)
    usage = meter.finish('failed', trace, reason)
    return {'reply': '本次Agent未生成报告：' + reason, 'provider': 'openai_agents_sdk',
            'tool_trace': [{'tool': x['tool'], 'ok': x['ok']} for x in trace],
            'loaded_skills': sorted(loaded), 'report': None, 'report_id': None,
            'report_download_url': None, 'turn_id': run_id, 'usage': usage}


def run_intent(message: str, upload: Optional[dict], inspection: Optional[dict],
               trace_id: Optional[str] = None) -> dict:
    run_id = trace_id if trace_id and live_progress.valid_id(trace_id) else uuid.uuid4().hex[:16]
    geometry = (inspection or {}).get('geometry') or {}
    if not upload or (inspection or {}).get('status') != 'ok' or geometry.get('status') != 'ok':
        return _local_block('尚未成功解析CAD几何；用途识别没有调用付费API。', run_id)
    settings = get_llm_settings()
    if not all(settings.get(k) for k in ('api_key', 'base_url', 'model')):
        return _local_block('请先填写API地址、Key及模型ID。', run_id)
    meter = HttpUsageMeter(settings, run_id, 'intent_identification')
    try:
        reply = asyncio.run(_run_sdk(intent=True, message=message, history=[],
                                     upload=upload, inspection=inspection,
                                     settings=settings, meter=meter,
                                     trace=[], loaded=set(), queried=set()))
        if meter.attempts < 1:
            raise RuntimeError('没有观察到真实模型请求，不输出假识别结果。')
        if not reply:
            raise ValueError('模型未给出有效的用途识别文字。')
        usage = meter.finish('completed')
        return {'reply': reply, 'provider': 'openai_agents_sdk_intent', 'tool_trace': [],
                'loaded_skills': [], 'report': None, 'report_id': None,
                'report_download_url': None, 'turn_id': run_id, 'usage': usage}
    except Exception as exc:
        reason = _safe_error(exc, settings)
        usage = meter.finish('failed', error=reason)
        return {'reply': '用途识别失败：' + reason, 'provider': 'openai_agents_sdk_intent',
                'tool_trace': [], 'loaded_skills': [], 'report': None,
                'report_id': None, 'report_download_url': None,
                'turn_id': run_id, 'usage': usage}
