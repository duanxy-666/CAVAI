"""Bounded, evidence-based CAD context. Full B-Rep never goes into the default prompt."""
from __future__ import annotations

from typing import Any, Dict, Optional

from cad.feature_graph import brief_feature_graph, query_feature_graph


def summarize_model(upload: Optional[Dict[str, Any]], inspection: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not upload:
        return {"uploaded": False, "note": "未上传模型，不能作出实际几何结论。"}
    result: Dict[str, Any] = {
        "uploaded": True, "file_id": upload.get("file_id"),
        "filename": str(upload.get("filename") or "")[:120],
        "extension": upload.get("extension"),
        "inspection_status": (inspection or {}).get("status", "not_checked"),
    }
    if not inspection:
        result["limitations"] = ["CATIA尚未读取。"]
        return result
    if inspection.get("status") != "ok":
        result["inspection_error"] = str(inspection.get("error") or "未完成")[:350]
        result["limitations"] = ["模型读取失败，不能用外观或名称证明任何具体几何结构。"]
        return result
    part = inspection.get("part") or {}
    if part:
        result["catia_body_count"] = part.get("body_count")
        result["body_names_and_features"] = [
            {"name": str(body.get("name", ""))[:60], "feature_count": body.get("feature_count"),
             "feature_names": [str(f.get("name", ""))[:45] for f in body.get("features", [])[:24]]}
            for body in part.get("bodies", [])[:12]
        ]
        result["note_about_features"] = "特征名称不等于功能或几何证据；只能结合B-Rep判断。"
    if inspection.get("assembly"):
        result["assembly_tree"] = _small_assembly(inspection["assembly"])
    geo = inspection.get("geometry") or {}
    result["geometry_status"] = geo.get("status", "not_available")
    if geo.get("status") == "ok":
        for field in ("backend", "coordinate_unit", "solid_count", "face_count", "edge_count",
                      "face_type_counts", "edge_type_counts", "cylindrical_face_counts", "hole_candidate_count",
                      "source_format", "geometry_scope_note", "bounding_box_mm"):
            if field in geo:
                result[field] = geo[field]
        result["solids_summary"] = [
            {k: solid.get(k) for k in ("solid_id", "volume", "bounding_box_mm", "face_count", "edge_count") if k in solid}
            for solid in geo.get("solids", [])[:12]
        ]
        # Prominent geometric feature regions and their relationships, rather
        # than a long list of raw Face IDs. Labels are conservative geometry.
        result["structure_graph"] = brief_feature_graph(geo, max_features=12, max_relations=8)
        result["auto_preview_available"] = (geo.get("preview") or {}).get("status") == "ok"
        result["structure_graph_note"] = "同轴/相邻只表示几何关系，不能证明功能、接触或配合。"
        result["hole_candidates_summary"] = [
            {k: hole.get(k) for k in ("candidate_id", "topology_class", "diameter", "radius", "source_face_id") if k in hole}
            for hole in geo.get("hole_candidates", [])[:12]
        ]
        # Actual B-Rep evidence, bounded and aggregated: enough to compare engineering
        # requirements without sending tens of thousands of face/edge IDs to an API.
        from collections import defaultdict
        groups = defaultdict(list)
        for face in geo.get("faces", []):
            if face.get("surface_type") == "cylinder" and isinstance(face.get("radius"), (int, float)):
                key = (round(face["radius"], 4), face.get("cylindrical_side", "undetermined"))
                groups[key].append(face.get("face_id"))
        result["cylinder_radius_groups"] = [
            {"radius_mm": r, "side": side, "count": len(ids), "sample_face_ids": ids[:6]}
            for (r, side), ids in sorted(groups.items(), key=lambda pair: (-len(pair[1]), pair[0]))[:24]
        ]
        result["sample_planar_faces"] = [
            {"face_id": f.get("face_id"), "area_mm2": round(float(f.get("area", 0)), 3),
             "normal": f.get("normal"), "center_mm": f.get("center_of_mass")}
            for f in geo.get("faces", []) if f.get("surface_type") == "plane"
        ][:8]
        result["sample_conical_faces"] = [
            {"face_id": f.get("face_id"), "reference_radius_mm": f.get("reference_radius"),
             "semi_angle_degrees": f.get("semi_angle_degrees")}
            for f in geo.get("faces", []) if f.get("surface_type") == "cone"
        ][:8]
        result["observed_geometry_evidence_id"] = "BREP-SUMMARY"
        result["verified_vs_unverified"] = {
            "observed": "Solid/Face/Edge统计、圆柱面曲率分类、孔拓扑候选",
            "unverified": "装配配合、受力寿命、材料性能、螺纹规格和未经测量的工况"
        }
        result["full_geometry_local_only"] = True
        result["detail_tool"] = "如需某一面的精确证据，按需调用get_model_geometry_page，不要请求全量JSON。"
        result["geometry_limitations"] = [
            "孔候选数量为0只代表当前算法未检出常规孔候选，不能断言所有孔型、螺纹都不存在。",
            "STEP B-Rep实体数量不等于CATIA Body数量，也不等于装配零件数量。",
        ]
    else:
        result["geometry_error"] = str(geo.get("error") or "未获得可靠B-Rep结果")[:300]
    result["limitations"] = [str(x)[:180] for x in (inspection.get("limitations") or [])[:6]]
    return result


def _small_assembly(node: Dict[str, Any], level: int = 0) -> Dict[str, Any]:
    return {
        "name": str(node.get("name", ""))[:90],
        "part_number": str(node.get("part_number", ""))[:70],
        "children": [_small_assembly(c, level + 1) for c in node.get("children", [])[:8]] if level < 3 else [],
        "truncated": bool(level >= 3 and node.get("children")),
    }


def geometry_page(inspection: Optional[Dict[str, Any]], kind: str, start: int, limit: int) -> Dict[str, Any]:
    geo = (inspection or {}).get("geometry") or {}
    if geo.get("status") != "ok":
        return {"error": "B-Rep未成功解析，不能获取几何面/边。"}
    if kind not in {"faces", "edges", "solids", "hole_candidates"}:
        return {"error": "kind必须为faces、edges、solids或hole_candidates"}
    source = geo.get(kind) or []
    start = max(0, min(int(start), 10000000))
    limit = max(1, min(int(limit), 8))  # hard bound per tool result
    subset = []
    for item in source[start:start + limit]:
        if not isinstance(item, dict):
            continue
        # Preserve bounded topology ID references to make evidence follow-up possible.
        bounded = {k: v for k, v in item.items() if k not in
                   ("edge_ids", "face_ids", "vertex_ids", "adjacent_face_ids")}
        for key in ("edge_ids", "face_ids", "vertex_ids", "adjacent_face_ids"):
            ids = item.get(key)
            if isinstance(ids, list):
                bounded[key] = [str(x)[:36] for x in ids[:20]]
                if len(ids) > 20:
                    bounded[key + "_total"] = len(ids)
        subset.append(bounded)
    return {"kind": kind, "start": start, "returned": len(subset), "total": len(source),
            "items": subset, "note": "本次为分页证据，并非完整几何列表。"}


def geometry_lookup(inspection: Optional[Dict[str, Any]], entity_id: str) -> Dict[str, Any]:
    """Resolve exact B-Rep entity IDs locally without sending a full geometry dump."""
    geo = (inspection or {}).get("geometry") or {}
    if geo.get("status") != "ok":
        return {"error": "本地几何尚未成功解析。"}
    entity_id = str(entity_id).strip()
    for kind, id_key in (("faces", "face_id"), ("edges", "edge_id"),
                         ("solids", "solid_id"), ("hole_candidates", "candidate_id")):
        for item in geo.get(kind) or []:
            if isinstance(item, dict) and item.get(id_key) == entity_id:
                return {"kind": kind, "entity_id": entity_id, "item": _safe_entity(item),
                        "source": "local OCP B-Rep"}
    return {"error": "未找到几何实体ID：" + entity_id[:70]}


def _safe_entity(item: Dict[str, Any]) -> Dict[str, Any]:
    """Bound every tool result (including unexpected OCP diagnostic fields)."""
    out = {}
    for k, value in item.items():
        if isinstance(value, str):
            out[k] = value[:180]
        elif isinstance(value, (int, float, bool)) or value is None:
            out[k] = value
        elif isinstance(value, list):
            out[k] = value[:16]
        elif isinstance(value, dict):
            out[k] = {str(a): b for a, b in list(value.items())[:10]}
    return out


def geometry_search(inspection: Optional[Dict[str, Any]], kind: str,
                    surface_type: str = "", cylindrical_side: str = "",
                    radius_mm: Optional[float] = None, tolerance_mm: float = 0.05,
                    start: int = 0, limit: int = 5) -> Dict[str, Any]:
    """Search OCP evidence by geometric attributes; return bounded, paginated hits."""
    geo = (inspection or {}).get("geometry") or {}
    if geo.get("status") != "ok":
        return {"error": "本地几何尚未成功解析。"}
    if kind not in {"faces", "edges", "solids", "hole_candidates"}:
        return {"error": "不支持的几何类型。"}
    if cylindrical_side and cylindrical_side not in {"inner", "outer", "undetermined"}:
        return {"error": "圆柱面分类必须是inner、outer或undetermined。"}
    if surface_type and surface_type not in {"plane", "cylinder", "cone", "sphere", "torus",
                                             "bspline_surface", "other_surface", "circle", "line", "bspline"}:
        return {"error": "曲面/曲线类型不支持。"}
    if radius_mm is not None and (not 0 < float(radius_mm) < 10000000):
        raise ValueError("radius_mm超出有效范围")
    if not 0 <= float(tolerance_mm) <= 1000:
        raise ValueError("tolerance_mm超出有效范围")
    start, limit = max(0, int(start)), max(1, min(8, int(limit)))
    matched = []
    for item in geo.get(kind) or []:
        if not isinstance(item, dict):
            continue
        if surface_type and item.get("surface_type", item.get("curve_type")) != surface_type:
            continue
        if cylindrical_side and item.get("cylindrical_side") != cylindrical_side:
            continue
        if radius_mm is not None and (item.get("radius") is None or
                                      abs(float(item["radius"]) - float(radius_mm)) > float(tolerance_mm)):
            continue
        matched.append(item)
    return {"kind": kind, "filter": {"surface_type": surface_type, "cylindrical_side": cylindrical_side,
                                     "radius_mm": radius_mm, "tolerance_mm": tolerance_mm},
            "total_matches": len(matched), "start": start,
            "items": [_safe_entity(x) for x in matched[start:start + limit]],
            "returned": len(matched[start:start + limit]), "source": "local OCP B-Rep"}


def structure_feature_query(inspection: Optional[Dict[str, Any]], feature_id: str = '',
                            kind: str = '', start: int = 0, limit: int = 5) -> Dict[str, Any]:
    """Query actual feature graph nodes and relationships by stable local IDs."""
    geo = (inspection or {}).get('geometry') or {}
    if geo.get('status') != 'ok':
        return {'error': '本地B-Rep几何尚未解析成功'}
    return query_feature_graph(geo, feature_id=feature_id.strip(), kind=kind,
                               start=start, limit=limit)
