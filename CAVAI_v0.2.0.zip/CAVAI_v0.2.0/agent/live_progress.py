"""Local-only, read-only Agent execution progress.

This is a record of observable tool/API actions, not the model's hidden thoughts.
No API secrets, CAD geometry dumps or model private reasoning are stored here.
Python 3.9 compatible. UI polls this in-memory state; there is no paid API call.
"""
from __future__ import annotations

import re
import threading
import time
from typing import Any, Dict, Optional

_LOCK = threading.RLock()
_RUNS: Dict[str, dict] = {}
_ID_RE = re.compile(r"^[a-fA-F0-9]{16,64}$")
_MAX_RUNS = 128
_MAX_EVENTS = 75
_TTL_SECONDS = 1800


def valid_id(run_id: str) -> bool:
    return isinstance(run_id, str) and bool(_ID_RE.fullmatch(run_id))


def _clean(value: Any, max_len: int = 180) -> str:
    # Callers must pass explanations or safe summaries, never raw HTTP payloads.
    return ' '.join(str(value or '').split())[:max_len]


def begin(run_id: str, label: str = '开始分析') -> None:
    if not valid_id(run_id):
        raise ValueError('无效的本地进度追踪ID')
    now = time.time()
    with _LOCK:
        expired = [key for key, value in _RUNS.items()
                   if now - value['created_at'] > _TTL_SECONDS]
        for key in expired:
            _RUNS.pop(key, None)
        if len(_RUNS) >= _MAX_RUNS:
            oldest = min(_RUNS, key=lambda x: _RUNS[x]['created_at'])
            _RUNS.pop(oldest, None)
        _RUNS[run_id] = {'run_id': run_id, 'created_at': now, 'done': False,
                         'status': 'running', 'events': [], 'label': _clean(label)}
        _append_unlocked(run_id, 'start', label)


def _append_unlocked(run_id: str, kind: str, label: str, detail: str = '') -> None:
    run = _RUNS.get(run_id)
    if not run:
        return
    events = run['events']
    events.append({'index': len(events) + 1, 'kind': _clean(kind, 36),
                   'label': _clean(label, 110), 'detail': _clean(detail, 190),
                   'timestamp': round(time.time(), 3)})
    # Capped to ensure the local UI cannot grow without bound.
    if len(events) > _MAX_EVENTS:
        del events[1:len(events) - _MAX_EVENTS + 1]


def event(run_id: str, kind: str, label: str, detail: str = '') -> None:
    if not valid_id(run_id):
        return
    with _LOCK:
        _append_unlocked(run_id, kind, label, detail)


def finish(run_id: str, status: str, label: str = '') -> None:
    if not valid_id(run_id):
        return
    with _LOCK:
        run = _RUNS.get(run_id)
        if run is None:
            return
        if run['done']:
            return
        run['done'] = True
        run['status'] = 'completed' if status == 'completed' else 'failed'
        _append_unlocked(run_id, 'finish', label or ('分析完成' if status == 'completed' else '分析已结束'))


def snapshot(run_id: str) -> Optional[dict]:
    if not valid_id(run_id):
        return None
    with _LOCK:
        run = _RUNS.get(run_id)
        if not run:
            return None
        return {'run_id': run_id, 'done': run['done'], 'status': run['status'],
                'events': [dict(item) for item in run['events']],
                'note': '仅展示真实请求、工具调用及工程证据轨迹，不代表模型未公开的内部思维链。'}
