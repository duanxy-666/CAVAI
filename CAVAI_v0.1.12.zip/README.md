# CAVAI_v0.1.12 — CAD 工程评测 Agent

**目标：上传 CATPart、CATProduct 或 STEP → Python/CATIA/OCP 解析 → 云端 Agent 自主调用本地 Skill 和几何查询 → Agent 写出工程报告 → 网页展示/下载。** 评测正确率是后续提高的目标，不用预写产品类型或强迫用户会写提示词。

## 技术选型（有出处）

- Agent：**OpenAI Agents SDK `0.8.4`**，PyPI 官方元数据明确支持 **Python ≥3.9**。使用其 `Agent`、`Runner.run`、`function_tool`、`OpenAIChatCompletionsModel` 和 `max_turns`；不自行编写多轮 LLM 调度循环。源码 `agent/sdk_agent.py`。
- API：用户填写自己的 OpenAI **Chat Completions 兼容** Base URL、API Key、模型名。首选验证对象是 DeepSeek 官方 `https://api.deepseek.com` + `deepseek-flash`；其他服务商要支持对应的原生工具调用协议。Agent SDK 是运行框架，不代表必须购买 OpenAI API。
- CAD：`cad/format_router.py`、`cad/catia_reader.py`、`cad/brep_analyzer.py`。STEP/STP 本地直接 OCP；CATPart/CATProduct 需 Windows CATIA V5 COM，先本地导出 STEP，再 OCP 提取几何。
- Skill：`skills/*/SKILL.md` 完全在本机，Agent **真正调用** `load_skill` 后才读到该文件；具体面、边、孔和尺寸由 Python `get_current_model_facts`、`search_model_geometry`、`get_geometry_entity_by_id` 等工具读取，不是 Skill 文件直接执行几何计算。
- Skill选择：随代码包预装，用户不需要下载或配置GitHub项目；按模型类别选择 `fastener-review`（紧固/孔）、`fixture-review`（夹具定位）、`manufacturing-dfm-review`（制造性）或已有的通用Skill。支持 `read_skill_reference` **按需加载**规则文件，并提供只读的 `check_fastener_hole_evidence` 本地几何检查工具。**这些是独立编写并注明来源的适配Skill，不代表已将第三方FreeCAD或text-to-cad的几何运行时代码移植进项目。**
- 报告：SDK Runner 的**最终实际文本输出**被本机 `reports/agent_report.py` 保存为 Markdown 和 JSON；**没有 `save_review_report` 工具**，不再用过长 JSON 参数让模型反复写文件。
- 用量：`agent/sdk_agent.py` 将 HTTPX 钩子挂在实际 OpenAI-compatible Chat Completions HTTP 请求上。每笔开始/成功/402/超时、服务商返回的 Token 与缓存 Token 都写入 `data/usage/events.jsonl`，不存 API Key 或完整模型。默认关闭 SDK/HTTP 自动重试。未得到 usage 时标记为未知；金额以服务商账单为准。

官方资料：

- Python 3.9 兼容 SDK 版本：https://pypi.org/project/openai-agents/0.8.4/
- Agents SDK Runner/本地 function tools：https://openai.github.io/openai-agents-python/running_agents/ 和 https://openai.github.io/openai-agents-python/tools/
- 官方 DeepSeek Chat Completions：https://api-docs.deepseek.com/api/create-chat-completion/
- CATIA Python Automation：https://github.com/evereux/pycatia
- Open CASCADE：https://dev.opencascade.org/

> 当前项目使用 **0.8.4** 的公共接口。官方文档网站的默认页面可能描述更高版本；因此固定了依赖版本。**本压缩包不内置第三方软件包**，须从可用的 PyPI 源安装。没有安装到真实 SDK 的环境不能宣称完成了真实框架集成测试。

## 在你的 Python 3.9 / PyCharm 上运行

1. 关闭旧 CAVAI；解压完整 ZIP；在 PyCharm 打开 `CAVAI_0.1.12` 文件夹，使用 **64 位 Python 3.9** 解释器（不需要升级 Python）。
2. 打开 PyCharm Terminal，在项目文件夹执行：

```powershell
python -m pip install -r requirements.txt
python -m pip install -r requirements-catia.txt
python -m unittest tests.test_sdk_runtime_smoke -v
python run.py
```

3. Ctrl + 左键点击终端打印的 `http://127.0.0.1:8000`，在 **API 设置** 里填 Base URL、Key、模型 ID，保存。
4. 上传 CATPart、CATProduct 或 STEP。可以不输入提示词；也可以先点击 **识别用途**（可选），检查系统对功能的猜测，补充或修正目标。然后点击 **开始评测**。
5. 查看 Agent 实际生成的报告和逐笔 Token 账本。报告存放在 `data/reports/`，完整 B-Rep 在 `data/evidence/`，用户文件在 `data/uploads/`。

**提示：** 如果只是 STEP，可不安装/启动 CATIA；如果是 CATPart/CATProduct，必须有本机可用的 CATIA V5 和 STEP 导出能力。运行 CAVAI 不要求访问 GitHub、LangSmith 或 OpenAI tracing 服务，**但云端 AI 评测必须能访问用户所选的 API 服务商**。

## Skill 与 Benchmark 的取舍

- **运行时用 Skill 组织检查方法和调用工具**；没有额外开发Benchmark打分模块。每个检查结论都要求来自CAD几何证据或用户要求；缺证据时报告“未验证”。
- 按 [Agent Skills规范](https://github.com/agentskills/agentskills/blob/main/docs/specification.mdx) 使用 `SKILL.md`、`references/` 渐进加载：启动只传Skill目录，Agent需要时才读取其正文与引用。
- 参考 [text-to-cad 的 DFM Skill](https://github.com/earthtojake/text-to-cad/blob/main/skills/dfm/SKILL.md) 的制造工艺分流方法以及 [freecad-automation](https://github.com/dooosp/freecad-automation) 的阶段式工程审查；**未安装/复制他们的CAD解析引擎**，只适配其公开的方法。第三方仓库许可与能力边界见 `references/SKILL_PROVENANCE.md`。
- 已可由Agent调用 `check_fastener_hole_evidence` 查询内外圆柱面/孔候选，仍不等于自动证明螺纹、力学强度或加工合格。

## Token 保护（界面只有一个可选开关）

默认不限制**用户预算**，仍有应用内硬性 **12 次请求**安全熔断；开启后可单独设置 **本次 Token 上限（估算）** 与 **API 请求次数上限**。Python 工具结果分页、按ID查询；重复的本地工具调用复用缓存，同样的完整 HTTP 请求超过两次会在发送前熔断。`max_retries=0`，不因 402/输出截断自动付费重试。Token 是按请求字节估算，上限不是服务商绝对计费承诺；实际 Token 以返回 usage 和服务商账单为准。

## 视觉输入

用户可上传可选截图。本版本 **仅在点击“识别用途”** 且模型能力表确认支持图像时，发送一次压缩视图。多轮正式评测主要传结构化几何文本、按需工具结果；不反复转发图像，也不直接把 CATPart 原文件发送给不支持 CAD 的 API。未知模型视觉能力默认禁用，不发付费探测请求。**用户可以不上传任何截图。**

## 闭环边界与已验证范围

- **本地已测试**：真实 OCP 创建并解析的 STEP（通孔、盲孔、实心凸台），FastAPI 上传→几何读取→模拟框架/模型调用→本地 Skill 工具→Markdown 报告下载；HTTPX 模拟 402、相同请求熔断、预算拦截、用量账本；Python 3.9 **语法**检查。
- **尚未验证**：真实安装的 `openai-agents==0.8.4` 与全部依赖在用户 Windows/Python 3.9 上运行；真实 DeepSeek 工具调用/视觉调用；用户 CATIA V5 的 STEP 导出。**请先运行零费用 smoke test**，确认 SDK 接口构造成功；只有在用户愿意并有可用额度的情况下才发起付费评测。
- API 不支持 Tool Calling 或模型未正常完成时会报告失败，不会假装已执行 Skill。模型给出最终报告但未调用任何本地工具时会明确标记为 **partial**，不能冒充已验证的工程报告。
- 几何拓扑检测不是力学求解器；材料、载荷、强度和装配关系缺失时应在报告中明确标注未验证，不能编造强度或配合数据。

## 主要代码

```
run.py                       # 启动网页（Python 3.9）
main.py                      # FastAPI 上传/评测/报告/账本接口
agent/sdk_agent.py           # OpenAI Agents SDK Runner + 本地工具 + HTTP Token 审计
agent/model_context.py       # CAD几何摘要/分页/按ID查询
agent/model_capabilities.py  # 不收费的保守视觉能力规则
cad/format_router.py         # CATIA文件和STEP的本地解析路由
cad/catia_reader.py          # CATIA COM读取和STEP导出
cad/brep_analyzer.py         # OCP B-Rep Face/Edge/Solid/孔候选
skills/                      # 预装的 Agent Skills 及按需参考文件（无需用户下载GitHub）
reports/agent_report.py      # Agent最终Markdown原文落盘
frontend/                    # 保留原界面和logo
```
