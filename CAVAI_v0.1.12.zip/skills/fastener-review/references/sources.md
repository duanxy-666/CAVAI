# Source and provenance

- Agent Skills packaging: https://github.com/agentskills/agentskills/blob/main/docs/specification.mdx
- CAD geometry inspection workflow and STEP/B-Rep provenance: https://github.com/earthtojake/text-to-cad/blob/main/skills/cad/SKILL.md
- Existing CAVAI `cad/brep_analyzer.py`, `agent/model_context.py`, and the user's negative-test requirement (solid hexagonal boss does not imply a nut).

**Reuse disclosure:** The checklist and text in this CAVAI Skill are independently written for the existing local evidence API, informed by linked workflows. No source repository's geometry engine was vendored or represented as integrated. Numerical tolerance rules are intentionally not hard-coded without standards or requirements.
