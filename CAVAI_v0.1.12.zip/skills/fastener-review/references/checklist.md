# Fastener-specific evidence checklist

| Functional claim | Minimum observations or required input | If absent |
| --- | --- | --- |
| Screw/nut with through clearance hole | Inner cylindrical face plus boundary/topology indicating open connection; estimated diameter | NOT_VERIFIED; distinguish solid boss |
| Blind tapped hole | Cavity/inner face plus bottom topology; pitch/thread metadata or design drawing | Do not claim a threaded hole |
| Fastener can pass through | Hole diameter, mating shank diameter, relevant section and direction | NOT_VERIFIED unless clearance documented |
| Joint holds preload | Material, fastener grade, pretension, engagement length, load case | Strength not verified |
| Multiple parts fit | CATProduct instances, transforms, constraints, clearances and interference | Assembly fit not verified |

**Geometry facts are evidence, not compliance to a numerical standard.** Never choose a pass/fail tolerance without declared design requirements or a cited applicable standard. If the model includes only solid six-sided and cylindrical extrusions, describe the observed solid features and do not rename them as functional hardware.
