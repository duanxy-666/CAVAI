---
name: fastener-review
description: Review suspected bolts, nuts, screws, holes, bosses, and fastening interfaces by actual CAD topology, not by silhouette or feature names. Use when user asks about threaded fastening, mounting, or bolt-hole functionality.
compatibility: CAVAI local CATIA V5 and OCP B-Rep evidence; no network required to load the Skill.
---

# Fastener & mounting interface review

**Trigger:** A bolt/nut/screw, mounting hole, standoff, threaded joint or fastening function is claimed or suspected. Do not claim that a cylindrical/hexagonal boss is a real bolt or nut solely because of its appearance.

## Minimum evidence procedure

1. Call `get_current_model_facts` to identify Solid counts, cylindrical face direction, hole-candidate counts, units and parsing scope.
2. Call `check_fastener_hole_evidence` for a compact, reproducible initial summary; its output is *evidence*, not an automatic verdict.
3. For possible holes, call `search_model_geometry` with `kind="faces"`, `surface_type="cylinder"`, `cylindrical_side="inner"`, then `get_geometry_entity_by_id` for the relevant Face IDs. Inspect same-axis faces, boundary edges and bottom faces where accessible.
4. For protrusions, search `cylindrical_side="outer"` and identify which faces are merely solid bosses.
5. Compare findings with user-stated fastening requirements. Separate geometrically observed holes from **engineering threads**, which may be symbolic or absent from neutral geometry.
6. Report `SUPPORTED`, `CONTRADICTED`, or `NOT_VERIFIED` for each requirement with evidence IDs and necessary follow-up measurements.

## Prohibitions and limits

- `hole_candidate_count == 0` means the current detector found no *regular hole candidate*, not that every conceivable hole is absent.
- A hole candidate is not proof of a mating fastener, correct thread, fit, strength or assembly.
- A CATPart B-Rep cannot by itself establish full CATProduct assembly connections.
- Do **not** invent standard thread sizes or allowable loads.

Additional rule breakdown: `references/checklist.md` (load only when the task requires detailed fastening checks).
