# Part Geometry Review — Sources

## Runtime APIs used
- pycatia 0.10.1 Document.export_data: https://pycatia.readthedocs.io/en/latest/api/pycatia/in_interfaces/document.html
  - Exports the current CATIA document to a supported neutral format. CAVAI exports a temporary `.stp` copy and does not save the source CATPart.
- pycatia 0.10.1 Getting Started: https://pycatia.readthedocs.io/en/latest/introduction.html
  - Documents `application = catia()`, `application.documents`, and opening CATIA documents.
- pycatia Part API: https://pycatia.readthedocs.io/en/latest/api/pycatia/mec_mod_interfaces/part.html
  - Part.Bodies access.
- pycatia Body API: https://pycatia.readthedocs.io/en/0.10.1/api/pycatia/mec_mod_interfaces/body.html
  - Body.Shapes access.
- CadQuery/OCP 7.7.2: https://github.com/CadQuery/OCP
  - Actual B-Rep runtime: STEPControl_Reader, TopExp, TopTools_IndexedMapOfShape, TopoDS, BRepAdaptor_Surface/Curve, BRepGProp, BRepLProp_SLProps.

## Algorithm references
- AIminminAI/Huhb3D-Viewer STEP topology parser: https://github.com/AIminminAI/Huhb3D-Viewer/blob/main/step_topology_parser.py
  - Reference for classifying concave/convex cylindrical surfaces from B-Rep normals and radial direction. CAVAI implements its own orientation-aware version; no source file is copied verbatim.
- Burić, M. & Marjanović, D. (2018), "A Tool for Idealisation of CAD Models", DESIGN 2018. https://doi.org/10.21278/idc.2018.0367
  - Method reference for CATIA V5 specification-tree and B-Rep-based geometry analysis.
- BRepNet, CVPR 2021: https://github.com/AutodeskAILab/BRepNet
  - Research reference for B-Rep topological reasoning; not a drop-in hole detector.
- Hierarchical CADNet (2022): https://doi.org/10.1016/j.cad.2022.103226
  - Research reference for machining-feature recognition.

## Scope
Hole results are topology candidates, not a complete standard-hole or thread recognizer.
