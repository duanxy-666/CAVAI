---
name: part-geometry-review
description: "Use to assess whether a CATPart's observed geometry and topology support user-defined design requirements, using CATIA Body facts and Open CASCADE B-Rep Face/Edge/Solid data."
---

# Part Geometry Review Skill

## 本版本数据路径
1. CATIA V5读取Part.Bodies与Body.Shapes，记录Body和特征树。
2. CATIA Document.ExportData导出临时STEP副本，不保存或修改原始CATPart。
3. Open CASCADE OCP解析STEP中的Solid、Face、Edge。
4. 提取Surface/Curve类型、面积/长度/体积、质心、方向、几何参数和拓扑关联。
5. 读取`geometry` JSON作为本轮评测的几何证据。

## 检查重点
- 分开报告CATIA Body数量与B-Rep Solid数量，不假设两者一一对应。
- 识别Plane、Cylinder、Cone、Sphere、Torus、BSpline等曲面。
- 识别Line、Circle、Ellipse、BSpline等边曲线。
- 区分内圆柱面与外圆柱面，检查其轴线、半径和边界圆。
- 根据内圆柱面、同轴圆形边界及相邻平面封闭面形成孔拓扑候选。
- 对用户明确提出的功能逐项映射到几何证据。

## 证据边界
- 内圆柱面是凹圆柱几何，不自动等于工程孔。
- `through_hole_candidate`和`blind_hole_candidate`是拓扑候选，不等于标准孔或螺纹已确认。
- 本版本没有完整的螺纹规格/螺旋曲面识别。
- STEP导出或OCP解析失败时，必须报告“B-Rep未验证”，不得把未检查说成没有孔。
- 实心六角凸台不能仅因外形相似而认定为螺母。
- 任何结论必须引用实际Face/Edge/Solid或hole candidate ID。

## 输出
列出几何事实、证据ID、用户要求符合性、问题严重程度、修改建议和未验证事项。
