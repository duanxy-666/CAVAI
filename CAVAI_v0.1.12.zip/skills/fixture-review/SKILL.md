---
name: fixture-review
description: Review the intended positioning, support and clamping functions of fixtures, jigs, workholding brackets and related machine-tool devices. Use when the CAD model or user intent suggests locating or clamping a workpiece.
compatibility: Local CATIA/OCP CAD facts; can express unknowns without an assembly or loads.
---

# Fixture function review

**Use when:** The user describes workholding, locating, support, clamping or fixture installation, or the Agent has a clearly marked hypothesis of such a function.

1. Identify the *workpiece* and contact/locating surfaces only from explicit evidence. If only a CATPart exists, note that mating workpieces may be missing.
2. Query `get_current_model_facts` for bodies, solids, bounding boxes, hole candidates and available plane Face IDs; fetch relevant local faces by ID.
3. Verify whether mounting, locating and clamping features have supporting geometry. Separate support *surfaces* from completed functional assemblies.
4. For positioning, distinguish observations (flat support surface, possible dowel hole) from claims (six freedoms constrained, repeatability). Do not assert complete kinematics without constraints and contacts.
5. For clamping, determine what is actually known about the force path; when missing actuator/bolt, coefficient of friction, workpiece or applied force, mark load-carrying adequacy as not verified.
6. Report required function → inspected CAD evidence ID → result (`SUPPORTED`, `CONTRADICTED`, `NOT_VERIFIED`) → modification or missing information.

Read `references/checklist.md` only if the user's requirements call for a detailed fixture assessment. Avoid assigning arbitrary safety factors or grades.
