# Source and provenance

- Generic stepwise engineering review and evidence traceability: https://github.com/dooosp/freecad-automation
- This Skill's analysis checklist is CAVAI-authored and applied to OCP/CATIA evidence, not a port of FreeCAD-automation.
- The existence of geometric evidence alone does not prove force transmission or fixture performance. No extra FEM engine is included.
