# Fixture checks by expected function

- **Locating:** Confirm reference/contact faces from CAD; ask for mating workpiece and datum scheme. A visible hole is not proof of a locating pin.
- **Supporting:** Verify actual support surfaces and their orientation (if OCP Face normals are available). Contact pressure is unknown without load and material.
- **Clamping:** Locate potential clamp arm/screw paths; assess whether the mechanism is *demonstrated*, *contradicted*, or *not verifiable*. No fastening solely from a named feature.
- **Mounting:** Query inner faces and hole candidates for baseplate mounting; cross-check with mating dimensions if given.
- **Assembly:** If CATProduct, inspect component hierarchy and references; if only CATPart, don't invent workpiece instances or contact constraints.
- **Mechanical adequacy:** Stress, deformation, stiffness and friction cannot be quantified without loads, material data and appropriate numerical simulation.

Existing CAVAI geometry tool support is limited to observed shapes and topology candidates; many above items are initially `NOT_VERIFIED` rather than automatic defects.
