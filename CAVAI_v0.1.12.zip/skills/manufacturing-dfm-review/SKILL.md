---
name: manufacturing-dfm-review
description: Process-aware manufacturability review for CNC machined parts, sheet metal, molding or additive manufacturing. Use when the material and manufacturing process are stated or can be kept as hypotheses.
compatibility: CAVAI local B-Rep evidence only; full DFM solvers are not installed or implied.
---

# Manufacturing process-aware review

**Source direction:** Follow the *choose process → gather the correct measurements → identify unsupported checks* approach of `earthtojake/text-to-cad` DFM Skill and the review/evidence separation in `dooosp/freecad-automation`. See `references/sources.md`. This CAVAI adaptation does **not** vendor their DFM executable or imply that CNC/toolpath, injection-flow or printability solvers are present.

1. Establish which process was specified by the user: CNC, sheet metal, molding, additive, or unknown. If unspecified, mark alternatives as hypotheses, not fact.
2. Fetch relevant actual geometry and dimensions with `get_current_model_facts`, `search_model_geometry`, and entity ID queries.
3. Select applicable questions from `references/process-checks.md` (load only for detailed DFM review).
4. Verify only what the current available CAD geometry can prove: entity shapes, sizes and certain hole candidates. Do not claim measured minimum wall thickness, reachability, draft or interference without a dedicated tool result.
5. Label every finding `SUPPORTED`, `CONTRADICTED`, or `NOT_VERIFIED`, with source face/hole IDs and suggestions.

**No arbitrary benchmark scores or generic thresholds.** If no material, tolerances, production volume, tool sizes or processing method are known, explicitly report limitations.
