# Sources reviewed for this Skill's method

1. https://github.com/earthtojake/text-to-cad/blob/main/skills/dfm/SKILL.md — manufacturing-process selection with process-specific reference materials and checks (MIT). Tool commands there are for its **own CAD runtime** and must NOT be claimed available in CAVAI.
2. https://github.com/dooosp/freecad-automation — `scripts/dfm_checker.py` and artifact/report workflow, tied to that project's FreeCAD runtime. No FreeCAD requirement added to CAVAI.
3. https://github.com/agentskills/agentskills/blob/main/docs/specification.mdx — packaged, progressively loaded instructions and references.

**Provenance declaration:** This CAVAI Skill is an independently authored, simplified implementation of the *workflow pattern*, not copied third-party DFM code. It has only the CATIA/OCP capabilities available in CAVAI 0.1.12. Its checks do not constitute mechanical validation or a commercial DFM pass.
