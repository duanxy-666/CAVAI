# Manufacturing process questions (not automatically executed tests)

## CNC machining / turning
- Are access directions, cutter diameters and workholding known? If not, tool access and corner radius suitability cannot be certified.
- Are any measured deep pockets or holes present? Current B-Rep can report face classes but does not compute tool accessibility.
- Are quoted tolerances, surface finish and material available? Never certify them from a neutral CAD solid alone.

## Sheet metal
- Is a uniform thickness and bend allowance defined? A generic B-Rep without thickness calculation is insufficient to pass/fail.
- If a bend is found, are its radius and material requirements known?

## Injection molding
- Does the model expose a draft direction, core/cavity partition or measured draft? If not, undercuts and tooling split cannot be verified.

## Additive manufacturing
- Is build orientation, process, material and minimum feature size defined? If not, avoid a confident printability claim.

The checklists are *question selection guidance*. Add deterministic, source-backed geometry tools as they become available; do not present unchecked items as successful simulations.
