# CAVAI V0.1.6 — Open-source reference and adoption map

This document records which upstream projects inform each CAVAI area, what is actually reused, what is only an architectural reference, and what is not integrated. A link in this document does not mean upstream code has been copied.

## 1. FreeCAD Automation — major engineering-review architecture reference

Repository: https://github.com/dooosp/freecad-automation  
License shown by GitHub: MIT.  
Project description: FreeCAD-backed CAD, TechDraw, inspection, FEM, reporting, and manufacturing-review pipeline.

### What is important to CAVAI
The README documents two runtime layers:
- Runtime-backed CAD layer for CAD, TechDraw, FEM, tolerance, inspection, and reports.
- Plain-Python/Node layer for DFM, process planning, readiness review, revision impact, inspection planning, and result handoff.

It also documents explicit artifacts and workflow stages such as:
- `review-context` -> `review_pack.json`
- `readiness-pack` -> `readiness_report.json`
- standard-document generation
- release bundle packaging
- revision comparison and reinspection planning
- inspection evidence intake, quarantine, validation, authorization, and attachment
- schema contracts and CLI lifecycle definitions

### Upstream source locations named in its README
- `bin/fcad.js`: CLI entry point
- `lib/runner.js`: runtime invocation/orchestration
- `scripts/intent_compiler.py`: intent-to-plan translation
- `scripts/dfm_checker.py`: deterministic DFM checks
- `src/agents/`: manufacturing engineering agents
- `src/workflows/`: review/readiness/document workflows
- `schemas/`: output contracts
- `docs/product-workflows.md`
- `docs/command-lifecycle.md`
- `tests/`: regression and contract tests

### CAVAI mapping
| Upstream concept | CAVAI destination | Adoption status |
|---|---|---|
| Two-layer runtime/review architecture | `cad/` vs `agent/`, `review/` | Architecture adopted |
| Intent compiler | `skills/design-intent-analysis/` | Workflow reference; no source code copied |
| DFM checker | future `tools/dfm/` | Not implemented |
| Review pack artifact | `schemas/review_pack.schema.json` | CAVAI-specific contract inspired by artifact-first design |
| Readiness/evidence distinction | `skills/engineering-review-workflow/` | Workflow principle adopted |
| Revision impact/reinspection planning | future revision-review Skill | Not implemented |
| CLI runtime diagnostics | `run.py`, `start_windows.bat`, `/api/health` | Local launcher/diagnostic adapted; not copied |

### Important compatibility boundary
This upstream project is FreeCAD-based, not CATIA-based. Its README reports mature runtime validation mainly on macOS with FreeCAD 1.1.x, and says Windows native runtime execution is experimental/compatibility-only. Its test lane also specifies Python 3.11+. Therefore CAVAI does not install FreeCAD or depend on its runtime. The project is used as a reference for workflow separation, artifact contracts, evidence provenance, and review lifecycle.

## 2. CATIA V5 integration

### pycatia
Repository: https://github.com/evereux/pycatia  
Documentation: https://pycatia.readthedocs.io/en/latest/  
License: MIT.  
Supports Python >=3.9 and CATIA V5 on Windows according to its repository README.

CAVAI uses pycatia as its preferred CATIA automation adapter. Relevant documented interfaces:
- `from pycatia import catia`
- `application.documents`
- `application.active_document`
- `documents.open(path)`
- `PartDocument.part`
- `Part.bodies`
- `Body.shapes`
- `ProductDocument.product`
- `Product.products`

The low-level COM fallback remains for compatibility and diagnostics.

### CATIA MCP projects
- https://github.com/hoacv5/Catia_MCP
- https://github.com/rutwikg/catia-mcp

Use as references for exposing CATIA operations as tools, COM-thread handling, tool schemas, and error recovery. Do not copy code without checking each repository's license and Python requirements.

### CATIA assembly clash/clearance/contact project
- https://github.com/Sajath7143/Automated-Clash-Clearance-and-Contact-Analysis-for-CAD-Assemblies-CATIA-V5-Python-

Reference for CATIA DMU-based clash, clearance, and contact workflows. Requires checking CATIA module/license availability and upstream license before direct reuse.

## 3. CAD geometry and topology

- CadQuery/OCP: https://github.com/CadQuery/OCP — Python Open CASCADE bindings; candidate geometry kernel for B-Rep operations.
- BRepNet: https://github.com/AutodeskAILab/BRepNet — research implementation for topological learning on B-Reps.
- Hierarchical CADNet: https://doi.org/10.1016/j.cad.2022.103226 — machining-feature recognition research.

These are not drop-in nut/bolt recognizers. OCP provides geometry operations; BRepNet/CADNet are research methods that require datasets, model integration, and validation.

## 4. Agent workflow

- CAD-Assistant: https://github.com/dimitrismallis/CAD-Assistant — reference for tool-augmented CAD task execution and feedback-driven iteration. Review its non-commercial license before any code reuse.

CAVAI's dynamic Skill mechanism follows the Agent Skills format:
- https://github.com/agentskills/agentskills
- Skill names use lowercase letters, digits, and hyphens.
- Folder name must match frontmatter `name`.
- Metadata is discovered first; full `SKILL.md` is loaded on demand; `references/` files are read only when needed.

## 5. What is directly integrated in V0.1.6
- `pycatia` is the preferred runtime connection path in `cad/catia_reader.py`, using documented `catia.documents.open`, `catia.active_document`, `document.part()`, `document.product()`, `Part.bodies`, `Body.shapes`, `Product.get_products`, and `Product.position.get_components` patterns; pywin32 COM remains a fallback.
- Dynamic Skill discovery/loading remains in `skills/registry.py` and `agent/llm_client.py`.
- FreeCAD Automation contributes the engineering-review workflow model and artifact/evidence boundaries; FreeCAD runtime and upstream source files are not bundled.
- A CAVAI review-pack schema is included as a CAVAI-specific contract inspired by upstream schema-driven workflows.

## 6. What is not yet integrated
- No FreeCAD runtime.
- No direct port of `dooosp/freecad-automation` source code.
- No B-Rep topology implementation in the CATIA reader yet.
- No automatic DFM, FEM, tolerance, or revision-impact analysis yet.
- No claim that a generated report is physical inspection evidence.

## V1.0.8 — CATPart B-Rep geometry implementation

| Component | Reference | Use in this version | Status |
|---|---|---|---|
| `cad/catia_reader.py` | pycatia 0.10.1 Document/Part/Body APIs | Reads CATIA Bodies/Shapes and exports temporary STEP with `Document.export_data` | Integrated; actual CATIA runtime test pending |
| `cad/brep_analyzer.py` | CadQuery/OCP 7.7.2 | Parses STEP B-Rep; unique Solid/Face/Edge maps; Surface/Curve classes; mass properties; cylinder inner/outer classification | Integrated; synthetic regression tests passed |
| Cylinder concavity rule | Huhb3D-Viewer STEP topology parser | Reference for oriented face normal vs radial vector method; CAVAI implementation is independently written | Algorithm reference |
| Hole candidates | OCP topology adjacency + Burić & Marjanović (2018) method reference | Inner cylinder + coaxial circular edges + adjacent planar cap evidence | Implemented as candidates, not certified hole/thread semantics |
| `part-geometry-review` Skill | Above references | Describes evidence use and limitations | Updated |

### Reproducible test cases
- Hexagonal solid boss + two solid cylindrical bosses, no holes: expected 3 solids, 0 inner cylinders, 0 hole candidates.
- Cylinder with a through bore: expected `through_hole_candidate`.
- Cylinder with a blind bore: expected `blind_hole_candidate`.

The tests use synthetic STEP geometry to validate the OCP parser. They do not replace a runtime test against the user's CATIA model.
