# CAVAI V0.1.6 — References

## Open-source software
1. dooosp. *freecad-automation*. MIT License. https://github.com/dooosp/freecad-automation
2. Bourne, P. *pycatia*. MIT License. https://github.com/evereux/pycatia
3. hoacv5. *Catia_MCP*. https://github.com/hoacv5/Catia_MCP
4. rutwikg. *catia-mcp*. https://github.com/rutwikg/catia-mcp
5. Sajath7143. *Automated Clash, Clearance and Contact Analysis for CAD Assemblies — CATIA V5 Python*. https://github.com/Sajath7143/Automated-Clash-Clearance-and-Contact-Analysis-for-CAD-Assemblies-CATIA-V5-Python-
6. CadQuery. *OCP*. https://github.com/CadQuery/OCP
7. Autodesk AI Lab. *BRepNet*. https://github.com/AutodeskAILab/BRepNet
8. Mallis et al. *CAD-Assistant*. https://github.com/dimitrismallis/CAD-Assistant
9. Agent Skills. *Agent Skills Open Standard*. https://github.com/agentskills/agentskills

## Research papers
10. Mallis, D. et al. (2025). *CAD-Assistant: Tool-Augmented VLLMs as Generic CAD Task Solvers*. ICCV 2025. https://openaccess.thecvf.com/content/ICCV2025/html/Mallis_CAD-Assistant_Tool-Augmented_VLLMs_as_Generic_CAD_Task_Solvers_ICCV_2025_paper.html
11. Lambourne, J. G. et al. (2021). *BRepNet: A Topological Message Passing System for Solid Models*. CVPR 2021. https://openaccess.thecvf.com/content/ICCV2021/html/Lambourne_BRepNet_A_Topological_Message_Passing_System_for_Solid_Models_ICCV_2021_paper.html
12. Colligan, A. R. et al. (2022). *Hierarchical CADNet: Learning from B-Reps for Machining Feature Recognition*. Computer-Aided Design, 147, 103226. https://doi.org/10.1016/j.cad.2022.103226

## Implementation provenance rule
For every future direct code import, record: upstream repository, exact file path, commit or release, license, modifications, and test coverage. Architectural inspiration must be labeled as such; it must not be described as copied or integrated code.


## HTTPX / OpenAI SDK compatibility incident
13. OpenAI Python SDK issue #1908: openai 1.30.1 with httpx 0.28 fails because `proxies` was removed. The reporter confirms httpx 0.27.2 fixes it. https://github.com/openai/openai-python/issues/1908
14. OpenAI Python SDK issue #1902: documents `httpx==0.28.0` removal of `proxies` and the resulting SDK initialization error. https://github.com/openai/openai-python/issues/1902
15. HTTPX 0.28.0 release notes: removal of deprecated `proxies` argument. https://github.com/encode/httpx/releases/tag/0.28.0

## V1.0.8 — B-Rep extraction
- pycatia 0.10.1 Document.export_data: https://pycatia.readthedocs.io/en/latest/api/pycatia/in_interfaces/document.html
- pycatia 0.10.1 Getting Started: https://pycatia.readthedocs.io/en/latest/introduction.html
- CadQuery/OCP: https://github.com/CadQuery/OCP
- cadquery-ocp 7.7.2 release files (includes CPython 3.9 Windows x64 wheel): https://pypi.org/project/cadquery-ocp/7.7.2/
- AIminminAI/Huhb3D-Viewer `step_topology_parser.py`: https://github.com/AIminminAI/Huhb3D-Viewer/blob/main/step_topology_parser.py
- Burić, M. & Marjanović, D. (2018). "A Tool for Idealisation of CAD Models." DESIGN 2018. https://doi.org/10.21278/idc.2018.0367
