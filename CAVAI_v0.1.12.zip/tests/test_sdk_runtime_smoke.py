"""No-billing smoke test of actual Agents SDK 0.8.4 on user's interpreter.

Run after requirements install:
    python -m unittest tests.test_sdk_runtime_smoke -v

Constructs a real Agent and tools but DOES NOT run Runner or open a network connection.
The test is skipped in build environments without the actual SDK installed.
"""
import importlib.util
import unittest


class TestRealSDKConstruction(unittest.TestCase):
    @unittest.skipUnless(importlib.util.find_spec('agents'),
                         'openai-agents not installed in this offline build environment')
    def test_official_sdk_imports_and_agent_construction_without_api_request(self):
        from agents import Agent, Runner, RunConfig, ModelSettings, function_tool, set_tracing_disabled
        from agents.models.openai_chatcompletions import OpenAIChatCompletionsModel
        from openai import AsyncOpenAI
        import inspect

        @function_tool
        def check_geometry(item_id: str) -> str:
            """Read a locally stored CAD geometry item by its identifier."""
            return 'local_geometry:' + item_id

        set_tracing_disabled(True)
        client = AsyncOpenAI(
            api_key='sk-offline-construction-no-network',
            base_url='https://api.deepseek.com',
            max_retries=0,
            timeout=5.0,
        )
        try:
            model = OpenAIChatCompletionsModel(model='deepseek-flash', openai_client=client)
            settings = ModelSettings(
                max_tokens=512,
                extra_args={'extra_body': {'thinking': {'type': 'disabled'}}},
            )
            agent = Agent(name='CAVAI SDK import smoke',
                          instructions='Do not call API; construction test only.',
                          model=model, tools=[check_geometry], model_settings=settings)
            config = RunConfig(tracing_disabled=True)
            self.assertEqual(agent.name, 'CAVAI SDK import smoke')
            self.assertEqual(len(agent.tools), 1)
            self.assertTrue(config.tracing_disabled)
            self.assertTrue(inspect.iscoroutinefunction(Runner.run))
        finally:
            import asyncio
            asyncio.run(client.close())


if __name__ == '__main__':
    unittest.main()
