"""No paid API calls: category Skill loading, guarded rule reads, fastener evidence tool."""
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from agent import sdk_agent
from skills.registry import list_skills, load_skill, read_skill_reference
from agent import usage_ledger


class TestCategorySkills(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.ledger_patch = patch.object(usage_ledger, 'LEDGER_PATH', Path(self.tmp.name) / 'events.jsonl')
        self.ledger_patch.start()

    def tearDown(self):
        self.ledger_patch.stop()
        self.tmp.cleanup()

    def test_three_category_skills_are_bundled_not_downloaded(self):
        names = {s['name'] for s in list_skills()}
        self.assertTrue({'fastener-review', 'fixture-review', 'manufacturing-dfm-review'} <= names)
        for name in ('fastener-review', 'fixture-review', 'manufacturing-dfm-review'):
            item = load_skill(name)
            self.assertTrue(item['content'].strip())
            self.assertTrue(item['reference_paths'])
            # The installed Skills are on disk, not fetched from remote GitHub at runtime.
            self.assertTrue(item['description'])
            self.assertLess(len(item['content']), 5000)

    def test_skill_reference_only_inside_references_directory(self):
        ref = read_skill_reference('fastener-review', 'checklist.md')
        self.assertIn('Fastener-specific', ref['content'])
        with self.assertRaises(ValueError):
            read_skill_reference('fastener-review', '../SKILL.md')
        with self.assertRaises(ValueError):
            read_skill_reference('fastener-review', '../../agent/sdk_agent.py')

    def _tools(self):
        module = types.ModuleType('agents')
        module.function_tool = lambda f: f
        inspection = {'status': 'ok', 'geometry': {
            'status': 'ok', 'solid_count': 1,
            'cylindrical_face_counts': {'inner': 0, 'outer': 3, 'undetermined': 0},
            'hole_candidate_count': 0,
            'hole_candidates': [],
            'faces': [
                {'face_id': 'F-1', 'surface_type': 'cylinder', 'cylindrical_side': 'outer'},
                {'face_id': 'F-2', 'surface_type': 'cylinder', 'cylindrical_side': 'outer'},
                {'face_id': 'F-3', 'surface_type': 'cylinder', 'cylindrical_side': 'outer'},
            ]}}
        loaded, queried, trace = set(), set(), []
        with patch.dict(sys.modules, {'agents': module}):
            methods = sdk_agent._make_tools(inspection, {'solid_count': 1}, 'offline-test',
                                            trace, loaded, queried)
        return {method.__name__: method for method in methods}, loaded, queried, trace

    def test_agents_tools_can_load_skill_and_read_rule_on_demand(self):
        methods, loaded, queried, trace = self._tools()
        before = json.loads(methods['read_skill_reference']('fastener-review', 'checklist.md'))
        self.assertIn('error', before)
        loaded_skill = json.loads(methods['load_skill']('fastener-review'))
        self.assertEqual(loaded_skill['name'], 'fastener-review')
        self.assertIn('checklist.md', loaded_skill['references_available'])
        after = json.loads(methods['read_skill_reference']('fastener-review', 'checklist.md'))
        self.assertNotIn('error', after)
        self.assertIn('content', after)
        self.assertIn('fastener-review', loaded)
        # A third request for identical arguments is blocked, preventing tool spam.
        third = json.loads(methods['read_skill_reference']('fastener-review', 'checklist.md'))
        self.assertTrue(third.get('duplicate_tool_call'))

    def test_fastener_query_returns_real_counts_but_no_invented_verdict(self):
        methods, loaded, queried, trace = self._tools()
        response = json.loads(methods['check_fastener_hole_evidence']())
        self.assertEqual(response['solid_count'], 1)
        self.assertEqual(response['inner_cylindrical_faces'], 0)
        self.assertEqual(response['outer_cylindrical_faces'], 3)
        self.assertEqual(response['hole_candidate_count'], 0)
        self.assertEqual(response['outer_face_sample_ids'], ['F-1','F-2','F-3'])
        self.assertNotIn('pass', response)
        self.assertNotIn('fail', response)
        self.assertIn('FASTENER-HOLE-EVIDENCE', queried)
        self.assertTrue(any(t['tool'] == 'check_fastener_hole_evidence' and t['ok'] for t in trace))
