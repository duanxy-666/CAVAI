@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title CAVAI 0.1.12 - Local CAD Agent
set "PYTHON_EXE=python"
if exist ".venv\Scripts\python.exe" set "PYTHON_EXE=.venv\Scripts\python.exe"
if exist "venv\Scripts\python.exe" set "PYTHON_EXE=venv\Scripts\python.exe"
echo.
echo ========= CAVAI 0.1.12 / Python 3.9 =========
%PYTHON_EXE% --version
if errorlevel 1 (
  echo Could not find Python. Select your Python 3.9 interpreter in PyCharm.
  pause
  exit /b 1
)
%PYTHON_EXE% -c "import fastapi, uvicorn, dotenv, httpx, agents; from openai import AsyncOpenAI"
if errorlevel 1 (
  echo.
  echo Dependencies missing. Run:
  echo   python -m pip install -r requirements.txt
  echo   python -m pip install -r requirements-catia.txt
  echo Then re-run this script.
  pause
  exit /b 1
)
echo.
echo Opening local CAVAI server. Ctrl+Left Click URL printed below.
%PYTHON_EXE% run.py
pause
