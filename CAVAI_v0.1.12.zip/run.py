from __future__ import print_function

import argparse
import sys
import socket
import threading
import webbrowser

import uvicorn


def port_is_available(host, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        sock.close()


def choose_port(host, preferred):
    for port in range(preferred, preferred + 20):
        if port_is_available(host, port):
            return port
    raise RuntimeError("8000-8019端口均被占用，请关闭旧服务或使用 --port 指定其他端口。")



def check_httpx_openai_compatibility():
    try:
        import openai
        import httpx
        openai_version = getattr(openai, "__version__", "unknown")
        httpx_version = getattr(httpx, "__version__", "unknown")
        try:
            from packaging.version import Version
            incompatible = (
                openai_version == "1.30.1"
                and Version(httpx_version) >= Version("0.28.0")
            )
        except Exception:
            incompatible = (openai_version == "1.30.1" and httpx_version.startswith("0.28"))
        print(" OpenAI SDK     : {}".format(openai_version))
        print(" HTTPX          : {}".format(httpx_version))
        if incompatible:
            print("")
            print("ERROR: openai==1.30.1 is incompatible with httpx>=0.28.0.")
            print("Run this command in the SAME PyCharm Terminal / interpreter:")
            print('python -m pip install --force-reinstall "httpx==0.27.2"')
            print("Then restart CAVAI.")
            raise SystemExit(1)
    except ImportError:
        # The normal requirements installer or Python traceback will explain missing packages.
        pass


def check_cad_geometry_dependencies():
    try:
        import OCP
        print(" Open CASCADE : installed")
    except Exception as exc:
        print(" Open CASCADE : MISSING - {}".format(exc))
        print(" Run: python -m pip install -r requirements-catia.txt")

def main():
    if sys.version_info < (3, 9):
        raise SystemExit("CAVAI 0.1.12 需要 Python 3.9 或更新版本。")
    parser = argparse.ArgumentParser(description="Start CAVAI V0.1.12-agent-sdk local web app.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--open-browser", action="store_true", help="Also open the browser automatically.")
    args = parser.parse_args()

    port = choose_port(args.host, args.port)
    url = "http://{}:{}".format(args.host, port)

    print("")
    print("============================================================")
    print(" CAVAI V0.1.12-agent-sdk - Local CAD Design Review Agent")
    print("============================================================")
    print(" Project folder : {}".format(__file__))
    print(" Local URL      : {}".format(url))
    print(" Tip            : In PyCharm Terminal, Ctrl+Left Click the URL.")
    print(" Stop server    : Ctrl+C")
    if port != args.port:
        print(" Note           : Port {} was busy; using {} instead.".format(args.port, port))
    print("============================================================")
    print("", flush=True)

    check_httpx_openai_compatibility()
    check_cad_geometry_dependencies()

    # Import app only after printing startup guidance so import failures are visible.
    from main import app

    if args.open_browser:
        timer = threading.Timer(1.0, lambda: webbrowser.open(url))
        timer.daemon = True
        timer.start()

    uvicorn.run(app, host=args.host, port=port, log_level="info", access_log=True)


if __name__ == "__main__":
    main()
