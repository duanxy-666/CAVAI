## CAVAI_v0.1.12 · 分类Skill补充（保持 0.1.12 版本号）

- 增加紧固件/孔、夹具、制造性三个专用Skill和按需加载参考文件。
- Agent新增`read_skill_reference`与`check_fastener_hole_evidence`工具，结果来自本地几何，不能声称更高级力学或DFM算法已集成。
- 补充开源方法出处和真实复用范围；不新增Benchmark打分服务。
- 继续沿用OpenAI Agents SDK 0.8.4、Python 3.9目标、Token账本及多轮工具调用。

# CAVAI 更新日志

## 0.1.12 — Python 3.9 / OpenAI Agents SDK

1. 正式将 Agent 引擎更换为 **`openai-agents==0.8.4`**，使用其 `Runner.run` 与 `function_tool` 完成多轮工具调用。删除旧 `LangChain/create_agent` 入口和自写 Agent 循环。
2. 保留 CATIA V5 COM、OCP STEP解析、结构化几何查询、所有本地Skill、原聊天网页与Logo。
3. Agent 自主加载 `skills/*/SKILL.md`，调用本地 Python 工具查询真实 CAD 几何，再直接输出 Markdown 工程报告；Python 保存最终 Agent 原文，不暴露 `save_review_report` 函数工具。
4. 将逐笔 Token 日志放到 HTTPX 请求/响应钩子：真实发出前记录，收到 usage 时记录 Input/Output/Cache，402/截断/超时明确终止。
5. 消除重复模型完整上传；多轮评测只发送有限几何摘要，详情经工具分页；完全相同的请求第三次拦截，无用户限制时仍有12次安全上限。
6. 视觉模型仅在单轮用途识别阶段传一张压缩截图，防止多轮不断重复发送图片；不需要图像才能完成评测。
7. 增加 Python 3.9 语法及 HTTP/OCP 离线回归测试和安装后不收费的 SDK smoke test。

**验收边界：** 本地离线闭环是模拟 SDK Runner / API，不代表在用户 Windows CATIA 和 DeepSeek 官方账户真实端到端成功。真实安装和支付服务联调需在相应环境验证。
