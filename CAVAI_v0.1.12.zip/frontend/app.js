const $ = (id) => document.getElementById(id);
let sessionId = null;
let currentFileId = null;
let currentFileName = null;
let busy = false;

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2800);
}

function addMessage(role, text, label) {
  $("welcomeBlock")?.remove();
  const row = document.createElement("div");
  row.className = "message-row " + role;
  const avatar = document.createElement("div");
  avatar.className = "message-avatar";
  avatar.textContent = role === "user" ? "我" : "C";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  row.appendChild(avatar);
  row.appendChild(bubble);
  $("messages").appendChild(row);
  $("messages").scrollTop = $("messages").scrollHeight;
}

function setBusy(value) {
  busy = value;
  $("sendBtn").disabled = value;
  $("recognizeBtn").disabled = value;
  $("sendBtn").querySelector("span").textContent = value ? "处理中" : "开始评测";
}

function setStep(index, state) {
  const steps = [...$("steps").querySelectorAll(".step")];
  if (!steps[index]) return;
  steps[index].classList.remove("active", "done");
  if (state) steps[index].classList.add(state);
  steps[index].querySelector("i").textContent = state === "done" ? "✓" : state === "active" ? "◌" : "○";
}

function resetSteps() {
  [...$("steps").querySelectorAll(".step")].forEach((step) => {
    step.classList.remove("active", "done");
    step.querySelector("i").textContent = "○";
  });
  $("reportPreview").classList.add("hidden");
}

function showUpload(file) {
  $("uploadPreview").classList.remove("hidden");
  $("uploadedName").textContent = file.name;
  $("uploadedMeta").textContent = "正在上传到本地工作空间…";
  $("emptyModel").classList.add("hidden");
  $("modelCard").classList.remove("hidden");
  $("sideFileName").textContent = file.name;
  $("sideFileSize").textContent = formatBytes(file.size);
  $("fileType").textContent = file.name.split(".").pop().toUpperCase();
  $("modelState").textContent = "正在上传";
  $("geometryJsonLink")?.classList.add("hidden");
}

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / 1024 / 1024).toFixed(1) + " MB";
}


function toggleLimits() {
  const enabled = $("limitsEnabled").checked;
  $("limitsFields").classList.toggle("hidden", !enabled);
  $("limitHint").textContent = enabled
    ? "已开启：超过设定的预估上限，就在发送前停止。"
    : "关闭：不设用户预算上限；仍保留最多8次付费请求的异常熔断。";
}
$("limitsEnabled").addEventListener("change", toggleLimits);

async function loadSettings() {
  try {
    const response = await fetch("/api/settings");
    const data = await response.json();
    $("apiBaseUrl").value = data.base_url || "https://api.deepseek.com";
    $("apiModel").value = data.model || "deepseek-flash";
    $("limitsEnabled").checked = data.limits_enabled === true;
    $("maxRequests").value = data.max_requests ?? 8;
    $("maxTurnTokens").value = data.max_turn_est_tokens ?? 30000;
    toggleLimits();
    $("apiKey").value = "";
    $("apiKey").placeholder = data.api_key_configured
      ? "密钥已保存；留空不更换" : "粘贴 DeepSeek 官方 API Key";
    $("settingsNote").textContent = data.configured
      ? "API 已配置：" + (data.api_key_masked || "密钥已保存")
      : "未配置 API。填入官方 API Key，然后保存即可。";
    $("apiStatus").textContent = data.configured ? "模型 API 已配置" : "尚未配置模型 API";
  } catch (error) {
    $("settingsNote").textContent = "读取设置失败：" + error.message;
  }
}

function openSettings() {
  $("settingsModal").classList.remove("hidden");
  loadSettings();
}
function closeSettings() {
  $("settingsModal").classList.add("hidden");
}
$("presetDeepSeekOfficial").addEventListener("click", () => {
  $("apiBaseUrl").value = "https://api.deepseek.com";
  $("apiModel").value = "deepseek-flash";
  $("settingsNote").style.color = "";
  $("settingsNote").textContent = "已选择 DeepSeek 官方配置。填写官方 API Key 并保存即可（此按钮不会发起收费调用）。";
});
$("settingsBtn").addEventListener("click", openSettings);
$("settingsTopBtn").addEventListener("click", openSettings);
$("closeSettings").addEventListener("click", closeSettings);
$("settingsModal").addEventListener("click", (event) => {
  if (event.target === $("settingsModal")) closeSettings();
});

function settingsPayload() {
  return {
    base_url: $("apiBaseUrl").value.trim(),
    api_key: $("apiKey").value.trim(),
    model: $("apiModel").value.trim(),
    limits_enabled: $("limitsEnabled").checked,
    max_requests: Number($("maxRequests").value),
    max_turn_est_tokens: Number($("maxTurnTokens").value)
  };
}

$("saveApiBtn").addEventListener("click", async () => {
  const payload = settingsPayload();
  $("settingsNote").textContent = "正在保存……";
  $("saveApiBtn").disabled = true;
  try {
    const response = await fetch("/api/settings", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "保存失败");
    $("apiKey").value = "";
    $("settingsNote").textContent = "✓ API设置已保存在本机。可以开始上传模型并评测。";
    $("settingsNote").style.color = "#21845b";
    $("apiStatus").textContent = "模型API 已配置";
    toast("API设置已保存");
    await loadSettings();
  } catch (error) {
    $("settingsNote").textContent = "保存失败：" + error.message;
    $("settingsNote").style.color = "#b54e45";
  } finally {
    $("saveApiBtn").disabled = false;
  }
});

$("fileInput").addEventListener("change", async (event) => {
  const file = event.target.files[0];
  if (!file) return;
  showUpload(file);
  const form = new FormData();
  form.append("file", file);
  try {
    const response = await fetch("/api/upload", { method: "POST", body: form });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "上传失败");
    currentFileId = data.file_id;
    currentFileName = data.filename;
    $("uploadedMeta").textContent = `${data.model_type} · 已保存到本机`;
    $("modelState").textContent = "已上传，等待评测";
    toast("模型已上传。可以描述设计目标，也可以直接发送“请先分析模型”。");
  } catch (error) {
    currentFileId = null;
    $("modelState").textContent = "上传失败";
    toast(error.message);
  }
});

$("removeFile").addEventListener("click", () => {
  currentFileId = null;
  currentFileName = null;
  $("uploadPreview").classList.add("hidden");
  $("modelCard").classList.add("hidden");
  $("geometryJsonLink")?.classList.add("hidden");
  $("emptyModel").classList.remove("hidden");
  $("fileInput").value = "";
});

async function sendMessage(textOverride, mode = "review") {
  if (busy) return;
  const text = (textOverride || $("messageInput").value).trim();
  if (!text && !currentFileId) {
    toast("请先输入消息或上传CAD模型。");
    return;
  }
  const message = text || "[未提供设计要求] 请先分析我上传的模型，推测可能的功能，并明确标注还不能确认的结构。";
  addMessage("user", (mode === "intent" ? "【识别模型用途】" : "【开始工程评测】") + message);
  $("messageInput").value = "";
  setBusy(true);
  resetSteps();
  setStep(0, "done");
  setStep(1, "active");

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session_id: sessionId, message, file_id: currentFileId, mode })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "请求失败");
    sessionId = data.session_id;
    setStep(0, "done");
    const geometryOk = data.inspection?.status === "ok" && data.inspection?.geometry?.status === "ok";
    if (geometryOk) setStep(1, "done");
    else setStep(1, "");
    const calledSkill = (data.tool_trace || []).some(item => item.tool === "load_skill" && item.ok);
    const lookedAtFacts = (data.tool_trace || []).some(item =>
      ["get_current_model_facts", "get_model_geometry_page", "search_model_geometry", "get_geometry_entity_by_id"].includes(item.tool) && item.ok);
    if (calledSkill) setStep(2, "done");
    if (calledSkill && lookedAtFacts) setStep(3, "done");
    if (data.report_id) setStep(4, "done");
    addMessage("assistant", data.reply);
    if (data.loaded_skills && data.loaded_skills.length) {
      toast("已从本地加载评测 Skill：" + data.loaded_skills.join("、"));
    }
    if (data.tool_trace && data.tool_trace.length) {
      const names = data.tool_trace.map(item => item.tool);
      addMessage("assistant", "本机Skill/几何工具执行记录：" + data.tool_trace.map(x =>
        `${x.ok ? "✓" : "×"} ${x.tool}${x.ok ? "" : "（失败）"}`).join(" → "));
    }
    if (data.inspection) {
      const geometry = data.inspection.geometry;
      if (data.inspection.status !== "ok") {
        $("modelState").textContent = "CATIA读取失败：" + (data.inspection.error || "请查看检查详情");
        $("geometryJsonLink")?.classList.add("hidden");
      } else if (geometry && geometry.status === "ok") {
        $("modelState").textContent =
          "B-Rep解析成功 · Body " + (geometry.catia_body_count ?? (data.inspection.document_type === "CATPRODUCT" ? "装配" : "?")) +
          " · Solid " + geometry.solid_count +
          " · Face " + geometry.face_count +
          " · Edge " + geometry.edge_count +
          " · 孔候选 " + geometry.hole_candidate_count;
        if ($("geometryJsonLink") && currentFileId) {
          $("geometryJsonLink").href = "/api/models/" + encodeURIComponent(currentFileId) + "/geometry";
          $("geometryJsonLink").classList.remove("hidden");
        }
      } else if (geometry) {
        $("modelState").textContent = "CATIA已读取，但B-Rep解析失败：" + (geometry.error || "未知错误");
        $("geometryJsonLink")?.classList.add("hidden");
      } else {
        $("modelState").textContent = "CATIA读取成功（基础信息）";
      }
    }
    if (data.report) renderReport(data.report);
    if (data.usage) {
      const u = data.usage;
      const cost = "实际费用请查看 DeepSeek 官方账单";
      addMessage("assistant", `本轮API账单：${u.calls} 次请求 · 输入 ${u.prompt_tokens} Token · 输出 ${u.completion_tokens} Token · ${cost} · 追踪ID ${u.turn_id}`);
      refreshUsageMini();
    }
    if (data.provider === "local_geometry_block") toast("CAD 解析未完成，未调用付费 API。");
    if (data.evidence_save_error) addMessage("assistant", "注意：本地几何证据保存失败：" + data.evidence_save_error);
    if (data.provider === "api_error") toast("模型API调用失败，已记录账本；请核对服务商账单。");
  } catch (error) {
    addMessage("assistant", "本次请求未完成：" + error.message);
    toast(error.message);
  } finally {
    setBusy(false);
  }
}

$("recognizeBtn").addEventListener("click", () => sendMessage(undefined, "intent"));
$("viewInput").addEventListener("change", async event => {
  const file = event.target.files[0];
  if (!file) return;
  if (!currentFileId) { toast("请先上传CAD模型，再上传可选视图"); return; }
  const form = new FormData(); form.append("file", file);
  try {
    const response = await fetch("/api/models/" + encodeURIComponent(currentFileId) + "/view", {method: "POST", body: form});
    const info = await response.json();
    if (!response.ok) throw new Error(info.detail || "视图上传失败");
    toast(info.vision_usable ? "视图已存本机；点击“识别用途”时最多发送一次" : "视图已存本机；当前API视觉能力未知，将仅发送文本证据");
  } catch (error) { toast(error.message); }
});

$("sendBtn").addEventListener("click", () => sendMessage());
$("messageInput").addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
});
$("messageInput").addEventListener("input", function () {
  this.style.height = "auto";
  this.style.height = Math.min(this.scrollHeight, 120) + "px";
});
document.querySelectorAll(".suggestion").forEach((button) => {
  button.addEventListener("click", () => sendMessage(button.dataset.prompt));
});

function renderReport(report) {
  if (!report) return;
  $("reportPreview").classList.remove("hidden");
  const status = report.overall_status || report.verdict || "inconclusive";
  const labels = {
    pass: "评测通过",
    fail: "存在不符合项",
    partial: "部分完成",
    inconclusive: "证据不足，无法定论"
  };
  $("verdictText").textContent = labels[status] || status;
  $("verdictNote").textContent = report.summary || report.title || "检查结果";

  const list = $("findingList");
  list.innerHTML = "";
  if (report.markdown_report) {
    $("verdictText").textContent = report.report_status === "partial" ? "Agent报告（部分完成）" : "Agent已生成报告";
    $("verdictNote").textContent = "由所选模型实际生成，并非预置答案";
    const md = document.createElement("div");
    md.className = "agent-markdown-report";
    md.textContent = report.markdown_report;
    list.appendChild(md);
  }
  // Show actual engineering requirements before findings. The model compares
  // the user's intended function with locally measured B-Rep evidence.
  const requirements = report.requirements || [];
  if (requirements.length) {
    const heading = document.createElement("div");
    heading.className = "requirement-heading";
    heading.textContent = "设计要求与实际几何对照";
    list.appendChild(heading);
    requirements.forEach(req => {
      const line = document.createElement("div");
      line.className = "requirement-row";
      const state = document.createElement("span");
      const status = req.status || "not_checked";
      state.className = "requirement-status " + status;
      state.textContent = ({pass:"已验证符合", fail:"已确认不符合", partial:"部分符合",
        not_checked:"尚未验证", not_applicable:"不适用"})[status] || "待验证";
      const subject = document.createElement("b");
      subject.textContent = req.requirement || "未列明要求";
      const proof = document.createElement("small");
      proof.textContent = "实测依据：" + (req.evidence || "目前没有对应的几何证据");
      line.append(state, subject, proof);
      list.appendChild(line);
    });
  }
  const findings = report.findings || [];
  if (findings.length) {
    const heading = document.createElement("div");
    heading.className = "requirement-heading";
    heading.textContent = "问题及修改建议";
    list.appendChild(heading);
  }
  findings.forEach((finding) => {
    const item = document.createElement("div");
    item.className = "finding";
    const severity = document.createElement("span");
    severity.className = "severity " + (finding.severity || "medium");
    severity.textContent = ({critical:"严重", high:"高风险", medium:"中风险", low:"低风险", info:"提示"})[finding.severity] || "待关注";
    const title = document.createElement("b");
    title.textContent = finding.title || "未命名问题";
    const detail = document.createElement("small");
    detail.textContent = (finding.detail || "") + (finding.recommendation ? " 建议：" + finding.recommendation : "");
    item.append(severity, title, detail);
    list.appendChild(item);
  });

  let link = $("reportDownloadLink");
  if (!link) {
    link = document.createElement("a");
    link.id = "reportDownloadLink";
    link.className = "report-download";
    link.textContent = "下载 Agent 报告 Markdown ↓";
    $("reportPreview").appendChild(link);
  }
  if (report.report_id) {
    link.href = report.markdown_report
      ? "/api/reports/" + encodeURIComponent(report.report_id) + "/download/markdown"
      : "/api/reports/" + encodeURIComponent(report.report_id) + "/download";
    link.classList.remove("hidden");
  } else {
    link.classList.add("hidden");
  }
}

$("newChatBtn").addEventListener("click", () => {
  sessionId = null;
  currentFileId = null;
  currentFileName = null;
  $("messages").innerHTML = "";
  $("messages").appendChild(createWelcome());
  $("uploadPreview").classList.add("hidden");
  $("modelCard").classList.add("hidden");
  $("geometryJsonLink")?.classList.add("hidden");
  $("emptyModel").classList.remove("hidden");
  $("fileInput").value = "";
  resetSteps();
  toast("已创建新会话");
});

function createWelcome() {
  const wrap = document.createElement("div");
  wrap.className = "welcome-block";
  wrap.innerHTML = `<div class="welcome-mark"><img src="/static/brand_logo.png" alt=""></div>
  <div class="welcome-kicker">WELCOME TO CAVAI</div><h2>你的设计意图，由你定义。</h2>
  <p>上传 CATIA 模型并描述设计要求；也可以不输入要求，让 CAVAI 先分析模型并提出功能假设。</p>
  <div class="welcome-note">
    <span>01</span><div><b>你定义目标</b><small>不预设固定产品类型</small></div>
    <span>02</span><div><b>AI读取模型</b><small>依据实际可获取的CATIA数据</small></div>
    <span>03</span><div><b>证据驱动评测</b><small>区分已验证、未验证和不符合项</small></div>
  </div>`;
  return wrap;
}

$("apiStatus").textContent = "本地服务在线";
fetch("/api/health").then(r => r.json()).then(data => {
  $("apiStatus").textContent = data.llm_configured ? "模型API 已配置" : "尚未配置模型API";
}).catch(() => $("apiStatus").textContent = "服务连接异常");
loadSettings();



function fmtNum(value) { return typeof value === "number" ? value.toLocaleString("zh-CN") : "未知"; }
function fmtCost(value) { return typeof value === "number" ? "￥" + value.toFixed(5) : "未知"; }
async function refreshUsageMini() {
  try {
    const response = await fetch("/api/usage/summary?limit=100");
    const data = await response.json();
    const s = data.all_time;
    $("usageMini").textContent = `成功 ${s.completed_requests} 次 · 失败 ${s.failed_requests} 次 · 发送前拦截 ${s.blocked_before_send} 次 · 输入 ${fmtNum(s.prompt_tokens_reported)} / 输出 ${fmtNum(s.completion_tokens_reported)} Token · 实际扣费请核对 DeepSeek 账单`;
  } catch (e) { $("usageMini").textContent = "账本读取异常：" + e.message; }
}
async function showUsageModal() {
  $("usageModal").classList.remove("hidden");
  const overview = $("usageOverview");
  const listing = $("usageLogTable");
  overview.textContent = "正在读取本地日志……";
  try {
    const response = await fetch("/api/usage/summary?limit=140");
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "读取失败");
    const s = data.all_time;
    overview.textContent = `完成 ${s.completed_requests} · 失败 ${s.failed_requests} · 发送前拦截 ${s.blocked_before_send} · 待确认 ${s.pending_or_interrupted} · 输入 ${fmtNum(s.prompt_tokens_reported)} · 输出 ${fmtNum(s.completion_tokens_reported)} · 使用量/实际扣费无法确认的请求 ${s.unknown_cost_requests}`;
    listing.innerHTML = "";
    const table = document.createElement("table");
    table.className = "ledger-table";
    const header = document.createElement("tr");
    ["时间 (UTC)", "事件", "请求 ID", "Input / Output / Cache", "费用状态", "结果 / 说明"].forEach(text => {
      const cell = document.createElement("th"); cell.textContent = text; header.appendChild(cell);
    });
    table.appendChild(header);
    const tracked = new Set(["api_request_started", "api_request_completed", "api_request_failed", "budget_blocked", "local_tool_executed", "compatibility_switch"]);
    (data.events || []).filter(ev => tracked.has(ev.event)).forEach(ev => {
      const tr = document.createElement("tr");
      const values = [
        ev.time_utc?.replace("T", " ").slice(0,19) || "-",
        ({api_request_started:"请求已发送", api_request_completed:"请求完成", api_request_failed:"请求失败", budget_blocked:"预算拦截", local_tool_executed:"本地工具", compatibility_switch:"兼容切换"})[ev.event] || ev.event,
        `${ev.mode || ""} ${ev.request_id || ev.turn_id || ""}`,
        ev.event === "api_request_completed" ? `${fmtNum(ev.prompt_tokens)} / ${fmtNum(ev.completion_tokens)} / ${fmtNum(ev.cached_input_tokens)}` : (ev.estimated_input_tokens ? `预计输入 ${ev.estimated_input_tokens}` : "—"),
        ev.event === "api_request_completed" ? "以官方账单为准" : "—",
        ev.error || ev.reason || (ev.tool ? `${ev.tool} · ${ev.ok ? "成功" : "失败"}` : ev.billing_status || ev.finish_reason || "—")
      ];
      values.forEach(value => { const td = document.createElement("td"); td.textContent = String(value); tr.appendChild(td); });
      table.appendChild(tr);
    });
    listing.appendChild(table);
  } catch (error) { overview.textContent = "读取失败：" + error.message; }
}
$("usageBtn").addEventListener("click", showUsageModal);
$("usageSideBtn").addEventListener("click", showUsageModal);
$("closeUsage").addEventListener("click", () => $("usageModal").classList.add("hidden"));
$("refreshUsage").addEventListener("click", showUsageModal);
$("usageModal").addEventListener("click", event => { if (event.target === $("usageModal")) $("usageModal").classList.add("hidden"); });
refreshUsageMini();
