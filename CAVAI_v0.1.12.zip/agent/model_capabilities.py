"""Free, conservative model capability lookup. Never probes the network for vision support.

An arbitrary OpenAI-compatible API does not expose a standard, reliable vision-capability endpoint.
Only pass images for verified model families. Unknown models always get textual B-Rep evidence.
"""
from urllib.parse import urlsplit
from typing import Dict, Any


def detect_model_capabilities(base_url: str, model: str) -> Dict[str, Any]:
    host = (urlsplit(base_url).hostname or '').lower()
    name = (model or '').strip().lower()
    official_deepseek = host == 'api.deepseek.com'
    if official_deepseek and name in {'deepseek-flash', 'deepseek-v4-flash', 'deepseek-v4-flash-vision-exp'}:
        return {'vision': True, 'status': 'verified', 'reason': 'DeepSeek官方Flash视觉文档', 'tools': True}
    if official_deepseek and name == 'deepseek-v4-pro':
        return {'vision': False, 'status': 'unknown', 'reason': '没有为当前模型确认图像输入，保守使用文本', 'tools': True}
    if host == 'api.openai.com' and (name.startswith(('gpt-4o','gpt-4.1','gpt-5','gpt-6'))):
        return {'vision': True, 'status': 'verified_family', 'reason': 'OpenAI多模态模型系列', 'tools': True}
    return {'vision': False, 'status': 'unknown', 'reason': '未能无额外计费地确认；自动使用文字几何证据', 'tools': None}
