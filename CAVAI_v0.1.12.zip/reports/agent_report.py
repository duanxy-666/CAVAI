"""Persist the actual LLM-created final report; never ask the LLM to call a save-file tool.

A report file exists only after a real model response. No synthetic answers are written.
"""
from __future__ import annotations
import json
import os
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

from reports.store import REPORT_DIR


def save_agent_markdown(*, markdown: str, filename: str, file_id: str,
                        model_id: str, loaded_skills: list,
                        tool_trace: list, geometry_fact_ids: list,
                        usage: dict, status: str = 'completed') -> Dict[str, Any]:
    content = (markdown or '').strip()
    if not content:
        raise ValueError('模型未返回报告正文；不能凭空生成报告。')
    if status not in {'completed', 'partial'}:
        raise ValueError('不支持的报告状态')
    ident = uuid.uuid4().hex
    payload = {
        'report_id': ident,
        'title': 'CAVAI Agent CAD 工程评测报告',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'report_source': 'agent_llm_output',
        'report_status': status,
        'overall_status': 'inconclusive',  # no unconditional engineering pass verdict
        'summary': content[:2000],
        'markdown_report': content,
        'requirements': [],  # the full actual requirements are in markdown_report
        'findings': [],
        'model_filename': filename,
        'model_file_id': file_id,
        'model_id': model_id,
        'actual_skill_names': sorted(set(loaded_skills)),
        'actual_tool_trace': tool_trace[:40],
        'queried_evidence_ids': sorted(set(geometry_fact_ids)),
        'usage': usage,
    }
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    target_json = REPORT_DIR / f'{ident}.json'
    target_md = REPORT_DIR / f'{ident}.md'
    scratch_json = target_json.with_suffix('.json.tmp')
    scratch_md = target_md.with_suffix('.md.tmp')
    try:
        scratch_md.write_text(content + '\n', encoding='utf-8')
        scratch_json.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(scratch_md, target_md)
        os.replace(scratch_json, target_json)
    finally:
        scratch_md.unlink(missing_ok=True)
        scratch_json.unlink(missing_ok=True)
    return {'report_id': ident, 'report': payload,
            'download_url': f'/api/reports/{ident}/download/markdown',
            'report_status': status}
