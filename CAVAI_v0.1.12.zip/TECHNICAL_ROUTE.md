# CAVAI_v0.1.12 技术路线（代码对应表）

## 核心闭环

1. 用户在本机 FastAPI 网页上传 CATPart/CATProduct/STEP，设计要求可以为空；也可以先点击“识别用途”并补充要求。
2. `cad/format_router.py` 识别文件：STEP/STP 直接由 `cad/brep_analyzer.py` 使用 OCP 解析；CATIA原生文件由 `cad/catia_reader.py` 通过本机 CATIA V5/pycatia 读取并导出临时 STEP，最后同样进入 OCP。
3. 解析结果由 `cad/evidence_store.py` 保存在 `data/evidence`；只将有限长度的几何摘要输入模型，不会把原始 CAD 文件或完整 B-Rep 反复发送给云端。
4. `agent/sdk_agent.py` 使用 **OpenAI Agents SDK 0.8.4** 的 `Agent`、`Runner.run`、`function_tool`（Python3.9候选版本）。由SDK维护模型/工具的多轮调用，不存在CAVAI自制的LLM轮询循环。
5. 用户填自己的Chat Completions兼容API地址、模型和Key。根据已确认的模型能力，识别用途时可以附加小幅截图；未知能力默认仅发送结构化文字。模型 API 不直接接收CATPart二进制，除非未来有确认支持的接口与用户许可。
6. Agent 按任务从 `skills/*/SKILL.md` 选择本地Skill（通用、紧固件、夹具、制造性等）；需要详细规则时调用 `read_skill_reference`，只读已安装Skill的 `references` 文档。**用户无须登录GitHub或安装Skill**。
7. Agent 需要证据时调用 `get_current_model_facts`、`check_fastener_hole_evidence`、`search_model_geometry`、`get_geometry_entity_by_id`、`get_model_geometry_page` 等只读Python工具，多轮查询。证据不足则明确标记未验证，不能强行评估力学或装配配合。
8. Agent 输出 Markdown 格式工程评测报告（用途假设、几何依据、功能符合性、风险、建议），由 `reports/agent_report.py` 原样保存为 `.md` 和 `.json`，不再要求大模型调用 `save_review_report({})`。
9. 网页显示报告、提供下载，`data/usage/events.jsonl` 保存 HTTP 请求、Token 及异常。HTTPX + OpenAI SDK 的自动重试关闭；本地工具缓存、请求去重及硬性最多12次API请求熔断。

## 技术来源与已实现范围

- 运行时框架：OpenAI Agents SDK 0.8.4，PyPI: https://pypi.org/project/openai-agents/0.8.4/
- Skill格式：Agent Skills spec https://github.com/agentskills/agentskills/blob/main/docs/specification.mdx
- 参考流程：earthtojake/text-to-cad DFM Skill https://github.com/earthtojake/text-to-cad/blob/main/skills/dfm/SKILL.md
- 参考工程审查：dooosp/freecad-automation https://github.com/dooosp/freecad-automation
- CATIA控制：evereux/pycatia https://github.com/evereux/pycatia

**没有**把 FreeCAD-automation 或 text-to-cad 的独立CAD引擎、有限元求解器或DFM脚本移植到CAVAI。三个分类Skill是本项目针对现有几何工具原创编写的适配说明和检查方法，已注明来源和未实现的量化能力。没有引入单独Benchmark模块。

## 环境和验收事实

目标用户环境为 Windows、Python 3.9 64位、CATIA V5、可安装 OCP/pycatia/OpenAI Agents SDK。第一版以**真实Agent的报告输出**为目标，但不以模型评测正确率作无根据保证。

开发环境当前没有安装 `openai-agents==0.8.4`，也没有Windows CATIA和用户DeepSeek Key，因此没有确认“真实 SDK/DeepSeek/CATIA 端到端报告成功”。项目包含零API费用的 smoke test 与离线模拟闭环测试。需要在用户本机完成一次真实联调；试验时先保留预算熔断与账本。
