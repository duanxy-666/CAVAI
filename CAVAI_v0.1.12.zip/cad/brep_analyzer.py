from __future__ import annotations

import math
from pathlib import Path
from typing import Any, Dict, List, Optional

def _xyz(point):
    return [float(point.X()), float(point.Y()), float(point.Z())]

def _vector(direction):
    return [float(direction.X()), float(direction.Y()), float(direction.Z())]

def _center_of_mass(shape, mode):
    from OCP.BRepGProp import BRepGProp
    from OCP.GProp import GProp_GProps
    props = GProp_GProps()
    if mode == "face":
        BRepGProp.SurfaceProperties_s(shape, props)
    elif mode == "edge":
        BRepGProp.LinearProperties_s(shape, props)
    else:
        BRepGProp.VolumeProperties_s(shape, props)
    return float(props.Mass()), _xyz(props.CentreOfMass())

def _finite(value):
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except Exception:
        return None

def _axis_projection(point, origin, direction):
    delta = [point[i] - origin[i] for i in range(3)]
    t = sum(delta[i] * direction[i] for i in range(3))
    radial_vec = [delta[i] - t * direction[i] for i in range(3)]
    return t, math.sqrt(sum(v * v for v in radial_vec)), radial_vec

def _surface_name(kind, geomabs):
    names = [
        ("plane", "GeomAbs_Plane"), ("cylinder", "GeomAbs_Cylinder"),
        ("cone", "GeomAbs_Cone"), ("sphere", "GeomAbs_Sphere"),
        ("torus", "GeomAbs_Torus"), ("bezier_surface", "GeomAbs_BezierSurface"),
        ("bspline_surface", "GeomAbs_BSplineSurface"),
        ("surface_of_revolution", "GeomAbs_SurfaceOfRevolution"),
        ("surface_of_extrusion", "GeomAbs_SurfaceOfExtrusion"),
        ("offset_surface", "GeomAbs_OffsetSurface"),
    ]
    for label, attr in names:
        if kind == getattr(geomabs, attr, object()):
            return label
    return "other_surface"

def _curve_name(kind, geomabs):
    names = [
        ("line", "GeomAbs_Line"), ("circle", "GeomAbs_Circle"),
        ("ellipse", "GeomAbs_Ellipse"), ("hyperbola", "GeomAbs_Hyperbola"),
        ("parabola", "GeomAbs_Parabola"), ("bezier", "GeomAbs_BezierCurve"),
        ("bspline", "GeomAbs_BSplineCurve"), ("offset_curve", "GeomAbs_OffsetCurve"),
    ]
    for label, attr in names:
        if kind == getattr(geomabs, attr, object()):
            return label
    return "other_curve"

def _extract_edge(edge, edge_id, geomabs):
    from OCP.BRepAdaptor import BRepAdaptor_Curve
    adaptor = BRepAdaptor_Curve(edge)
    curve_type = _curve_name(adaptor.GetType(), geomabs)
    length, center = _center_of_mass(edge, "edge")
    record = {
        "edge_id": edge_id,
        "curve_type": curve_type,
        "length": length,
        "center_of_mass": center,
        "first_parameter": _finite(adaptor.FirstParameter()),
        "last_parameter": _finite(adaptor.LastParameter()),
    }
    try:
        if curve_type == "circle":
            circle = adaptor.Circle()
            record.update({
                "radius": float(circle.Radius()),
                "center": _xyz(circle.Location()),
                "axis_direction": _vector(circle.Axis().Direction()),
            })
        elif curve_type == "line":
            line = adaptor.Line()
            record.update({"origin": _xyz(line.Location()), "direction": _vector(line.Direction())})
        elif curve_type == "ellipse":
            ellipse = adaptor.Ellipse()
            record.update({
                "major_radius": float(ellipse.MajorRadius()),
                "minor_radius": float(ellipse.MinorRadius()),
                "center": _xyz(ellipse.Location()),
                "axis_direction": _vector(ellipse.Axis().Direction()),
            })
    except Exception as exc:
        record["parameter_error"] = str(exc)
    return record

def _extract_face(face, face_id, geomabs, topabs):
    from OCP.BRepAdaptor import BRepAdaptor_Surface
    adaptor = BRepAdaptor_Surface(face, True)
    surface_type = _surface_name(adaptor.GetType(), geomabs)
    area, center = _center_of_mass(face, "face")
    orientation = "FORWARD" if face.Orientation() == topabs.TopAbs_FORWARD else (
        "REVERSED" if face.Orientation() == topabs.TopAbs_REVERSED else "OTHER"
    )
    record = {
        "face_id": face_id,
        "surface_type": surface_type,
        "area": area,
        "center_of_mass": center,
        "orientation": orientation,
    }
    try:
        if surface_type == "plane":
            plane = adaptor.Plane()
            normal = _vector(plane.Axis().Direction())
            if face.Orientation() == topabs.TopAbs_REVERSED:
                normal = [-x for x in normal]
            record.update({"plane_origin": _xyz(plane.Location()), "normal": normal})
        elif surface_type == "cylinder":
            cylinder = adaptor.Cylinder()
            record.update({
                "radius": float(cylinder.Radius()),
                "diameter": float(cylinder.Radius()) * 2.0,
                "axis_origin": _xyz(cylinder.Axis().Location()),
                "axis_direction": _vector(cylinder.Axis().Direction()),
            })
            # Classify concave/convex cylindrical faces from the oriented surface normal.
            from OCP.BRepLProp import BRepLProp_SLProps
            u = (float(adaptor.FirstUParameter()) + float(adaptor.LastUParameter())) / 2.0
            v = (float(adaptor.FirstVParameter()) + float(adaptor.LastVParameter())) / 2.0
            props = BRepLProp_SLProps(adaptor, u, v, 1, 1e-7)
            if props.IsNormalDefined():
                n = props.Normal()
                normal = [float(n.X()), float(n.Y()), float(n.Z())]
                if face.Orientation() == topabs.TopAbs_REVERSED:
                    normal = [-x for x in normal]
                point = _xyz(adaptor.Value(u, v))
                _, _, radial_vec = _axis_projection(point, record["axis_origin"], record["axis_direction"])
                dot = sum(normal[i] * radial_vec[i] for i in range(3))
                record["normal_dot_radial"] = dot
                record["cylindrical_side"] = "outer" if dot > 1e-7 else ("inner" if dot < -1e-7 else "undetermined")
            else:
                record["cylindrical_side"] = "undetermined"
        elif surface_type == "cone":
            cone = adaptor.Cone()
            record.update({
                "reference_radius": float(cone.RefRadius()),
                "semi_angle_degrees": math.degrees(float(cone.SemiAngle())),
                "axis_origin": _xyz(cone.Axis().Location()),
                "axis_direction": _vector(cone.Axis().Direction()),
            })
        elif surface_type == "sphere":
            sphere = adaptor.Sphere()
            record.update({"radius": float(sphere.Radius()), "center": _xyz(sphere.Location())})
        elif surface_type == "torus":
            torus = adaptor.Torus()
            record.update({
                "major_radius": float(torus.MajorRadius()),
                "minor_radius": float(torus.MinorRadius()),
                "center": _xyz(torus.Location()),
                "axis_direction": _vector(torus.Axis().Direction()),
            })
    except Exception as exc:
        record["parameter_error"] = str(exc)
    return record

def _detect_holes(faces, edges, edge_to_faces):
    face_by_id = {f["face_id"]: f for f in faces}
    edge_by_id = {e["edge_id"]: e for e in edges}
    holes = []
    for face in faces:
        if face.get("surface_type") != "cylinder" or face.get("cylindrical_side") != "inner":
            continue
        radius = face.get("radius")
        origin = face.get("axis_origin")
        direction = face.get("axis_direction")
        if not radius or not origin or not direction:
            continue

        circles = []
        for edge_id in face.get("edge_ids", []):
            edge = edge_by_id.get(edge_id, {})
            if edge.get("curve_type") != "circle" or edge.get("radius") is None:
                continue
            if abs(edge["radius"] - radius) > max(1e-3, radius * 1e-4):
                continue
            center = edge.get("center")
            axis = edge.get("axis_direction")
            if not center or not axis:
                continue
            axial, radial, _ = _axis_projection(center, origin, direction)
            parallel = abs(abs(sum(direction[i] * axis[i] for i in range(3))) - 1.0) < 1e-4
            if radial <= max(1e-3, radius * 1e-4) and parallel:
                circles.append({"edge_id": edge_id, "axial": axial, "adjacent_faces": edge_to_faces.get(edge_id, [])})

        groups = []
        for item in sorted(circles, key=lambda x: x["axial"]):
            if not groups or abs(item["axial"] - groups[-1]["axial"]) > 1e-3:
                groups.append({"axial": item["axial"], "items": [item]})
            else:
                groups[-1]["items"].append(item)

        cap_faces = []
        target_area = math.pi * radius * radius
        for group in groups:
            for circle in group["items"]:
                for adjacent_id in circle["adjacent_faces"]:
                    adjacent = face_by_id.get(adjacent_id, {})
                    if adjacent.get("surface_type") != "plane" or not adjacent.get("normal"):
                        continue
                    normal = adjacent["normal"]
                    if abs(abs(sum(normal[i] * direction[i] for i in range(3))) - 1.0) > 1e-3:
                        continue
                    area = adjacent.get("area")
                    # A planar blind-hole bottom is a disk bounded by this one circular edge.
                    if area is not None and 0.75 * target_area <= area <= 1.25 * target_area and len(adjacent.get("edge_ids", [])) == 1:
                        cap_faces.append(adjacent_id)

        positions = [g["axial"] for g in groups]
        if len(positions) >= 2 and cap_faces:
            classification, confidence = "blind_hole_candidate", "medium"
        elif len(positions) >= 2:
            classification, confidence = "through_hole_candidate", "medium"
        elif len(positions) == 1 and cap_faces:
            classification, confidence = "blind_cavity_candidate", "low"
        else:
            classification, confidence = "inner_cylindrical_surface_candidate", "low"

        holes.append({
            "candidate_id": "HC-{:04d}".format(len(holes) + 1),
            "source_face_id": face["face_id"],
            "topology_class": classification,
            "confidence": confidence,
            "radius": radius,
            "diameter": 2.0 * radius,
            "axis_origin": origin,
            "axis_direction": direction,
            "boundary_circle_edge_ids": sorted({x["edge_id"] for x in circles}),
            "boundary_axial_positions": positions,
            "estimated_depth": max(positions) - min(positions) if len(positions) >= 2 else None,
            "cap_face_ids": sorted(set(cap_faces)),
            "notes": "B-Rep拓扑候选，不等同于螺纹或标准孔语义已确认。",
        })
    return holes

def _shape_bbox(shape):
    """Axis-aligned envelope in millimeters, sourced from the STEP shape."""
    try:
        from OCP.Bnd import Bnd_Box
        from OCP.BRepBndLib import BRepBndLib
        bbox = Bnd_Box()
        bbox.SetGap(0.0)
        BRepBndLib.Add_s(shape, bbox)
        xmin, ymin, zmin, xmax, ymax, zmax = bbox.Get()
        return {
            "min": [float(xmin), float(ymin), float(zmin)],
            "max": [float(xmax), float(ymax), float(zmax)],
            "size": [float(xmax-xmin), float(ymax-ymin), float(zmax-zmin)]
        }
    except Exception:
        return None


def analyze_step_brep(step_path: str) -> Dict[str, Any]:
    try:
        from OCP.STEPControl import STEPControl_Reader
        from OCP.IFSelect import IFSelect_RetDone
        from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE, TopAbs_EDGE
        from OCP.TopExp import TopExp, TopExp_Explorer
        from OCP.TopTools import TopTools_IndexedMapOfShape
        from OCP.TopoDS import TopoDS
        from OCP.BRepGProp import BRepGProp
        from OCP.GProp import GProp_GProps
        from OCP.Interface import Interface_Static
        import OCP.GeomAbs as geomabs
        import OCP.TopAbs as topabs
    except Exception as exc:
        return {"status": "unavailable", "backend": "OCP", "error": "OCP未安装或导入失败。", "details": str(exc)}

    path = Path(step_path)
    if not path.exists():
        return {"status": "error", "backend": "OCP", "error": "STEP文件不存在。"}
    try:
        Interface_Static.SetCVal_s("xstep.cascade.unit", "MM")
    except Exception:
        pass

    reader = STEPControl_Reader()
    status = reader.ReadFile(str(path))
    if status != IFSelect_RetDone:
        return {"status": "error", "backend": "OCP", "error": "Open CASCADE无法读取STEP文件。"}
    if not reader.TransferRoots():
        return {"status": "error", "backend": "OCP", "error": "STEP文件没有可转移的几何根节点。"}
    shape = reader.OneShape()
    if shape.IsNull():
        return {"status": "error", "backend": "OCP", "error": "STEP中没有有效形状。"}

    face_map = TopTools_IndexedMapOfShape()
    edge_map = TopTools_IndexedMapOfShape()
    TopExp.MapShapes_s(shape, TopAbs_FACE, face_map)
    TopExp.MapShapes_s(shape, TopAbs_EDGE, edge_map)

    solids = []
    explorer = TopExp_Explorer(shape, TopAbs_SOLID)
    while explorer.More():
        solids.append(TopoDS.Solid_s(explorer.Current()))
        explorer.Next()

    solid_records = []
    face_to_solids = {}
    edge_to_solids = {}
    for si, solid in enumerate(solids, 1):
        sm_faces = TopTools_IndexedMapOfShape()
        sm_edges = TopTools_IndexedMapOfShape()
        TopExp.MapShapes_s(solid, TopAbs_FACE, sm_faces)
        TopExp.MapShapes_s(solid, TopAbs_EDGE, sm_edges)
        fids, eids = [], []
        for i in range(1, sm_faces.Extent() + 1):
            gi = face_map.FindIndex(sm_faces.FindKey(i))
            if gi > 0:
                fid = "F{:06d}".format(gi)
                fids.append(fid)
                face_to_solids.setdefault(gi, []).append("S{:04d}".format(si))
        for i in range(1, sm_edges.Extent() + 1):
            gi = edge_map.FindIndex(sm_edges.FindKey(i))
            if gi > 0:
                eid = "E{:06d}".format(gi)
                eids.append(eid)
                edge_to_solids.setdefault(gi, []).append("S{:04d}".format(si))
        from OCP.BRepGProp import BRepGProp
        from OCP.GProp import GProp_GProps
        props = GProp_GProps()
        BRepGProp.VolumeProperties_s(solid, props)
        solid_records.append({
            "solid_id": "S{:04d}".format(si),
            "volume": float(props.Mass()),
            "bounding_box_mm": _shape_bbox(solid),
            "center_of_mass": _xyz(props.CentreOfMass()),
            "face_count": len(fids),
            "edge_count": len(eids),
            "face_ids": fids,
            "edge_ids": eids,
        })

    edge_records = []
    for i in range(1, edge_map.Extent() + 1):
        edge = TopoDS.Edge_s(edge_map.FindKey(i))
        rec = _extract_edge(edge, "E{:06d}".format(i), geomabs)
        rec["solid_ids"] = edge_to_solids.get(i, [])
        edge_records.append(rec)

    face_records = []
    edge_to_faces = {}
    for i in range(1, face_map.Extent() + 1):
        face = TopoDS.Face_s(face_map.FindKey(i))
        rec = _extract_face(face, "F{:06d}".format(i), geomabs, topabs)
        rec["solid_ids"] = face_to_solids.get(i, [])
        local_edges = TopTools_IndexedMapOfShape()
        TopExp.MapShapes_s(face, TopAbs_EDGE, local_edges)
        rec["edge_ids"] = []
        for j in range(1, local_edges.Extent() + 1):
            gi = edge_map.FindIndex(local_edges.FindKey(j))
            if gi > 0:
                eid = "E{:06d}".format(gi)
                rec["edge_ids"].append(eid)
                edge_to_faces.setdefault(eid, []).append(rec["face_id"])
        face_records.append(rec)

    holes = _detect_holes(face_records, edge_records, edge_to_faces)
    face_counts, edge_counts = {}, {}
    for f in face_records:
        face_counts[f["surface_type"]] = face_counts.get(f["surface_type"], 0) + 1
    for e in edge_records:
        edge_counts[e["curve_type"]] = edge_counts.get(e["curve_type"], 0) + 1

    return {
        "status": "ok",
        "backend": "Open CASCADE OCP",
        "source_file": path.name,
        "coordinate_unit": "mm",
        "solid_count": len(solid_records),
        "bounding_box_mm": _shape_bbox(shape),
        "face_count": len(face_records),
        "edge_count": len(edge_records),
        "face_type_counts": face_counts,
        "edge_type_counts": edge_counts,
        "cylindrical_face_counts": {
            "inner": sum(1 for f in face_records if f.get("surface_type") == "cylinder" and f.get("cylindrical_side") == "inner"),
            "outer": sum(1 for f in face_records if f.get("surface_type") == "cylinder" and f.get("cylindrical_side") == "outer"),
            "undetermined": sum(1 for f in face_records if f.get("surface_type") == "cylinder" and f.get("cylindrical_side") == "undetermined"),
        },
        "hole_candidate_count": len(holes),
        "hole_candidates": holes,
        "solids": solid_records,
        "faces": face_records,
        "edges": edge_records,
        "method_notes": [
            "CATIA导出临时STEP，原始CATPart不修改。",
            "Body数量与Solid数量分开统计，不假设一一对应。",
            "内外圆柱面基于带方向的Face法向与圆柱径向向量点积。",
            "孔仅输出拓扑候选；不等同于螺纹或标准孔语义。",
        ],
    }
