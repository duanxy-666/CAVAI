from __future__ import annotations

import json
import os
import hashlib
import shutil
import tempfile
from pathlib import Path
from typing import Any, Dict, List

from cad.brep_analyzer import analyze_step_brep


def _get(obj, *names, default=None):
    for name in names:
        try:
            value = getattr(obj, name)
            if callable(value) and name.endswith("_call"):
                value = value()
            return value
        except Exception:
            continue
    return default


def _items(collection):
    if collection is None:
        return []
    try:
        return list(collection)
    except Exception:
        pass
    try:
        return list(collection.items())
    except Exception:
        pass
    count = _get(collection, "count", "Count", default=0)
    try:
        count = int(count)
    except Exception:
        count = 0
    result = []
    for index in range(1, count + 1):
        try:
            result.append(collection.item(index))
        except Exception:
            try:
                result.append(collection.Item(index))
            except Exception:
                break
    return result


def _name(obj, default):
    value = _get(obj, "name", "Name", default=default)
    return str(value or default)


def _raw(obj):
    return _get(obj, "com_object", default=obj)


def _saved_open_copy_same_as_upload(candidate, path: Path) -> bool:
    """Safely avoid CATIA 'same document identifier already open' errors.

    Never reuse an unrelated similarly named part. Reuse only a saved on-disk
    document whose actual bytes match the uploaded CAD part.
    """
    source = _get(candidate, "full_name", "FullName", default="")
    if not source or Path(str(source)).name.lower() != path.name.lower():
        return False
    if _get(candidate, "saved", "Saved", default=False) is not True:
        return False
    source_path = Path(str(source))
    if not source_path.is_file() or source_path.stat().st_size != path.stat().st_size:
        return False
    try:
        def digest(file_path):
            h = hashlib.sha256()
            with file_path.open("rb") as stream:
                for data in iter(lambda: stream.read(1024 * 1024), b""):
                    h.update(data)
            return h.digest()
        return digest(source_path) == digest(path)
    except (OSError, PermissionError):
        return False


def _read_bodies(part):
    bodies = _items(_get(part, "bodies", "Bodies"))
    output = []
    for body_index, body in enumerate(bodies, start=1):
        body_name = _name(body, "Body_{}".format(body_index))
        shapes = _items(_get(body, "shapes", "Shapes"))
        features = []
        for feature_index, shape in enumerate(shapes, start=1):
            features.append({
                "feature_id": "B{:03d}-F{:04d}".format(body_index, feature_index),
                "name": _name(shape, "Feature_{}".format(feature_index)),
                "wrapper_type": type(shape).__name__,
                "evidence_level": "CATIA feature-tree object; not B-Rep semantic proof",
            })
        output.append({
            "body_id": "BODY-{:04d}".format(body_index),
            "name": body_name,
            "feature_count": len(features),
            "features": features,
        })
    return output


def _read_product(product, depth=0, node_id="ROOT"):
    record = {
        "node_id": "ASM-" + node_id,
        "name": _name(product, "UnknownComponent"),
        "part_number": _get(product, "part_number", "PartNumber", default=""),
        "depth": depth,
        "children": [],
    }
    position = _get(product, "position", "Position")
    if position is not None:
        try:
            record["position"] = list(position.get_components())
        except Exception:
            try:
                values = [0.0] * 12
                position.GetComponents(values)
                record["position"] = values
            except Exception:
                record["position"] = None
    children = _items(_get(product, "products", "Products"))
    for i, child in enumerate(children, start=1):
        record["children"].append(_read_product(child, depth + 1, "{}-{}".format(node_id, i)))
    return record


def _export_temp_step(document, path: Path) -> Path:
    temp_dir = Path(tempfile.mkdtemp(prefix="cavai_step_"))
    step_path = temp_dir / (path.stem + "_cavai.stp")
    try:
        # pycatia Document.export_data(file_name: Path, file_type: str, overwrite=False)
        if hasattr(document, "export_data"):
            document.export_data(step_path, "stp", overwrite=True)
        else:
            raw_doc = _raw(document)
            raw_doc.ExportData(str(step_path), "stp")
        if not step_path.exists() or step_path.stat().st_size == 0:
            raise RuntimeError("CATIA导出STEP后没有生成有效文件。请确认CATIA支持STEP导出。")
        return step_path
    except Exception:
        shutil.rmtree(str(temp_dir), ignore_errors=True)
        raise


def _cleanup_temp_step(temp_step: Path) -> None:
    """Never delete a directory unless it is the one created by CAVAI in temp."""
    temp_root = Path(tempfile.gettempdir()).resolve()
    folder = temp_step.parent.resolve()
    if folder.parent == temp_root and folder.name.startswith("cavai_step_"):
        shutil.rmtree(str(folder), ignore_errors=True)


def _analyze_part_geometry(document, path: Path, body_records: List[Dict[str, Any]]) -> Dict[str, Any]:
    temp_step = None
    try:
        temp_step = _export_temp_step(document, path)
        geometry = analyze_step_brep(str(temp_step))
        if geometry.get("status") != "ok":
            return geometry

        geometry["catia_body_count"] = len(body_records)
        geometry["catia_bodies"] = body_records
        geometry["source_format"] = "CATPart exported temporarily to STEP"
        geometry["original_catpart_modified"] = False
        geometry["step_export_method"] = "CATIA Document.ExportData"
        geometry["geometry_scope_note"] = (
            "CATIA Body数量与STEP Solid数量分别报告；由于Boolean/Part Design结果和导出结构可能不同，"
            "当前不假设两者一一对应。"
        )

        json_path = path.parent / (path.stem + "_geometry.json")
        geometry["geometry_json_path"] = str(json_path)
        json_path.write_text(
            json.dumps(geometry, ensure_ascii=False, indent=2, default=str),
            encoding="utf-8",
        )
        return geometry
    except Exception as exc:
        return {
            "status": "error",
            "backend": "CATIA STEP export + OCP",
            "error": "CATPart已尝试读取，但临时STEP导出或B-Rep分析失败。",
            "details": str(exc),
            "catia_body_count": len(body_records),
        }
    finally:
        if temp_step is not None:
            _cleanup_temp_step(temp_step)


def _analyze_product_geometry(document, path: Path, assembly: Dict[str, Any]) -> Dict[str, Any]:
    """Export the assembled CATProduct to temporary STEP, then inspect its B-Rep.

    This is **assembly-level** geometry: it does not assert per-instance mappings,
    contact, constraints, mates or interferences. Those must remain unverified.
    """
    temp_step = None
    try:
        temp_step = _export_temp_step(document, path)
        geometry = analyze_step_brep(str(temp_step))
        if geometry.get("status") != "ok":
            return geometry
        geometry["source_format"] = "CATProduct assembly exported temporarily to STEP"
        geometry["original_catproduct_modified"] = False
        geometry["step_export_method"] = "CATIA Document.ExportData"
        geometry["geometry_scope_note"] = (
            "当前是整套CATProduct的装配级STEP B-Rep，能识别导出的实体和几何面，"
            "但未建立每个Solid到CATIA实例的可靠归属关系；不自动证明装配约束、接触、干涉或运动学。"
        )
        geometry["assembly_root_name"] = assembly.get("name", "")
        json_path = path.parent / (path.stem + "_assembly_geometry.json")
        geometry["geometry_json_path"] = str(json_path)
        json_path.write_text(json.dumps(geometry, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        return geometry
    except Exception as exc:
        return {"status": "error", "backend": "CATIA assembly STEP export + OCP",
                "error": "CATProduct装配STEP导出或OCP解析失败；仅取得装配树，不会假装已读取实体几何。",
                "details": str(exc)}
    finally:
        if temp_step is not None:
            _cleanup_temp_step(temp_step)


def _geometry_evidence(geometry):
    evidence = []
    if geometry.get("status") != "ok":
        return evidence
    evidence.append({
        "evidence_id": "BREP-SUMMARY",
        "source": "CATIA temporary STEP export + Open CASCADE",
        "kind": "cad_fact",
        "status": "computed",
        "value": {
            "solid_count": geometry.get("solid_count"),
            "face_count": geometry.get("face_count"),
            "edge_count": geometry.get("edge_count"),
            "face_type_counts": geometry.get("face_type_counts"),
            "edge_type_counts": geometry.get("edge_type_counts"),
            "cylindrical_face_counts": geometry.get("cylindrical_face_counts"),
            "hole_candidate_count": geometry.get("hole_candidate_count"),
        },
        "unit": None,
        "notes": "由OCP解析STEP B-Rep得到的统计数据。",
    })
    for hole in geometry.get("hole_candidates", []):
        evidence.append({
            "evidence_id": hole.get("candidate_id"),
            "source": "OCP B-Rep topology",
            "kind": "rule_check",
            "status": "computed",
            "value": {
                "topology_class": hole.get("topology_class"),
                "radius": hole.get("radius"),
                "diameter": hole.get("diameter"),
                "source_face_id": hole.get("source_face_id"),
            },
            "unit": "mm",
            "notes": "拓扑候选，不自动证明螺纹或设计功能。",
        })
    return evidence


def _read_with_pyc(path: Path) -> Dict[str, Any]:
    import pythoncom
    from pycatia import catia

    pythoncom.CoInitialize()
    try:
        application = catia()
        documents = application.documents
        document = None
        opened_by_cavai = False

        for candidate in _items(documents):
            full_name = _get(candidate, "full_name", "FullName", default="")
            if full_name and (os.path.normcase(str(full_name)) == os.path.normcase(str(path))
                              or _saved_open_copy_same_as_upload(candidate, path)):
                document = candidate
                break

        if document is None:
            opened = documents.open(str(path))
            document = opened or application.active_document
            opened_by_cavai = True

        result = {
            "status": "ok",
            "document_name": _name(document, path.name),
            "document_path": str(_get(document, "full_name", "FullName", default=path)),
            "document_type": path.suffix.lower().lstrip(".").upper(),
            "opened_by_cavai": opened_by_cavai,
            "adapter": "pycatia",
        }

        if path.suffix.lower() == ".catpart":
            part = document.part
            body_records = _read_bodies(part)
            result["part"] = {
                "part_name": _name(part, path.stem),
                "body_count": len(body_records),
                "bodies": body_records,
            }
            geometry = _analyze_part_geometry(document, path, body_records)
            result["geometry"] = geometry
            result["geometry_topology_verified"] = geometry.get("status") == "ok"
            result["evidence"] = _geometry_evidence(geometry)
            if geometry.get("status") != "ok":
                result["limitations"] = [geometry.get("error", "B-Rep解析未完成。")]
        elif path.suffix.lower() == ".catproduct":
            product = document.product
            result["assembly"] = _read_product(product)
            geometry = _analyze_product_geometry(document, path, result["assembly"])
            result["geometry"] = geometry
            result["geometry_topology_verified"] = geometry.get("status") == "ok"
            result["evidence"] = _geometry_evidence(geometry)
            result["limitations"] = [
                "装配级STEP几何不证明实例间约束、干涉或运动自由度。",
                "当前尚未逐实例映射Solid到其引用CATPart，不自动判定装配定位和夹紧关系。",
            ]
            if geometry.get("status") != "ok":
                result["limitations"].append(geometry.get("error", "装配B-Rep解析失败。"))
        else:
            return {"status": "unsupported", "error": "当前只支持CATPart和CATProduct。"}
        return result
    finally:
        pythoncom.CoUninitialize()


def _read_with_com(path: Path) -> Dict[str, Any]:
    import pythoncom
    import win32com.client

    pythoncom.CoInitialize()
    try:
        try:
            application = win32com.client.GetActiveObject("CATIA.Application")
        except Exception as exc:
            raise RuntimeError("未找到正在运行的CATIA V5。请先启动CATIA。") from exc

        documents = application.Documents
        document = None
        for i in range(1, documents.Count + 1):
            candidate = documents.Item(i)
            full_name = _get(candidate, "FullName", default="")
            if full_name and (os.path.normcase(str(full_name)) == os.path.normcase(str(path))
                              or _saved_open_copy_same_as_upload(candidate, path)):
                document = candidate
                break

        opened_by_cavai = False
        if document is None:
            document = documents.Open(str(path))
            opened_by_cavai = True

        result = {
            "status": "ok",
            "document_name": _name(document, path.name),
            "document_path": str(_get(document, "FullName", default=path)),
            "document_type": path.suffix.lower().lstrip(".").upper(),
            "opened_by_cavai": opened_by_cavai,
            "adapter": "pywin32_com_fallback",
        }

        if path.suffix.lower() == ".catpart":
            part = document.Part
            body_records = _read_bodies(part)
            result["part"] = {
                "part_name": _name(part, path.stem),
                "body_count": len(body_records),
                "bodies": body_records,
            }
            geometry = _analyze_part_geometry(document, path, body_records)
            result["geometry"] = geometry
            result["geometry_topology_verified"] = geometry.get("status") == "ok"
            result["evidence"] = _geometry_evidence(geometry)
            if geometry.get("status") != "ok":
                result["limitations"] = [geometry.get("error", "B-Rep解析未完成。")]
        elif path.suffix.lower() == ".catproduct":
            result["assembly"] = _read_product(document.Product)
            geometry = _analyze_product_geometry(document, path, result["assembly"])
            result["geometry"] = geometry
            result["geometry_topology_verified"] = geometry.get("status") == "ok"
            result["evidence"] = _geometry_evidence(geometry)
            result["limitations"] = [
                "装配级STEP几何不能自动验证配合约束、干涉或运动学。",
                "未将STEP Solid可靠映射到每一个CATIA装配实例。",
            ]
            if geometry.get("status") != "ok":
                result["limitations"].append(geometry.get("error", "装配几何未读取。"))
        else:
            return {"status": "unsupported", "error": "当前只支持CATPart和CATProduct。"}
        return result
    finally:
        pythoncom.CoUninitialize()


def inspect_catia_document(file_path: str) -> Dict[str, Any]:
    path = Path(file_path)
    if not path.exists():
        return {"status": "error", "error": "上传文件不存在：{}".format(file_path)}
    if path.suffix.lower() not in {".catpart", ".catproduct"}:
        return {"status": "unsupported", "error": "当前只支持CATPart和CATProduct。"}

    errors = []
    try:
        return _read_with_pyc(path)
    except Exception as exc:
        errors.append("pycatia: {}".format(exc))

    try:
        result = _read_with_com(path)
        result["pycatia_fallback_reason"] = errors[0]
        return result
    except Exception as exc:
        errors.append("pywin32: {}".format(exc))
        return {
            "status": "error",
            "error": "CATIA读取失败。",
            "details": errors,
            "troubleshooting": [
                "先启动CATIA V5。",
                "不要手动打开上传目录中同名的副本。",
                "确认PyCharm与CATIA使用相同Windows权限级别。",
                "确认CATIA支持导出STEP格式。",
                "确认已安装cadquery-ocp。",
            ],
        }
