# CAVAI V0.1.7

**CAVAI — AI-powered CAD Design Review Agent**

本版本目标：在 Windows + Python 3.9 + CATIA V5 + PyCharm 环境中，提供可从控制台启动的本地聊天界面、动态 Skill 调用基础设施、CATIA读取初版，以及可追溯的开源参考映射。

## 1. 这次版本改了什么

- 使用你本轮上传的新Logo，作为网页品牌图和favicon。
- 新增 `run.py`：默认只在控制台打印实际访问URL，支持PyCharm Terminal Ctrl+左键打开。
- 新增 `start_windows.bat`：双击即可在可见控制台启动，窗口不会自动关闭。
- 在PyCharm Terminal执行 `python run.py`，终端会显示 `http://127.0.0.1:8000`；支持的终端可以 Ctrl+左键打开。
- pycatia作为CATIA V5首选连接路径，pywin32 COM作为回退路径。
- Skill名称、目录、YAML元数据按Agent Skills规范统一。
- 新增按需读取Skill references的工具。
- 新增 `engineering-review-workflow` Skill，参考 `dooosp/freecad-automation` 的工程评审流程。
- 新增开源参考映射、参考文献清单和CAVAI Review Pack Schema。
- 不预设夹具、齿轮箱或其他产品类型；设计要求由用户定义。用户不输入时，AI只能根据可读模型事实提出带不确定性的假设。

## 2. 当前已支持的用户操作流程

1. PyCharm Terminal执行 `python run.py`。
2. 在控制台Ctrl+左键打开打印出的本地网页链接。
3. 网页API设置中填写Base URL、API Key和Model，测试并保存。
4. 上传CATPart/CATProduct/装配ZIP，输入设计要求或让AI先分析。
5. Agent动态加载Skill，读取当前可获得的CATIA数据，调用GPT生成并保存结构化评测报告和修改建议。
6. 网页展示报告摘要、问题和建议，并提供JSON报告下载。

## 3. 当前明确的能力边界

已包含：
- 聊天式网页。
- CATPart / CATProduct / ZIP上传。
- pycatia优先、pywin32回退的CATIA文档读取。
- 动态Skill目录发现、Skill加载、Skill参考资料按需读取。
- OpenAI兼容Chat Completions Function Calling调用循环。
- 开源项目/论文映射与来源记录。

尚未完成：
- B-Rep级面、边、环拓扑分析。
- 对孔、盲孔、贯通孔、螺纹的真实几何识别。
- CATIA DMU干涉/间隙/接触分析工具集成。
- 完整Agent CAD工具选择和复核链（当前已具备Skill工具调用，但CAD事实工具数量有限）。
- FEM、公差、运动学和DFM完整计算。

因此，本版本不能把特征树名称当作几何证明；未提取的几何必须报告为“未验证”。

## 4. 环境

- Windows 10/11
- Python 3.9 x64
- PyCharm
- CATIA V5
- 已安装的CATIA V5可用环境和COM注册

pycatia项目文档明确要求Python 3.9或以上、Windows及正在运行的CATIA V5：
https://github.com/evereux/pycatia

## 5. 安装依赖

在PyCharm打开项目根目录，在Terminal执行：

```powershell
python -m pip install -r requirements.txt
python -m pip install -r requirements-catia.txt
```

如果你已有这些包，可以不重复安装。

## 6. 启动方式（推荐）

### 方式A：PyCharm Terminal

在项目根目录执行：

```powershell
python run.py
```

控制台会打印：

```text
CAVAI V0.1.7 - Local CAD Design Review Agent
Local URL : http://127.0.0.1:8000
Tip       : In PyCharm Terminal, Ctrl+Left Click the URL.
Stop      : Ctrl+C
```

默认只在控制台输出网址，方便你在PyCharm Terminal中Ctrl+左键点击。若希望自动打开浏览器：

```powershell
python run.py --open-browser
```

### 方式B：双击启动

双击项目根目录的：

```text
start_windows.bat
```

它会保持控制台窗口打开，显示启动信息和错误。关闭服务时在窗口按 `Ctrl+C`。

### 方式C：直接使用Uvicorn

```powershell
python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

访问：

http://127.0.0.1:8000

如果8000端口已占用，推荐使用 `python run.py`，它会自动寻找8000-8019中的可用端口，并打印实际地址。

## 7. 网页配置第三方GPT API

启动网页后，点击右上角或左侧的“API设置”，填写：
- API Base URL
- API Key
- Model名称

先点击“测试连接”，测试通过后点击“保存设置”。设置保存在本机 `data/settings.json`，API Key不会通过设置读取接口返回给浏览器。该文件已加入 `.gitignore`。注意：该本地JSON文件中的密钥是明文保存的，请保护好项目目录，不要分享或上传整个项目文件夹。

当前Agent使用OpenAI兼容Chat Completions Function Calling。第三方服务必须支持 `tools`、`tool_calls` 和 `tool_choice`；不支持时会明确报错，不会伪装成已调用Skill。

安全提醒：CAVAI默认只绑定 `127.0.0.1`，不要把本地服务暴露到公网；不要将API Key提交到GitHub或放入前端代码。
## 8. Skill系统

Skill遵循Agent Skills开放规范：
https://github.com/agentskills/agentskills

结构：

```text
skills/
├── cad-model-intake/
│   ├── SKILL.md
│   └── references/sources.md
├── design-intent-analysis/
│   ├── SKILL.md
│   └── references/sources.md
├── part-geometry-review/
│   ├── SKILL.md
│   └── references/sources.md
├── assembly-review/
│   ├── SKILL.md
│   └── references/sources.md
├── evidence-verification/
│   ├── SKILL.md
│   └── references/sources.md
├── review-report/
│   ├── SKILL.md
│   └── references/sources.md
└── engineering-review-workflow/
    ├── SKILL.md
    └── references/sources.md
```

Agent调用：
1. 后端从Skill Registry读取轻量的名称/描述元数据，并动态放入 `load_skill` 工具定义；不会把完整Skill正文预先塞进提示词。
2. 模型根据当前任务直接调用 `load_skill`，只加载所选SKILL.md（一次工具调用，不需要先额外调用list_skills）。
3. `read_skill_reference`：只有需要时才加载对应references。
4. `get_current_model_facts`：读取本轮后端真实获得的模型信息。
5. `/api/skills` 可供网页/维护者查看Skill目录，不占用模型工具调用轮次。

Skill文件夹名必须与frontmatter中的name一致，使用小写字母和连字符。

检查Skill格式：

```powershell
python validate_skills.py
```

查看技能清单：
http://127.0.0.1:8000/api/skills

## 9. FreeCAD Automation在CAVAI中的位置

重要参考项目：
https://github.com/dooosp/freecad-automation

它不是CATIA插件，也不是CAVAI的运行依赖。它的价值是提供完整的工程评审工作流参考：模型导入、intent编译、确定性DFM检查、review pack、证据链、revision impact、inspection planning、readiness和报告。

它的README指出Windows native FreeCAD runtime仍属于实验/兼容路径，主要运行时验证在macOS FreeCAD 1.1.x；其Python测试路径要求Python 3.11+。所以本项目不会在你的Python 3.9/CATIA环境里强行安装FreeCAD。

具体模块映射见：
- `references/OPEN_SOURCE_REFERENCE_MAP.md`
- `references/BIBLIOGRAPHY.md`

## 10. 开源复用与许可证

- pycatia：MIT，作为CATIA接口依赖。
- FreeCAD Automation：MIT，当前复用其公开工作流架构思路；没有将整个仓库复制进CAVAI。
- Agent Skills：采用开放Skill格式规范。
- CATIA MCP、DMU分析、CAD-Assistant、OCP、BRepNet：作为明确标注的工具/算法/研究参考；是否直接复制代码必须逐仓库检查许可证和版本要求。

每次新增直接代码复用，都应记录上游仓库、文件路径、版本/commit、许可证、修改内容和测试结果。

## 11. 目录结构

```text
CAVAI_V0.1.7/
├── main.py
├── run.py
├── start_windows.bat
├── requirements.txt
├── requirements-catia.txt
├── agent/
├── cad/
├── skills/
├── references/
├── schemas/
├── frontend/
├── static/
└── data/
```

## 12. 常见问题

### 运行后控制台没有显示URL
请使用项目根目录的 `python run.py`，不要在其他目录执行。检查Terminal当前路径是否为CAVAI_V0.1.7。

### 浏览器打不开
复制控制台打印的完整URL到浏览器。默认端口是8000，如果被占用，run.py会选取8001-8019中的可用端口。

### `ModuleNotFoundError`
确认PyCharm选中的解释器与Terminal中的Python是同一个。运行：

```powershell
python -c "import sys; print(sys.executable)"
python -m pip install -r requirements.txt
```

### CATIA读取失败
先启动CATIA V5并确保上传的CATPart/CATProduct可以在CATIA中正常打开。再检查当前PyCharm解释器能否导入pycatia和pywin32。

### GPT提示Function Calling不支持
确认你的第三方API服务和所选模型支持Chat Completions Function Calling。仅支持普通文本聊天的API无法执行动态Skill工具调用。

## 13. 版本说明

V0.1.7是可运行原型和工程架构重整版，不代表完整CAD评测功能已经全部完成。
