@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"

title CAVAI V0.1.7 Local Server

echo.
echo ============================================================
echo  CAVAI V0.1.7 - Local CAD Design Review Agent
echo ============================================================
echo.

set "PYTHON_EXE=python"
if exist ".venv\Scripts\python.exe" set "PYTHON_EXE=.venv\Scripts\python.exe"
if exist "venv\Scripts\python.exe" set "PYTHON_EXE=venv\Scripts\python.exe"

echo Using Python:
%PYTHON_EXE% --version
if errorlevel 1 (
    echo.
    echo ERROR: Python was not found. Open this folder in PyCharm and select your Python 3.9 interpreter.
    pause
    exit /b 1
)

%PYTHON_EXE% -c "import fastapi, uvicorn, dotenv, openai" >nul 2>nul
if errorlevel 1 (
    echo Required web packages are missing. Installing requirements...
    %PYTHON_EXE% -m pip install -r requirements.txt
    if errorlevel 1 (
        echo.
        echo ERROR: Dependency installation failed. See the message above.
        pause
        exit /b 1
    )
)


%PYTHON_EXE% -c "import pycatia, win32com.client" >nul 2>nul
if errorlevel 1 (
    echo CATIA Python dependencies are missing. Installing CATIA requirements...
    %PYTHON_EXE% -m pip install -r requirements-catia.txt
    if errorlevel 1 (
        echo.
        echo WARNING: CATIA dependencies could not be installed. The web UI can still start, but CATIA parsing will be unavailable.
    )
)

echo.
echo Starting server in this console. Do not close this window while using CAVAI.
echo The local URL will be printed below and can be Ctrl+Left Clicked in supported terminals.
echo.
%PYTHON_EXE% run.py
echo.
echo CAVAI server stopped.
pause
