from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List

SKILLS_DIR = Path(__file__).resolve().parent
SKILL_NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


def _parse_frontmatter(text: str):
    if not text.startswith("---\n"):
        raise ValueError("SKILL.md缺少YAML frontmatter")
    parts = text.split("---", 2)
    if len(parts) != 3:
        raise ValueError("SKILL.md frontmatter格式错误")
    metadata = {}
    for line in parts[1].splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        metadata[key.strip()] = value.strip().strip('"').strip("'")
    return metadata, parts[2].lstrip()


def _parse_skill(path: Path) -> Dict[str, str]:
    text = path.read_text(encoding="utf-8")
    metadata, body = _parse_frontmatter(text)
    name = metadata.get("name", "")
    description = metadata.get("description", "")

    if not SKILL_NAME_RE.fullmatch(name):
        raise ValueError("Skill name必须使用小写字母、数字和连字符")
    if name != path.parent.name:
        raise ValueError("Skill name必须与目录名一致")
    if not description or len(description) > 1024:
        raise ValueError("Skill description必须为1-1024字符")

    return {
        "name": name,
        "description": description,
        "content": body,
        "path": str(path),
    }


def list_skills() -> List[Dict[str, str]]:
    result = []
    for path in sorted(SKILLS_DIR.glob("*/SKILL.md")):
        try:
            skill = _parse_skill(path)
            result.append({
                "name": skill["name"],
                "description": skill["description"],
            })
        except Exception:
            continue
    return result


def load_skill(name: str) -> Dict[str, str]:
    for path in SKILLS_DIR.glob("*/SKILL.md"):
        skill = _parse_skill(path)
        if name in (skill["name"], path.parent.name):
            return {
                "name": skill["name"],
                "description": skill["description"],
                "content": skill["content"],
            }
    raise KeyError("未找到Skill: " + name)


def read_skill_reference(name: str, relative_path: str) -> Dict[str, str]:
    skill_dir = None
    for path in SKILLS_DIR.glob("*/SKILL.md"):
        skill = _parse_skill(path)
        if name in (skill["name"], path.parent.name):
            skill_dir = path.parent
            break
    if skill_dir is None:
        raise KeyError("未找到Skill: " + name)

    references_dir = (skill_dir / "references").resolve()
    target = (skill_dir / "references" / relative_path).resolve()
    if references_dir not in target.parents or not target.is_file():
        raise ValueError("引用文件不存在或路径不允许")
    return {
        "skill_name": name,
        "relative_path": relative_path,
        "content": target.read_text(encoding="utf-8"),
    }
