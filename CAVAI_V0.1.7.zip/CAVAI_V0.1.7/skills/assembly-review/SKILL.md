---
name: assembly-review
description: "Use to assess CATProduct structure, component instances, references, placements, constraints, and assembly requirements using available CAD evidence."
---

# Assembly Review Skill

## 目标
判断装配体是否具备用户要求的零件组成和装配关系。

## 工作步骤
1. 读取装配树和所有实例。
2. 区分零件定义与装配实例，同一个零件可以有多个实例。
3. 检查外部引用是否缺失。
4. 获取可用的实例变换和约束信息。
5. 根据用户要求检查零件是否齐全、关系是否合理。
6. 对无法读取的配合、干涉或运动关系明确标记未验证。

## 约束
- 零件名称不等于零件功能。
- 装配树中有两个实例不代表它们已经正确连接。
- 未运行干涉检测不能声称无干涉。
