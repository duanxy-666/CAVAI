# References for Assembly Review

- pycatia Product/Products API and examples: https://pycatia.readthedocs.io/en/latest/examples.html
  - Relevant documented examples include product-tree traversal and component position matrices.
- hoacv5/Catia_MCP: https://github.com/hoacv5/Catia_MCP
  - Reference for exposing CATIA assembly and measurement operations as callable tools.
- Sajath7143 Automated Clash/Clearance/Contact Analysis: https://github.com/Sajath7143/Automated-Clash-Clearance-and-Contact-Analysis-for-CAD-Assemblies-CATIA-V5-Python-
  - Reference for CATIA V5 assembly clash, clearance, and contact workflows; check DMU licensing and repository license before copying code.
- dooosp/freecad-automation: https://github.com/dooosp/freecad-automation
  - Reference for review artifact organization and revision-impact/inspection-planning concepts.
