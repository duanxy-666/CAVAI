# References for Design Intent Analysis

- dooosp/freecad-automation `scripts/intent_compiler.py` (repository path documented in README): https://github.com/dooosp/freecad-automation
  - Reference for converting engineering intent into structured downstream plans.
- CAD-Assistant, ICCV 2025: https://github.com/dimitrismallis/CAD-Assistant
  - Reference for task planning followed by CAD-tool feedback; its primary focus is CAD task solving, not a finished engineering review product.
- Adaptation: CAVAI keeps the user-defined intent as source of truth and does not assume a product category.
