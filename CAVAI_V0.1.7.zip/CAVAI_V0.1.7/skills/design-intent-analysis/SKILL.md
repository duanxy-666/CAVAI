---
name: design-intent-analysis
description: "Use to translate user-defined product functions, design goals, constraints, and acceptance criteria into verifiable engineering requirements. If the user gives no requirements, form clearly labeled hypotheses from model evidence."
---

# Design Intent Analysis Skill

## 目标
把用户定义的设计意图转换为结构化、可验证的要求。

## 工作步骤
1. 优先提取用户明确说出的功能、输入输出、约束、使用工况和验收标准。
2. 将每项要求拆成可观察的结构或可计算的指标。
3. 为每项要求定义所需证据、检查方法和通过条件。
4. 对信息不足的要求标记为待澄清，不自行补充成事实。
5. 用户未提供目标时，先根据CAD模型事实提出一个或多个功能假设，说明置信度和依据，并提出最关键的澄清问题。

## 输出字段
- requirement_id
- user_statement
- interpreted_function
- required_structure
- verification_method
- acceptance_criteria
- evidence_needed
- uncertainty

## 约束
不得预设产品类型。不得把AI推测的用途写成用户确认的设计要求。
