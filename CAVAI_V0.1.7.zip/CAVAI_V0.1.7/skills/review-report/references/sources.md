# References for Review Report

- dooosp/freecad-automation `schemas/`, `src/workflows/`, and review-pack/readiness workflow: https://github.com/dooosp/freecad-automation
  - Reference for schema-governed artifacts, staged review, readiness states, and provenance.
- Sajath7143 Automated Clash/Clearance/Contact Analysis: https://github.com/Sajath7143/Automated-Clash-Clearance-and-Contact-Analysis-for-CAD-Assemblies-CATIA-V5-Python-
  - Reference for exporting engineering check results to structured JSON/CSV.
- Adaptation: CAVAI report fields are CAVAI-specific and do not copy the source repository's schemas.
