---
name: review-report
description: "Use to produce a traceable engineering review report from requirements, CAD facts, checks, and verification results."
---

# Review Report Skill

## 报告结构
1. 任务与用户设计目标。
2. 模型解析范围及限制。
3. 评测摘要。
4. 符合项。
5. 不符合项（每项包含位置、证据、严重程度、影响和改进建议）。
6. 待确认/无法验证项。
7. 复核记录。
8. 总体结论。

## 结论状态
- PASS：所有适用的关键要求都有足够证据支持。
- FAIL：至少一项关键要求有明确反证。
- PARTIAL：部分要求完成检查，仍有未验证项目。
- INCONCLUSIVE：现有证据不足以作出结论。

不得根据未经验证的猜测输出PASS。


## 证据引用规则
- 报告中的 evidence_id 必须来自CAD解析器或实际检查工具返回的证据ID。
- 不得自行编造E-001等ID来装饰报告。
- 若当前模型数据没有证据ID，findings.evidence_ids使用空数组，并在limitations中说明。
- 特征树名称证据必须标记为特征树观察，不能伪装成B-Rep几何证明。
