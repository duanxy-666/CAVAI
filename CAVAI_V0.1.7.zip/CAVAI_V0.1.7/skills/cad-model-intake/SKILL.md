---
name: cad-model-intake
description: "Use when a CATPart, CATProduct, or supported neutral CAD file is uploaded, or when the user asks to inspect a CAD model. Establish the model scope, dependencies, and available evidence before assessment."
---

# CAD Model Intake Skill

## 目标
建立本次任务的CAD模型事实基础，不推测未读取的数据。

## 工作步骤
1. 确认上传文件、扩展名、主文档及外部引用是否可用。
2. 调用当前可用的CAD模型事实工具。
3. 对CATPart记录可读取的Body、特征树和参数；对CATProduct记录装配层级、实例和引用。
4. 标记解析器未覆盖的能力，例如B-Rep拓扑、孔洞、螺纹、装配约束、干涉和运动学。
5. 输出模型摘要，并区分已读取、读取失败和未实现。

## 约束
- 文件名和零件名称不是几何证据。
- 不能把未读取的结构判定为不存在。
- 不得修改或保存用户原始模型。
