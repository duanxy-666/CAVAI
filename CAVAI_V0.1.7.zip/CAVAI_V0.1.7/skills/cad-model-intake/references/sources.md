# References for CAD Model Intake

- pycatia documentation, Getting Started: https://pycatia.readthedocs.io/en/latest/introduction.html
  - Used for the supported `from pycatia import catia`, application, documents, and document access model.
- pycatia Examples: https://pycatia.readthedocs.io/en/latest/examples.html
  - Relevant examples include document open/export, product traversal, position matrices, inertia, and Space Analysis.
- dooosp/freecad-automation README: https://github.com/dooosp/freecad-automation
  - Workflow inspiration: import diagnostics, review-context, explicit runtime boundary, and artifact provenance.
- CAVAI implementation status: references only; this Skill does not itself parse CAD files.


Current version-specific pycatia 0.10.1 documentation checked for V0.1.7:
- Application API: https://pycatia.readthedocs.io/en/latest/api/pycatia/in_interfaces/application.html
  - Documents collection and ActiveDocument are part of the Application interface.
- Examples: https://pycatia.readthedocs.io/en/latest/examples.html
  - Document examples cover opening/closing CATIA documents; Product examples cover product tree traversal and component position matrices.
- Part API: https://pycatia.readthedocs.io/en/latest/api/pycatia/mec_mod_interfaces/part.html
  - Documents the Part.Bodies collection.
- Body API: https://pycatia.readthedocs.io/en/0.10.1/api/pycatia/mec_mod_interfaces/body.html
  - Documents Body.Shapes and Body.Sketches collections.
