# References for Evidence Verification

- dooosp/freecad-automation: https://github.com/dooosp/freecad-automation
  - Its README explicitly separates generated review/readiness artifacts from genuine inspection evidence and describes provenance, quarantine, and human authorization boundaries.
- CAD-Assistant: https://github.com/dimitrismallis/CAD-Assistant
  - Reference for iterative tool execution and feedback-driven replanning.
- Adaptation: CAVAI should use independent geometry/measurement checks where available; repeating the same unverified inference is not independent verification.
