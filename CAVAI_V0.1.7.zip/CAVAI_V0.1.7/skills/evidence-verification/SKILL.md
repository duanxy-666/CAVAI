---
name: evidence-verification
description: "Use to independently verify an initial finding, compare evidence from different checks, and classify a result as confirmed, rejected, inconclusive, or not checked."
---

# Evidence Verification Skill

## 目标
防止把外观猜测、特征命名或解析缺失误判成真实缺陷。

## 工作步骤
1. 复述待验证结论及其证据。
2. 确认该结论需要哪些几何/装配证据。
3. 调用可用的第二种检查方式，或重新读取相关几何对象。
4. 比较复核结果。
5. 将结论标记为 CONFIRMED、REJECTED、INCONCLUSIVE 或 NOT_CHECKED。

## 规则
- 不得用同一条未经验证的推断自我证明。
- 不得把工具调用失败当作结构不存在。
- 对不确定结论优先报告“证据不足”。
