---
name: engineering-review-workflow
description: Use when the task needs a staged engineering review, structured review artifacts, DFM/process-planning context, revision impact, inspection planning, evidence traceability, or readiness reporting. Adapt workflow concepts to the active CAD backend; do not assume FreeCAD is installed.
---

# Engineering Review Workflow

## Source basis
This workflow is adapted from the public architecture and documented workflow surface of `dooosp/freecad-automation` (MIT). It is a workflow reference, not a FreeCAD runtime dependency and not a claim that its implementation has been ported.

Reference map:
- `bin/fcad.js` and `lib/runner.js`: command orchestration and execution boundary.
- `scripts/intent_compiler.py`: translate engineering intent into structured plans.
- `scripts/dfm_checker.py`: deterministic manufacturability checks.
- `src/agents/`: domain-specific manufacturing review agents.
- `src/workflows/`: staged review/readiness/document workflows.
- `schemas/`: explicit artifact contracts.
- `docs/product-workflows.md` and `docs/command-lifecycle.md`: lifecycle and workflow definitions.

## Review procedure
1. Establish input provenance: original file, revision, format, parser version, and dependencies.
2. Build a model context from the active CAD backend. Keep CAD runtime operations separate from plain-Python review logic.
3. Compile user intent into explicit requirements and acceptance criteria.
4. Run deterministic checks first; preserve raw tool outputs and units.
5. Assemble a review pack linking requirements, model entities, checks, findings, and evidence IDs.
6. Distinguish generated analysis from physical inspection evidence. A generated report is not proof that a manufactured part passed inspection.
7. If the model revision changes, identify which findings and evidence may need re-checking.
8. Keep unresolved or unsupported checks visible. Do not convert missing evidence into PASS.
9. Require human confirmation for high-impact engineering decisions and any release/readiness decision.

## Output states
- `pass`: all applicable required checks have sufficient evidence.
- `fail`: at least one required check has a confirmed contradiction.
- `partial`: some checks are complete, others remain open.
- `inconclusive`: evidence is insufficient to decide.

## Adaptation to CAVAI
Use CATIA V5/pycatia as the geometry runtime. Reuse the staged workflow, artifact traceability, explicit schemas, and evidence boundaries described by the source project. Do not install or launch FreeCAD just to use this Skill.
