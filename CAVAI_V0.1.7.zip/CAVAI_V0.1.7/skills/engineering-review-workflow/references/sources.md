# References for Engineering Review Workflow

Primary source:
- dooosp/freecad-automation (MIT): https://github.com/dooosp/freecad-automation

Specific repository areas named by the source README:
- `bin/fcad.js`
- `lib/runner.js`
- `scripts/intent_compiler.py`
- `scripts/dfm_checker.py`
- `src/agents/`
- `src/workflows/`
- `schemas/`
- `docs/product-workflows.md`
- `docs/command-lifecycle.md`

Use these as the starting points when inspecting the upstream implementation. CAVAI adapts workflow architecture to CATIA and does not claim the FreeCAD runtime has been integrated.
