# References for Part Geometry Review

- CadQuery/OCP: https://github.com/CadQuery/OCP
  - Candidate Python binding to Open CASCADE for B-Rep access and geometry operations.
- BRepNet, CVPR 2021: https://github.com/AutodeskAILab/BRepNet
  - Topological message passing over B-Rep entities; research reference, not a drop-in CATIA feature detector.
- Hierarchical CADNet, Computer-Aided Design (2022): https://doi.org/10.1016/j.cad.2022.103226
  - Research reference for machining-feature recognition from B-Reps.
- pycatia Part/Body/Shapes APIs: https://pycatia.readthedocs.io/en/latest/api/pycatia/mec_mod_interfaces/part.html
  - Source for native CATIA feature/body access.
- Adaptation: a missing B-Rep capability must be reported as not checked, never as a confirmed absence.


Current pycatia 0.10.1 examples:
- https://pycatia.readthedocs.io/en/latest/examples.html
  - Part - Hole example documents retrieving origin and direction for CATIA Hole features.
  - Part/Space Analysis examples demonstrate measurable geometry access.
- https://pycatia.readthedocs.io/en/latest/api/pycatia/mec_mod_interfaces/part.html
  - Part.Bodies collection.
- https://pycatia.readthedocs.io/en/0.10.1/api/pycatia/mec_mod_interfaces/body.html
  - Body.Shapes collection.
