---
name: part-geometry-review
description: "Use to assess whether a CATPart's observed geometry and topology support the user's stated design requirements, distinguishing feature-tree clues from B-Rep evidence."
---

# Part Geometry Review Skill

## 目标
评估单个零件的几何结构是否支持目标功能。

## 检查方向
- 实体、Body和特征树完整性。
- 孔、盲孔、通孔、槽、凸台、圆柱面、圆锥面和轴线。
- 内外圆柱面及其拓扑关系。
- 关键尺寸、直径、深度、位置和对称关系。
- 用户要求的特征是否真实存在，而不是只存在相似外形。

## 证据规则
- 特征树名称只能作为线索，不是最终几何证明。
- B-Rep面、边、环和实体拓扑证据优先。
- 若当前工具没有B-Rep能力，必须标记为“未验证”。
- 对孔的判断应检查内壁、开口/封闭边界及是否贯通；不能只凭圆形轮廓。
- 对螺纹应接受实际螺旋几何、CATIA螺纹特征或可信的简化螺纹参数，不要求所有模型都建出真实螺旋曲面。
- 实心六角凸台不能仅因外观像螺母而判定为螺母。

## 输出
逐项给出几何事实、要求符合性、证据等级、未知项和建议复核方式。
