from __future__ import print_function

import argparse
import socket
import threading
import webbrowser

import uvicorn


def port_is_available(host, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        sock.close()


def choose_port(host, preferred):
    for port in range(preferred, preferred + 20):
        if port_is_available(host, port):
            return port
    raise RuntimeError("8000-8019端口均被占用，请关闭旧服务或使用 --port 指定其他端口。")


def main():
    parser = argparse.ArgumentParser(description="Start CAVAI V0.1.7 local web app.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--open-browser", action="store_true", help="Also open the browser automatically.")
    args = parser.parse_args()

    port = choose_port(args.host, args.port)
    url = "http://{}:{}".format(args.host, port)

    print("")
    print("============================================================")
    print(" CAVAI V0.1.7 - Local CAD Design Review Agent")
    print("============================================================")
    print(" Project folder : {}".format(__file__))
    print(" Local URL      : {}".format(url))
    print(" Tip            : In PyCharm Terminal, Ctrl+Left Click the URL.")
    print(" Stop server    : Ctrl+C")
    if port != args.port:
        print(" Note           : Port {} was busy; using {} instead.".format(args.port, port))
    print("============================================================")
    print("", flush=True)

    # Import app only after printing startup guidance so import failures are visible.
    from main import app

    if args.open_browser:
        timer = threading.Timer(1.0, lambda: webbrowser.open(url))
        timer.daemon = True
        timer.start()

    uvicorn.run(app, host=args.host, port=port, log_level="info", access_log=True)


if __name__ == "__main__":
    main()
