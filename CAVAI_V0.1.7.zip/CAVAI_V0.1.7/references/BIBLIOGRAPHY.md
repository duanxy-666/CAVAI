# CAVAI V0.1.6 — References

## Open-source software
1. dooosp. *freecad-automation*. MIT License. https://github.com/dooosp/freecad-automation
2. Bourne, P. *pycatia*. MIT License. https://github.com/evereux/pycatia
3. hoacv5. *Catia_MCP*. https://github.com/hoacv5/Catia_MCP
4. rutwikg. *catia-mcp*. https://github.com/rutwikg/catia-mcp
5. Sajath7143. *Automated Clash, Clearance and Contact Analysis for CAD Assemblies — CATIA V5 Python*. https://github.com/Sajath7143/Automated-Clash-Clearance-and-Contact-Analysis-for-CAD-Assemblies-CATIA-V5-Python-
6. CadQuery. *OCP*. https://github.com/CadQuery/OCP
7. Autodesk AI Lab. *BRepNet*. https://github.com/AutodeskAILab/BRepNet
8. Mallis et al. *CAD-Assistant*. https://github.com/dimitrismallis/CAD-Assistant
9. Agent Skills. *Agent Skills Open Standard*. https://github.com/agentskills/agentskills

## Research papers
10. Mallis, D. et al. (2025). *CAD-Assistant: Tool-Augmented VLLMs as Generic CAD Task Solvers*. ICCV 2025. https://openaccess.thecvf.com/content/ICCV2025/html/Mallis_CAD-Assistant_Tool-Augmented_VLLMs_as_Generic_CAD_Task_Solvers_ICCV_2025_paper.html
11. Lambourne, J. G. et al. (2021). *BRepNet: A Topological Message Passing System for Solid Models*. CVPR 2021. https://openaccess.thecvf.com/content/ICCV2021/html/Lambourne_BRepNet_A_Topological_Message_Passing_System_for_Solid_Models_ICCV_2021_paper.html
12. Colligan, A. R. et al. (2022). *Hierarchical CADNet: Learning from B-Reps for Machining Feature Recognition*. Computer-Aided Design, 147, 103226. https://doi.org/10.1016/j.cad.2022.103226

## Implementation provenance rule
For every future direct code import, record: upstream repository, exact file path, commit or release, license, modifications, and test coverage. Architectural inspiration must be labeled as such; it must not be described as copied or integrated code.
