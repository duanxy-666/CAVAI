const $ = (id) => document.getElementById(id);
let sessionId = null;
let currentFileId = null;
let currentFileName = null;
let busy = false;

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2800);
}

function addMessage(role, text, label) {
  $("welcomeBlock")?.remove();
  const row = document.createElement("div");
  row.className = "message-row " + role;
  const avatar = document.createElement("div");
  avatar.className = "message-avatar";
  avatar.textContent = role === "user" ? "我" : "C";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  row.appendChild(avatar);
  row.appendChild(bubble);
  $("messages").appendChild(row);
  $("messages").scrollTop = $("messages").scrollHeight;
}

function setBusy(value) {
  busy = value;
  $("sendBtn").disabled = value;
  $("sendBtn").querySelector("span").textContent = value ? "处理中" : "发送";
}

function setStep(index, state) {
  const steps = [...$("steps").querySelectorAll(".step")];
  if (!steps[index]) return;
  steps[index].classList.remove("active", "done");
  if (state) steps[index].classList.add(state);
  steps[index].querySelector("i").textContent = state === "done" ? "✓" : state === "active" ? "◌" : "○";
}

function resetSteps() {
  [...$("steps").querySelectorAll(".step")].forEach((step) => {
    step.classList.remove("active", "done");
    step.querySelector("i").textContent = "○";
  });
  $("reportPreview").classList.add("hidden");
}

function showUpload(file) {
  $("uploadPreview").classList.remove("hidden");
  $("uploadedName").textContent = file.name;
  $("uploadedMeta").textContent = "正在上传到本地工作空间…";
  $("emptyModel").classList.add("hidden");
  $("modelCard").classList.remove("hidden");
  $("sideFileName").textContent = file.name;
  $("sideFileSize").textContent = formatBytes(file.size);
  $("fileType").textContent = file.name.split(".").pop().toUpperCase();
  $("modelState").textContent = "正在上传";
}

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / 1024 / 1024).toFixed(1) + " MB";
}


async function loadSettings() {
  try {
    const response = await fetch("/api/settings");
    const data = await response.json();
    $("apiBaseUrl").value = data.base_url || "";
    $("apiModel").value = data.model || "";
    $("apiKey").value = "";
    $("apiKey").placeholder = data.api_key_configured
      ? "API Key已保存；留空表示保持不变"
      : "粘贴你的API Key";
    $("settingsNote").textContent = data.configured
      ? "API已配置：" + (data.api_key_masked || "密钥已保存")
      : "尚未配置API。请填写服务商提供的Base URL、Key和模型名称。";
    $("apiStatus").textContent = data.configured ? "GPT API 已配置" : "尚未配置GPT API";
  } catch (error) {
    $("settingsNote").textContent = "读取设置失败：" + error.message;
  }
}

function openSettings() {
  $("settingsModal").classList.remove("hidden");
  loadSettings();
}
function closeSettings() {
  $("settingsModal").classList.add("hidden");
}
$("settingsBtn").addEventListener("click", openSettings);
$("settingsTopBtn").addEventListener("click", openSettings);
$("closeSettings").addEventListener("click", closeSettings);
$("settingsModal").addEventListener("click", (event) => {
  if (event.target === $("settingsModal")) closeSettings();
});

function settingsPayload() {
  return {
    base_url: $("apiBaseUrl").value.trim(),
    api_key: $("apiKey").value.trim(),
    model: $("apiModel").value.trim()
  };
}

$("testApiBtn").addEventListener("click", async () => {
  const payload = settingsPayload();
  $("settingsNote").textContent = "正在测试API连接和Function Calling能力……";
  $("testApiBtn").disabled = true;
  try {
    const response = await fetch("/api/settings/test", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "连接测试失败");
    $("settingsNote").textContent = "✓ " + data.message;
    $("settingsNote").style.color = "#21845b";
  } catch (error) {
    $("settingsNote").textContent = "连接失败：" + error.message;
    $("settingsNote").style.color = "#b54e45";
  } finally {
    $("testApiBtn").disabled = false;
  }
});

$("saveApiBtn").addEventListener("click", async () => {
  const payload = settingsPayload();
  $("settingsNote").textContent = "正在保存……";
  $("saveApiBtn").disabled = true;
  try {
    const response = await fetch("/api/settings", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "保存失败");
    $("apiKey").value = "";
    $("settingsNote").textContent = "✓ API设置已保存在本机。可以开始上传模型并评测。";
    $("settingsNote").style.color = "#21845b";
    $("apiStatus").textContent = "GPT API 已配置";
    toast("API设置已保存");
    await loadSettings();
  } catch (error) {
    $("settingsNote").textContent = "保存失败：" + error.message;
    $("settingsNote").style.color = "#b54e45";
  } finally {
    $("saveApiBtn").disabled = false;
  }
});

$("fileInput").addEventListener("change", async (event) => {
  const file = event.target.files[0];
  if (!file) return;
  showUpload(file);
  const form = new FormData();
  form.append("file", file);
  try {
    const response = await fetch("/api/upload", { method: "POST", body: form });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "上传失败");
    currentFileId = data.file_id;
    currentFileName = data.filename;
    $("uploadedMeta").textContent = `${data.model_type} · 已保存到本机`;
    $("modelState").textContent = "已上传，等待评测";
    toast("模型已上传。可以描述设计目标，也可以直接发送“请先分析模型”。");
  } catch (error) {
    currentFileId = null;
    $("modelState").textContent = "上传失败";
    toast(error.message);
  }
});

$("removeFile").addEventListener("click", () => {
  currentFileId = null;
  currentFileName = null;
  $("uploadPreview").classList.add("hidden");
  $("modelCard").classList.add("hidden");
  $("emptyModel").classList.remove("hidden");
  $("fileInput").value = "";
});

async function sendMessage(textOverride) {
  if (busy) return;
  const text = (textOverride || $("messageInput").value).trim();
  if (!text && !currentFileId) {
    toast("请先输入消息或上传CAD模型。");
    return;
  }
  const message = text || "请先分析我上传的模型，推测它可能的功能，并指出目前能够确认和不能确认的结构。";
  addMessage("user", message);
  $("messageInput").value = "";
  setBusy(true);
  resetSteps();
  setStep(0, "active");
  setTimeout(() => setStep(0, "done"), 350);
  setTimeout(() => setStep(1, "active"), 400);

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session_id: sessionId, message, file_id: currentFileId })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "请求失败");
    sessionId = data.session_id;
    setStep(0, "done"); setStep(1, "done"); setStep(2, "done"); setStep(3, "done");
    addMessage("assistant", data.reply);
    if (data.loaded_skills && data.loaded_skills.length) {
      addMessage("assistant", "本轮实际调用的 Skill：\\n" + data.loaded_skills.join("、"));
    }
    if (data.tool_trace && data.tool_trace.length) {
      const names = data.tool_trace.map(item => item.tool);
      toast("Agent已执行工具：" + names.join("、"));
    }
    if (data.inspection) {
      $("modelState").textContent = data.inspection.status === "ok" ? "CATIA读取成功（基础信息）" : "CATIA读取未完成";
    }
    if (data.report) renderReport(data.report);
    if (data.provider === "local_fallback") toast("当前使用本地提示模式；配置API后可启用GPT。");
    if (data.provider === "api_error") toast("GPT API调用失败，请检查配置。");
  } catch (error) {
    addMessage("assistant", "本次请求未完成：" + error.message);
    toast(error.message);
  } finally {
    setBusy(false);
  }
}

$("sendBtn").addEventListener("click", () => sendMessage());
$("messageInput").addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
});
$("messageInput").addEventListener("input", function () {
  this.style.height = "auto";
  this.style.height = Math.min(this.scrollHeight, 120) + "px";
});
document.querySelectorAll(".suggestion").forEach((button) => {
  button.addEventListener("click", () => sendMessage(button.dataset.prompt));
});

function renderReport(report) {
  if (!report) return;
  $("reportPreview").classList.remove("hidden");
  const status = report.overall_status || report.verdict || "inconclusive";
  const labels = {
    pass: "评测通过",
    fail: "存在不符合项",
    partial: "部分完成",
    inconclusive: "证据不足，无法定论"
  };
  $("verdictText").textContent = labels[status] || status;
  $("verdictNote").textContent = report.summary || report.title || "检查结果";

  const list = $("findingList");
  list.innerHTML = "";
  const findings = report.findings || [];
  findings.forEach((finding) => {
    const item = document.createElement("div");
    item.className = "finding";
    const severity = document.createElement("span");
    severity.className = "severity " + (finding.severity || "medium");
    severity.textContent = ({critical:"严重", high:"高风险", medium:"中风险", low:"低风险", info:"提示"})[finding.severity] || "待关注";
    const title = document.createElement("b");
    title.textContent = finding.title || "未命名问题";
    const detail = document.createElement("small");
    detail.textContent = (finding.detail || "") + (finding.recommendation ? " 建议：" + finding.recommendation : "");
    item.append(severity, title, detail);
    list.appendChild(item);
  });

  let link = $("reportDownloadLink");
  if (!link) {
    link = document.createElement("a");
    link.id = "reportDownloadLink";
    link.className = "report-download";
    link.textContent = "下载完整评测报告 JSON ↓";
    $("reportPreview").appendChild(link);
  }
  if (report.report_id) {
    link.href = "/api/reports/" + encodeURIComponent(report.report_id) + "/download";
    link.classList.remove("hidden");
  } else {
    link.classList.add("hidden");
  }
}

$("newChatBtn").addEventListener("click", () => {
  sessionId = null;
  currentFileId = null;
  currentFileName = null;
  $("messages").innerHTML = "";
  $("messages").appendChild(createWelcome());
  $("uploadPreview").classList.add("hidden");
  $("modelCard").classList.add("hidden");
  $("emptyModel").classList.remove("hidden");
  $("fileInput").value = "";
  resetSteps();
  toast("已创建新会话");
});

function createWelcome() {
  const wrap = document.createElement("div");
  wrap.className = "welcome-block";
  wrap.innerHTML = `<div class="welcome-mark"><img src="/static/brand_logo.png" alt=""></div>
  <div class="welcome-kicker">WELCOME TO CAVAI</div><h2>你的设计意图，由你定义。</h2>
  <p>上传 CATIA 模型并描述设计要求；也可以不输入要求，让 CAVAI 先分析模型并提出功能假设。</p>
  <div class="welcome-note">
    <span>01</span><div><b>你定义目标</b><small>不预设固定产品类型</small></div>
    <span>02</span><div><b>AI读取模型</b><small>依据实际可获取的CATIA数据</small></div>
    <span>03</span><div><b>证据驱动评测</b><small>区分已验证、未验证和不符合项</small></div>
  </div>`;
  return wrap;
}

$("apiStatus").textContent = "本地服务在线";
fetch("/api/health").then(r => r.json()).then(data => {
  $("apiStatus").textContent = data.llm_configured ? "GPT API 已配置" : "尚未配置GPT API";
}).catch(() => $("apiStatus").textContent = "服务连接异常");
loadSettings();

