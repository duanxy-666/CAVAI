$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$python = "python"
if (Test-Path ".venv\Scripts\python.exe") {
    $python = ".venv\Scripts\python.exe"
} elseif (Test-Path "venv\Scripts\python.exe") {
    $python = "venv\Scripts\python.exe"
}

Write-Host ""
Write-Host "CAVAI V0.1.7"
& $python --version
Write-Host "Starting local server. Ctrl+Left Click the URL printed by run.py."
Write-Host ""
& $python "run.py"
