from __future__ import annotations

import json
import os
import re
import shutil
import uuid
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from agent.orchestrator import run_chat_turn
from cad.catia_reader import inspect_catia_document
from skills.registry import list_skills
from settings_store import get_llm_settings, save_llm_settings, public_settings
from reports.store import read_review_report

load_dotenv()

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
REPORT_DIR = DATA_DIR / "reports"
FRONTEND_DIR = ROOT / "frontend"
STATIC_DIR = ROOT / "static"

for folder in (UPLOAD_DIR, REPORT_DIR):
    folder.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="CAVAI", version="0.1.7")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.mount("/frontend", StaticFiles(directory=str(FRONTEND_DIR)), name="frontend")

SESSIONS: Dict[str, List[Dict[str, str]]] = {}
UPLOADS: Dict[str, Dict[str, Any]] = {}

ALLOWED_EXTENSIONS = {".catpart", ".catproduct", ".zip"}


class ChatRequest(BaseModel):
    session_id: Optional[str] = None
    message: str
    file_id: Optional[str] = None


class SettingsRequest(BaseModel):
    base_url: str
    api_key: str
    model: str


class SettingsTestRequest(BaseModel):
    base_url: str
    api_key: str
    model: str


def safe_extract_zip(zip_path: Path, destination: Path) -> List[Path]:
    """Extract a user ZIP while rejecting path traversal entries."""
    extracted: List[Path] = []
    destination_resolved = destination.resolve()
    with zipfile.ZipFile(zip_path, "r") as archive:
        for member in archive.infolist():
            if member.is_dir():
                continue
            target = (destination / member.filename).resolve()
            if destination_resolved not in target.parents and target != destination_resolved:
                raise HTTPException(status_code=400, detail="ZIP中包含不安全的路径，已拒绝解压。")
            archive.extract(member, destination)
            extracted.append(target)
    return extracted


@app.get("/", response_class=HTMLResponse)
def home():
    return FileResponse(FRONTEND_DIR / "index.html")


@app.get("/api/health")
def health():
    return {
        "ok": True,
        "app": "CAVAI",
        "version": "0.1.7",
        "python_note": "Designed for Python 3.9+",
        "llm_configured": public_settings()["configured"],
        "llm_model": public_settings()["model"],
        "catia_adapter": "pycatia_preferred_with_pywin32_fallback",
        "python_version": os.sys.version.split()[0],
        "pycatia_installed": __import__("importlib.util").util.find_spec("pycatia") is not None,
        "pywin32_installed": __import__("importlib.util").util.find_spec("win32com") is not None,
        "catia_available_check": "not_checked",
        "skills_count": len(list_skills())
    }


@app.get("/api/skills")
def get_skills():
    """Return skill metadata only; full skill files are loaded on demand by the Agent."""
    return {"skills": list_skills()}


@app.get("/api/settings")
def get_settings():
    return public_settings()


@app.post("/api/settings")
def update_settings(request: SettingsRequest):
    existing = get_llm_settings()
    api_key = request.api_key.strip() or existing["api_key"]
    if not request.base_url.strip() or not api_key or not request.model.strip():
        raise HTTPException(status_code=400, detail="API Base URL、API Key和模型名称都必须填写。")
    if not request.base_url.strip().startswith(("http://", "https://")):
        raise HTTPException(status_code=400, detail="API Base URL必须以http://或https://开头。")
    save_llm_settings(request.base_url, api_key, request.model)
    return {"ok": True, "settings": public_settings()}


@app.post("/api/settings/test")
def test_settings(request: SettingsTestRequest):
    existing = get_llm_settings()
    api_key = request.api_key.strip() or existing["api_key"]
    base_url = request.base_url.strip() or existing["base_url"]
    model = request.model.strip() or existing["model"]
    if not api_key or not model:
        raise HTTPException(status_code=400, detail="请填写API Key和模型名称。")
    try:
        from openai import OpenAI
        kwargs = {"api_key": api_key}
        if base_url:
            kwargs["base_url"] = base_url.rstrip("/")
        client = OpenAI(**kwargs)
        from agent.llm_client import build_tools
        skill_catalog = list_skills()
        cavai_tools = build_tools(skill_catalog)
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": "请调用一个与你当前任务相关的CAVAI Skill。"}],
            tools=cavai_tools,
            tool_choice={"type": "function", "function": {"name": "load_skill"}},
            temperature=0
        )
        message = response.choices[0].message
        calls = getattr(message, "tool_calls", None)
        if not calls or calls[0].function.name != "load_skill":
            raise RuntimeError("API返回成功，但没有执行CAVAI的load_skill工具调用。")
        return {"ok": True, "message": "API连接成功，CAVAI当前工具定义可用，且load_skill Function Calling已执行。"}
    except Exception as exc:
        raise HTTPException(status_code=400, detail="API连接或Function Calling测试失败：" + str(exc))


@app.get("/api/reports/{report_id}/download")
def download_report(report_id: str):
    try:
        report = read_review_report(report_id)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="报告不存在。")
    report_path = REPORT_DIR / (report_id + ".json")
    return FileResponse(
        report_path,
        media_type="application/json",
        filename="CAVAI_Report_{}.json".format(report_id[:8])
    )


@app.post("/api/upload")
async def upload_model(file: UploadFile = File(...)):
    filename = Path(file.filename or "uploaded_model").name
    suffix = Path(filename).suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail="目前支持 .CATPart、.CATProduct 和包含装配文件的 .ZIP。"
        )

    file_id = uuid.uuid4().hex
    session_dir = UPLOAD_DIR / file_id
    session_dir.mkdir(parents=True, exist_ok=True)
    target = session_dir / filename

    size = 0
    with target.open("wb") as out:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            if size > 500 * 1024 * 1024:
                shutil.rmtree(session_dir, ignore_errors=True)
                raise HTTPException(status_code=413, detail="文件超过500MB限制。")
            out.write(chunk)

    extracted_files: List[str] = []
    primary_document: Optional[Path] = None

    if suffix == ".zip":
        try:
            extracted = safe_extract_zip(target, session_dir / "extracted")
        except zipfile.BadZipFile:
            shutil.rmtree(session_dir, ignore_errors=True)
            raise HTTPException(status_code=400, detail="上传文件不是有效ZIP。")
        cad_files = [p for p in extracted if p.suffix.lower() in {".catproduct", ".catpart"}]
        products = [p for p in cad_files if p.suffix.lower() == ".catproduct"]
        primary_document = products[0] if products else (cad_files[0] if cad_files else None)
        extracted_files = [str(p.relative_to(session_dir)) for p in cad_files]
    else:
        primary_document = target

    if primary_document is None:
        shutil.rmtree(session_dir, ignore_errors=True)
        raise HTTPException(status_code=400, detail="ZIP中没有找到CATProduct或CATPart文件。")

    UPLOADS[file_id] = {
        "file_id": file_id,
        "filename": filename,
        "path": str(primary_document),
        "original_path": str(target),
        "extension": primary_document.suffix.lower(),
        "size": size,
        "extracted_files": extracted_files,
    }

    return {
        "file_id": file_id,
        "filename": filename,
        "size": size,
        "model_type": primary_document.suffix.lower().lstrip(".").upper(),
        "primary_document": primary_document.name,
        "extracted_cad_files": extracted_files,
        "message": "文件已接收。实际几何评测需要本机CATIA可通过COM打开该文件。"
    }


@app.post("/api/chat")
def chat(request: ChatRequest):
    session_id = request.session_id or uuid.uuid4().hex
    history = SESSIONS.setdefault(session_id, [])
    upload = UPLOADS.get(request.file_id) if request.file_id else None

    if request.file_id and not upload:
        raise HTTPException(status_code=404, detail="找不到上传文件，请重新上传。")

    inspection = None
    if upload:
        if "inspection" not in upload:
            upload["inspection"] = inspect_catia_document(upload["path"])
        inspection = upload["inspection"]

    result = run_chat_turn(
        message=request.message,
        history=history,
        upload=upload,
        inspection=inspection,
    )

    history.append({"role": "user", "content": request.message})
    history.append({"role": "assistant", "content": result["reply"]})
    # Keep a bounded conversation window.
    del history[:-20]

    return {
        "session_id": session_id,
        "reply": result["reply"],
        "inspection": inspection,
        "provider": result.get("provider", "openai_compatible_tools"),
        "tool_trace": result.get("tool_trace", []),
        "loaded_skills": result.get("loaded_skills", []),
        "report": result.get("report"),
        "report_id": result.get("report_id"),
        "report_download_url": result.get("report_download_url"),
    }



@app.get("/api/reports/{report_id}")
def get_report(report_id: str):
    path = REPORT_DIR / f"{report_id}.json"
    if not path.exists():
        raise HTTPException(status_code=404, detail="报告不存在。")
    return json.loads(path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=False)
