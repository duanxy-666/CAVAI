# CAVAI V0.1.6 — Third-party notices and provenance

CAVAI V0.1.6 does not bundle the full source trees of the projects listed below.

## Direct runtime dependency
- pycatia — https://github.com/evereux/pycatia
  - License: MIT (upstream repository).
  - Used as the preferred Python interface to CATIA V5 Automation.
  - CAVAI keeps a pywin32 COM fallback for compatibility.

## Architecture / workflow references (no upstream source code copied into this package)
- dooosp/freecad-automation — https://github.com/dooosp/freecad-automation
  - Upstream README identifies MIT license.
  - Used as a reference for runtime/review separation, structured review artifacts, evidence provenance, staged review workflows, and explicit readiness boundaries.
  - FreeCAD runtime is not bundled or required by CAVAI.
- Agent Skills — https://github.com/agentskills/agentskills
  - Used as the format reference for Skill folders and SKILL.md metadata.
- CAD-Assistant — https://github.com/dimitrismallis/CAD-Assistant
  - Architecture/research reference only. Check upstream non-commercial license before any source-code reuse.
- BRepNet — https://github.com/AutodeskAILab/BRepNet
  - Research reference only. Check upstream license and dependencies before any source-code reuse.
- OCP — https://github.com/CadQuery/OCP
  - Candidate geometry dependency; not included in this release.
- Catia_MCP — https://github.com/hoacv5/Catia_MCP
  - Tool design reference. Check upstream license before copying code.
- rutwikg/catia-mcp — https://github.com/rutwikg/catia-mcp
  - COM stability/tool design reference. Check AGPL-3.0 obligations before copying code.
- Sajath7143 clash/clearance/contact project — see references/OPEN_SOURCE_REFERENCE_MAP.md
  - Reference only; verify repository license and CATIA DMU requirements before reuse.

For every future direct code import, record the exact upstream file, version/commit, license, modifications, and test results in references/OPEN_SOURCE_REFERENCE_MAP.md.
