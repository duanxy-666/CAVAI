from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_health():
    response = client.get("/api/health")
    assert response.status_code == 200
    payload = response.json()
    assert payload["app"] == "CAVAI"
    assert payload["version"] == "0.1.7"

def test_settings_page():
    response = client.get("/")
    assert response.status_code == 200
    assert 'id="settingsModal"' in response.text
    assert 'id="apiBaseUrl"' in response.text
