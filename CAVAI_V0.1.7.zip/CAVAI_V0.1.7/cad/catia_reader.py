from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict


def _safe_attr(obj: Any, name: str, default=None):
    try:
        return getattr(obj, name)
    except Exception:
        return default


def _collection_count(collection) -> int:
    try:
        return int(collection.count)
    except Exception:
        try:
            return int(collection.Count)
        except Exception:
            return 0


def _collection_item(collection, index: int):
    try:
        return collection.item(index)
    except Exception:
        return collection.Item(index)




def _part_evidence(part_data: Dict[str, Any]) -> list:
    evidence = []
    for body in part_data.get("bodies", []):
        body_id = body.get("entity_id")
        if body_id:
            evidence.append({
                "evidence_id": body_id,
                "source": "CATIA Part.Bodies",
                "kind": "cad_fact",
                "status": "observed",
                "value": body.get("name"),
                "unit": None,
                "notes": "仅为Body名称/层级观察，不证明具体功能。",
            })
        for feature in body.get("features", []):
            feature_id = feature.get("entity_id")
            if feature_id:
                evidence.append({
                    "evidence_id": feature_id,
                    "source": "CATIA Body.Shapes",
                    "kind": "cad_fact",
                    "status": "observed",
                    "value": feature.get("name"),
                    "unit": None,
                    "notes": "特征树/Shape对象观察；当前未完成B-Rep拓扑验证。",
                })
    return evidence


def _assembly_evidence(node: Dict[str, Any]) -> list:
    evidence = []
    node_id = node.get("entity_id")
    if node_id:
        evidence.append({
            "evidence_id": node_id,
            "source": "CATIA Product.Products",
            "kind": "cad_fact",
            "status": "observed",
            "value": "{} ({})".format(node.get("name", ""), node.get("part_number", "")),
            "unit": None,
            "notes": "仅为装配树节点观察，不证明零件功能或正确配合。",
        })
    for child in node.get("children", []):
        evidence.extend(_assembly_evidence(child))
    return evidence

def _read_part_pyc(document) -> Dict[str, Any]:
    part = document.part()
    bodies = part.bodies
    body_items = []

    for i, body in enumerate(bodies, start=1):
        body_name = _safe_attr(body, "name", "Body_{}".format(i))
        features = []
        shapes = _safe_attr(body, "shapes")
        if shapes is not None:
            try:
                shape_items = list(shapes.items())
            except Exception:
                shape_items = []
                count = _collection_count(shapes)
                for j in range(1, count + 1):
                    shape_items.append(_collection_item(shapes, j))
            for j, shape in enumerate(shape_items, start=1):
                features.append({
                    "entity_id": "BODY-{:03d}-FEATURE-{:03d}".format(i, j),
                    "name": _safe_attr(shape, "name", "Shape_{}".format(j)),
                    "wrapper_class": type(shape).__name__,
                    "classification": "unverified",
                    "evidence_level": "feature_tree_observation",
                })
        body_items.append({
            "entity_id": "BODY-{:03d}".format(i),
            "name": body_name,
            "shape_count": len(features),
            "features": features,
        })

    return {
        "part_name": _safe_attr(part, "name", "UnknownPart"),
        "body_count": len(body_items),
        "bodies": body_items,
        "adapter": "pycatia",
        "geometry_topology_verified": False,
        "hole_detection": "not_implemented_in_v0.1.7",
        "thread_detection": "not_implemented_in_v0.1.7",
        "limitations": [
            "当前读取CATIA Part/Body/Shapes对象，不是完整B-Rep面、边和环拓扑检查。",
            "特征名或包装类名只能作为线索，不能单独证明某项机械功能。",
            "未提取的孔、螺纹和几何关系必须标记为未验证。",
        ],
    }


def _read_product_pyc(product, depth=0, node_path="ROOT") -> Dict[str, Any]:
    node = {
        "entity_id": "ASSEMBLY-{}".format(node_path),
        "name": _safe_attr(product, "name", "UnknownComponent"),
        "part_number": _safe_attr(product, "part_number", ""),
        "depth": depth,
        "children": [],
    }

    position = _safe_attr(product, "position")
    if position is not None:
        try:
            node["position_components"] = list(position.get_components())
        except Exception:
            node["position_components"] = None

    try:
        children = product.get_products()
    except Exception:
        products = _safe_attr(product, "products")
        try:
            children = list(products.items()) if products is not None else []
        except Exception:
            children = []
    for child_index, child in enumerate(children, start=1):
        node["children"].append(_read_product_pyc(child, depth + 1, "{}-{}".format(node_path, child_index)))
    return node


def _inspect_with_pyc(path: Path) -> Dict[str, Any]:
    import pythoncom
    from pycatia import catia

    pythoncom.CoInitialize()
    try:
        # pycatia's documented public pattern is:
        # from pycatia import catia; catia.documents.open(...); catia.active_document
        documents = catia.documents
        document = None
        opened_by_cavai = False
        try:
            document_count = _collection_count(documents)
            for index in range(1, document_count + 1):
                candidate = _collection_item(documents, index)
                candidate_path = _safe_attr(candidate, "path")
                if callable(candidate_path):
                    candidate_path = candidate_path()
                if candidate_path and os.path.normcase(str(candidate_path)) == os.path.normcase(str(path)):
                    document = candidate
                    break
        except Exception:
            document = None

        if document is None:
            documents.open(str(path))
            document = catia.active_document
            opened_by_cavai = True

        document_path = _safe_attr(document, "path", path)
        if callable(document_path):
            document_path = document_path()

        base = {
            "status": "ok",
            "document_name": _safe_attr(document, "name", path.name),
            "document_path": str(document_path),
            "document_type": path.suffix.lower().lstrip(".").upper(),
            "opened_by_cavai": opened_by_cavai,
            "adapter": "pycatia",
        }

        if path.suffix.lower() == ".catpart":
            base["part"] = _read_part_pyc(document)
            base["evidence"] = _part_evidence(base["part"])
        elif path.suffix.lower() == ".catproduct":
            product = document.product()
            base["assembly"] = _read_product_pyc(product)
            base["evidence"] = _assembly_evidence(base["assembly"])
            base["limitations"] = [
                "V0.1.7读取CATProduct装配层级、实例名称及可用的位置数据。",
                "尚未完成装配约束、干涉、间隙和运动学验证。",
            ]
        else:
            return {"status": "unsupported", "error": "暂不支持该文件类型。"}

        return base
    finally:
        pythoncom.CoUninitialize()


def _read_part_com(doc) -> Dict[str, Any]:
    part = doc.Part
    bodies = part.Bodies
    body_items = []
    for i in range(1, bodies.Count + 1):
        body = bodies.Item(i)
        features = []
        try:
            shapes = body.Shapes
            for j in range(1, shapes.Count + 1):
                shape = shapes.Item(j)
                features.append({
                    "entity_id": "BODY-{:03d}-FEATURE-{:03d}".format(i, j),
                    "name": _safe_attr(shape, "Name", "Shape_{}".format(j)),
                    "wrapper_class": "COM dispatch object",
                    "classification": "unverified",
                    "evidence_level": "feature_tree_observation",
                })
        except Exception as exc:
            features.append({"read_error": str(exc)})
        body_items.append({
            "entity_id": "BODY-{:03d}".format(i),
            "name": _safe_attr(body, "Name", "Body_{}".format(i)),
            "shape_count": len(features),
            "features": features,
        })
    return {
        "part_name": _safe_attr(part, "Name", "UnknownPart"),
        "body_count": len(body_items),
        "bodies": body_items,
        "adapter": "pywin32_com_fallback",
        "geometry_topology_verified": False,
        "hole_detection": "not_implemented_in_v0.1.7",
        "thread_detection": "not_implemented_in_v0.1.7",
    }


def _read_product_com(product, depth=0, node_path="ROOT") -> Dict[str, Any]:
    node = {
        "entity_id": "ASSEMBLY-{}".format(node_path),
        "name": _safe_attr(product, "Name", "UnknownComponent"),
        "part_number": _safe_attr(product, "PartNumber", ""),
        "depth": depth,
        "children": [],
    }
    try:
        position = product.Position
        components = [0.0] * 12
        position.GetComponents(components)
        node["position_components"] = components
    except Exception:
        pass
    try:
        products = product.Products
        for i in range(1, products.Count + 1):
            node["children"].append(_read_product_com(products.Item(i), depth + 1, "{}-{}".format(node_path, i)))
    except Exception as exc:
        node["children_read_error"] = str(exc)
    return node


def _inspect_with_com(path: Path) -> Dict[str, Any]:
    import pythoncom
    import win32com.client

    pythoncom.CoInitialize()
    try:
        try:
            catia_app = win32com.client.GetActiveObject("CATIA.Application")
        except Exception as exc:
            raise RuntimeError(
                "未找到正在运行的CATIA V5。请先启动CATIA并打开模型，再重试。"
            ) from exc

        docs = catia_app.Documents
        document = None
        opened_by_cavai = False
        for i in range(1, docs.Count + 1):
            candidate = docs.Item(i)
            candidate_path = _safe_attr(candidate, "FullName", "")
            if candidate_path and os.path.normcase(candidate_path) == os.path.normcase(str(path)):
                document = candidate
                break
        if document is None:
            document = docs.Open(str(path))
            opened_by_cavai = True

        base = {
            "status": "ok",
            "document_name": _safe_attr(document, "Name", path.name),
            "document_path": _safe_attr(document, "FullName", str(path)),
            "document_type": path.suffix.lower().lstrip(".").upper(),
            "opened_by_cavai": opened_by_cavai,
            "adapter": "pywin32_com_fallback",
        }
        if path.suffix.lower() == ".catpart":
            base["part"] = _read_part_com(document)
            base["evidence"] = _part_evidence(base["part"])
        elif path.suffix.lower() == ".catproduct":
            base["assembly"] = _read_product_com(document.Product)
            base["evidence"] = _assembly_evidence(base["assembly"])
            base["limitations"] = [
                "当前只读取装配树和可用实例位置，不代表已检查配合、干涉或运动。",
            ]
        else:
            return {"status": "unsupported", "error": "暂不支持该文件类型。"}
        return base
    finally:
        pythoncom.CoUninitialize()


def inspect_catia_document(file_path: str) -> Dict[str, Any]:
    path = Path(file_path)
    if not path.exists():
        return {"status": "error", "error": "文件不存在：{}".format(file_path)}

    suffix = path.suffix.lower()
    if suffix not in {".catpart", ".catproduct"}:
        return {"status": "unsupported", "error": "V0.1.6当前只通过CATIA读取CATPart/CATProduct。"}

    errors = []
    try:
        return _inspect_with_pyc(path)
    except Exception as exc:
        errors.append("pycatia: {}".format(exc))

    try:
        result = _inspect_with_com(path)
        result["fallback_reason"] = errors[0]
        return result
    except Exception as exc:
        errors.append("pywin32: {}".format(exc))
        return {
            "status": "error",
            "error": "CATIA读取失败。请确认CATIA V5已启动、文件可打开、Python环境安装pycatia/pywin32且权限一致。",
            "details": errors,
        }
