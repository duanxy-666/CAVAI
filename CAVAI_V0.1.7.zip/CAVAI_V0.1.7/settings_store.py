from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

ROOT = Path(__file__).resolve().parent
SETTINGS_FILE = ROOT / "data" / "settings.json"


def get_llm_settings() -> Dict[str, str]:
    data: Dict[str, Any] = {}
    if SETTINGS_FILE.exists():
        try:
            data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        except Exception:
            data = {}

    # Backward-compatible fallback to environment variables.
    return {
        "base_url": str(data.get("base_url") or os.getenv("LLM_BASE_URL", "")).strip(),
        "api_key": str(data.get("api_key") or os.getenv("LLM_API_KEY", "")).strip(),
        "model": str(data.get("model") or os.getenv("LLM_MODEL", "")).strip(),
    }


def save_llm_settings(base_url: str, api_key: str, model: str) -> None:
    SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "base_url": base_url.strip().rstrip("/"),
        "api_key": api_key.strip(),
        "model": model.strip(),
    }
    temp = SETTINGS_FILE.with_suffix(".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(SETTINGS_FILE)


def public_settings() -> Dict[str, Any]:
    data = get_llm_settings()
    key = data["api_key"]
    masked = (key[:4] + "…" + key[-4:]) if len(key) > 10 else ("已保存" if key else "")
    return {
        "base_url": data["base_url"],
        "model": data["model"],
        "api_key_configured": bool(key),
        "api_key_masked": masked,
        "configured": bool(data["base_url"] and key and data["model"]),
    }
