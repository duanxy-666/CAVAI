from __future__ import annotations

import json
from typing import Any, Callable, Dict, List

from settings_store import get_llm_settings


def build_tools(skill_catalog: List[Dict[str, str]]) -> List[Dict[str, Any]]:
    skill_names = [item["name"] for item in skill_catalog]
    catalog_text = "\n".join(
        "- {}: {}".format(item["name"], item["description"])
        for item in skill_catalog
    )

    return [
        {
            "type": "function",
            "function": {
                "name": "load_skill",
                "description": (
                    "根据当前CAD任务选择并加载一个专业Skill。完整技能内容只在调用后返回。"
                    "可用Skill：\n" + catalog_text
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "skill_name": {"type": "string", "enum": skill_names}
                    },
                    "required": ["skill_name"],
                    "additionalProperties": False,
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "read_skill_reference",
                "description": "按需读取已加载Skill的references目录中的资料。",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "skill_name": {"type": "string", "enum": skill_names},
                        "relative_path": {"type": "string"},
                    },
                    "required": ["skill_name", "relative_path"],
                    "additionalProperties": False,
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "get_current_model_facts",
                "description": (
                    "读取本轮CATIA解析器实际获得的模型事实。没有提供的数据不能说成不存在。"
                ),
                "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
            },
        },
        {
            "type": "function",
            "function": {
                "name": "save_review_report",
                "description": (
                    "提交本次CAD评测报告。完成分析后必须调用此工具保存报告，"
                    "然后再向用户总结。报告必须区分已验证事实、推断和未验证事项。"
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string"},
                        "overall_status": {
                            "type": "string",
                            "enum": ["pass", "fail", "partial", "inconclusive"]
                        },
                        "summary": {"type": "string"},
                        "requirements": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "requirement": {"type": "string"},
                                    "status": {"type": "string", "enum": ["pass", "fail", "partial", "not_checked", "not_applicable"]},
                                    "evidence": {"type": "string"}
                                },
                                "required": ["requirement", "status", "evidence"],
                                "additionalProperties": False
                            }
                        },
                        "findings": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "title": {"type": "string"},
                                    "severity": {"type": "string", "enum": ["critical", "high", "medium", "low", "info"]},
                                    "status": {"type": "string", "enum": ["confirmed", "rejected", "inconclusive", "not_checked"]},
                                    "detail": {"type": "string"},
                                    "recommendation": {"type": "string"},
                                    "evidence_ids": {"type": "array", "items": {"type": "string"}}
                                },
                                "required": ["title", "severity", "status", "detail", "recommendation", "evidence_ids"],
                                "additionalProperties": False
                            }
                        },
                        "evidence": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "evidence_id": {"type": "string"},
                                    "source": {"type": "string"},
                                    "kind": {"type": "string", "enum": ["cad_fact", "measurement", "rule_check", "human_review", "other"]},
                                    "status": {"type": "string", "enum": ["observed", "computed", "human_confirmed", "unverified", "failed"]},
                                    "value": {"type": ["string", "number", "boolean", "null"]},
                                    "unit": {"type": ["string", "null"]},
                                    "notes": {"type": ["string", "null"]}
                                },
                                "required": ["evidence_id", "source", "kind", "status", "value", "unit", "notes"],
                                "additionalProperties": False
                            }
                        },
                        "limitations": {"type": "array", "items": {"type": "string"}},
                        "suggested_changes": {"type": "array", "items": {"type": "string"}}
                    },
                    "required": ["title", "overall_status", "summary", "requirements", "findings", "evidence", "limitations", "suggested_changes"],
                    "additionalProperties": False
                }
            }
        }
    ]


def run_tool_agent(
    messages: List[Dict[str, Any]],
    tool_executor: Callable[[str, Dict[str, Any]], Dict[str, Any]],
    skill_catalog: List[Dict[str, str]],
    max_tool_rounds: int = 10,
) -> Dict[str, Any]:
    settings = get_llm_settings()
    if not settings["api_key"] or not settings["model"]:
        raise RuntimeError("尚未配置API。请先在网页右上角设置中填写API Base URL、API Key和模型名称。")

    try:
        from openai import OpenAI
    except ImportError as exc:
        raise RuntimeError("未安装openai SDK，请执行 pip install -r requirements.txt") from exc

    kwargs = {"api_key": settings["api_key"]}
    if settings["base_url"]:
        kwargs["base_url"] = settings["base_url"]
    client = OpenAI(**kwargs)

    working = list(messages)
    tools = build_tools(skill_catalog)
    trace: List[Dict[str, Any]] = []
    loaded: List[str] = []
    report_result = None
    force_report = False

    for round_index in range(max_tool_rounds):
        if round_index == 0:
            tool_choice = {"type": "function", "function": {"name": "load_skill"}}
        elif force_report and report_result is None:
            tool_choice = {"type": "function", "function": {"name": "save_review_report"}}
        else:
            tool_choice = "auto"

        response = client.chat.completions.create(
            model=settings["model"],
            messages=working,
            tools=tools,
            tool_choice=tool_choice,
            temperature=0.2,
        )
        assistant = response.choices[0].message
        calls = getattr(assistant, "tool_calls", None)

        if not calls:
            if round_index == 0 and not loaded:
                raise RuntimeError("API未执行Skill加载。请确认该模型支持Function Calling及tool_choice。")
            if report_result is None:
                working.append({"role": "assistant", "content": assistant.content or ""})
                working.append({
                    "role": "user",
                    "content": "请基于已经获得的模型事实、已加载Skill和检查结果，提交结构化评测报告。必须调用 save_review_report 工具，不要只输出文字报告。"
                })
                force_report = True
                continue
            return {
                "reply": assistant.content or "评测报告已生成。",
                "provider": "openai_compatible_tools",
                "tool_trace": trace,
                "loaded_skills": loaded,
                "report": report_result.get("report"),
                "report_id": report_result.get("report_id"),
                "report_download_url": report_result.get("download_url"),
            }

        assistant_tool_message = {
            "role": "assistant",
            "content": assistant.content or "",
            "tool_calls": [],
        }
        for call in calls:
            assistant_tool_message["tool_calls"].append({
                "id": call.id,
                "type": "function",
                "function": {
                    "name": call.function.name,
                    "arguments": call.function.arguments or "{}",
                },
            })
        working.append(assistant_tool_message)

        for call in calls:
            name = call.function.name
            try:
                args = json.loads(call.function.arguments or "{}")
            except json.JSONDecodeError:
                args = {}
            result = tool_executor(name, args)
            trace.append({
                "tool": name,
                "arguments": args,
                "ok": "error" not in result,
            })
            if name == "load_skill" and "content" in result:
                loaded.append(result.get("name", args.get("skill_name", "")))
            if name == "save_review_report" and "report_id" in result:
                report_result = result
            working.append({
                "role": "tool",
                "tool_call_id": call.id,
                "content": json.dumps(result, ensure_ascii=False, default=str),
            })

    raise RuntimeError("Agent超过最大工具调用轮数，未能完成报告。")
