from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from agent.llm_client import run_tool_agent
from skills.registry import list_skills, load_skill, read_skill_reference
from reports.store import save_review_report


def run_chat_turn(
    message: str,
    history: List[Dict[str, str]],
    upload: Optional[Dict[str, Any]] = None,
    inspection: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    model_context = {
        "user_message": message,
        "uploaded_model": upload,
        "catia_inspection": inspection,
    }

    # This is a compact tool protocol, not a fixed expert persona or product-specific prompt.
    # Task-specific instructions are loaded only when the model invokes load_skill.
    messages: List[Dict[str, Any]] = list(history[-12:])
    messages.append({
        "role": "user",
        "content": (
            message
            + "\n\n[当前模型上下文]\n"
            + json.dumps(model_context, ensure_ascii=False, default=str)
            
        ),
    })

    def execute_tool(name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        if name == "load_skill":
            skill_name = str(arguments.get("skill_name", "")).strip()
            if not skill_name:
                return {"error": "skill_name不能为空"}
            try:
                return load_skill(skill_name)
            except KeyError as exc:
                return {"error": str(exc), "available_skills": list_skills()}
        if name == "read_skill_reference":
            skill_name = str(arguments.get("skill_name", "")).strip()
            relative_path = str(arguments.get("relative_path", "")).strip()
            try:
                return read_skill_reference(skill_name, relative_path)
            except (KeyError, ValueError) as exc:
                return {"error": str(exc)}
        if name == "get_current_model_facts":
            return {
                "uploaded_model": upload,
                "catia_inspection": inspection,
                "note": "仅返回后端真实提供的数据；未提供的几何能力不能推断为不存在。",
            }
        if name == "save_review_report":
            try:
                return save_review_report(arguments)
            except Exception as exc:
                return {"error": "报告保存失败：{}".format(exc)}
        return {"error": "不允许调用未知工具：" + name}

    try:
        result = run_tool_agent(
            messages=messages,
            tool_executor=execute_tool,
            skill_catalog=list_skills(),
            max_tool_rounds=8,
        )
        return {
            "reply": result["reply"],
            "provider": result.get("provider", "openai_compatible_tools"),
            "tool_trace": result.get("tool_trace", []),
            "loaded_skills": result.get("loaded_skills", []),
            "report": result.get("report"),
            "report_id": result.get("report_id"),
            "report_download_url": result.get("report_download_url"),
        }
    except Exception as exc:
        return {
            "reply": (
                "当前模型API调用失败，或服务商不支持兼容的Tool Calling。\n\n"
                f"错误信息：{exc}\n\n"
                "请检查API服务商是否支持Chat Completions的tools/function calling，以及模型是否开放该能力。"
                "本版本不会伪装成已经调用Skill。"
            ),
            "provider": "tool_call_error",
            "tool_trace": [],
            "loaded_skills": [],
        }
